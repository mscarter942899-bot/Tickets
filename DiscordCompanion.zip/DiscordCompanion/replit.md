# Discord Raffle Bot

## Overview

A professional Discord raffle bot built with Discord.js v14 that provides a comprehensive raffle system with live countdowns, interactive UI components, and persistent ticket management. The bot features slash commands, real-time embed updates, and a sophisticated ticket economy system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Framework Choice
- **Discord.js v14**: Modern Discord API wrapper with slash command support
- **Node.js**: Runtime environment for server-side JavaScript execution

The architecture follows a modular design pattern with clear separation of concerns:
- Command handlers for slash command processing
- Interaction handlers for buttons and modals
- Utility managers for business logic
- Persistent storage system for data management

### File Structure
```
├── index.js              # Main entry point and bot initialization
├── commands/             # Slash command implementations
├── handlers/             # Interaction processing (buttons, modals, commands)
├── utils/                # Business logic managers and utilities
└── config/               # Configuration constants and settings
```

## Key Components

### 1. Command System
**Problem**: Need comprehensive raffle management capabilities
**Solution**: Slash command architecture with role-based permissions
- `/earn` - User ticket claiming with cooldown management
- `/create-raffle` - Staff-only raffle creation with flexible duration parsing
- `/end-raffle` - Manual raffle termination for staff
- `/raffle-status` - Live raffle status with countdown timers
- `/my-tickets` - User ticket balance and breakdown
- `/chat-stats` - Chat activity tracking and rewards

**Pros**: Type-safe parameters, built-in Discord validation, modern UX
**Cons**: Requires Discord application command registration

### 2. Interaction Management
**Problem**: Complex UI interactions beyond simple commands
**Solution**: Centralized interaction handler with specialized sub-handlers
- Button interactions for raffle entry and help
- Modal forms for detailed raffle entry with ticket amount selection
- Autocomplete support for enhanced user experience

### 3. Ticket Economy System
**Problem**: Fair and persistent ticket distribution and tracking
**Solution**: Multi-source ticket manager with cooldown enforcement
- **Earn System**: 30-minute cooldown for free ticket claims
- **Chat Rewards**: 1 ticket per message with anti-spam protection
- **Admin Awards**: Administrator-only ticket distribution system
- **Persistent Storage**: Cross-session ticket balance maintenance
- **Usage Tracking**: Active raffle participation monitoring
- **Data Integrity**: Automatic validation and corruption detection

### 4. Raffle Management
**Problem**: Complex raffle lifecycle with real-time updates
**Solution**: Comprehensive raffle manager with live embed updates
- **Duration Parsing**: Flexible time format support ("30m", "tomorrow 3pm", "15:30")
- **Winner Selection**: Weighted random selection based on ticket entries
- **Live Updates**: Real-time countdown and participation statistics
- **Multi-winner Support**: Up to 10 winners per raffle

### 5. Interactive UI Components
**Problem**: Engaging user experience beyond text commands
**Solution**: Rich embed system with interactive buttons and modals
- **Visual Design**: Color-coded embeds with emoji enhancement
- **Real-time Updates**: Live countdown timers and statistics
- **Interactive Entry**: Modal-based ticket entry with validation
- **Help Integration**: Contextual assistance and tips

## Data Flow

### Ticket Earning Flow
1. User executes `/earn` command
2. TicketManager checks cooldown status
3. If eligible, awards ticket and updates storage
4. Returns updated balance and next earn time

### Raffle Creation Flow
1. Staff member uses `/create-raffle` with parameters
2. DurationParser processes time input to timestamp
3. RaffleManager creates raffle object with unique ID
4. Interactive embed posted with entry buttons
5. Live countdown updates begin

### Raffle Entry Flow
1. User clicks "Enter Raffle" button
2. Modal displays for ticket amount input
3. TicketManager validates available balance
4. If valid, updates raffle participants and user tickets
5. Embed refreshes with updated statistics

### Winner Selection Flow
1. Raffle end time reached or manually ended
2. RaffleManager calculates weighted random selection
3. Winners announced in channel
4. Participant tickets marked as used
5. Raffle marked as completed

## External Dependencies

### Core Dependencies
- **discord.js v14.21.0**: Discord API interaction and bot framework
  - Provides slash commands, embeds, buttons, modals
  - Handles WebSocket connections and event management
  - Type-safe interaction handling

### Built-in Node.js Modules
- **fs/promises**: Asynchronous file system operations for data persistence
- **path**: Cross-platform file path handling
- **util**: Utility functions for development helpers

### Rationale for Minimal Dependencies
The project intentionally uses minimal external dependencies to:
- Reduce security vulnerabilities
- Minimize bundle size and startup time
- Maintain full control over business logic
- Simplify deployment and maintenance

## Deployment Strategy

### Environment Setup
- Node.js 16.11.0+ required for Discord.js v14 compatibility
- Discord bot token required via environment variables
- File system write permissions for data persistence

### Storage Strategy
**Problem**: Need persistent data storage without database complexity
**Solution**: JSON file-based storage with in-memory caching
- **Data Structure**: Maps for efficient lookups, serialized to JSON
- **Persistence**: Automatic saving on data changes
- **Recovery**: Graceful handling of corrupted data files
- **Backup**: Timestamped data exports for recovery

**Pros**: Simple deployment, no database setup, version controllable
**Cons**: Limited scalability, no concurrent access protection

### Scalability Considerations
The current file-based approach works well for small to medium servers. For larger deployments, the storage system can be extended to support:
- Database backends (PostgreSQL, MongoDB)
- Redis for caching and real-time features
- Horizontal scaling with shared storage

### Security Measures
- Permission-based command access (Manage Server for staff commands)
- Input validation and sanitization
- Rate limiting through cooldown systems
- Ephemeral responses for sensitive information

### Monitoring and Maintenance
- Console logging for debugging and monitoring
- Error handling with user-friendly messages
- Graceful degradation for missing permissions
- Data integrity checks on startup