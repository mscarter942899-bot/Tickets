/**
 * Discord Raffle Bot - Main Entry Point
 * A comprehensive raffle bot with live countdowns and interactive UI
 */

const { Client, GatewayIntentBits, Collection, REST, Routes, ActivityType, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { COLORS, EMOJIS, COOLDOWNS } = require('./config/constants.js');
const { RaffleManager } = require('./utils/raffle-manager.js');
const { TicketManager } = require('./utils/ticket-manager.js');
const { Storage } = require('./utils/storage.js');
const { DashboardServer } = require('./dashboard/server.js');
const { BugFixer } = require('./utils/bug-fixer.js');
const interactionHandler = require('./handlers/interaction-handler.js');

// Initialize the Discord client with required intents
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

// Create collections for commands and global managers
client.commands = new Collection();
client.raffleManager = new RaffleManager();
client.ticketManager = new TicketManager();
client.storage = new Storage();
client.bugFixer = new BugFixer(client);
client.dashboardServer = new DashboardServer(client);

/**
 * Load all slash commands from the commands directory
 */
function loadCommands() {
    const commandsPath = path.join(__dirname, 'commands');
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

    console.log(`📦 Loading ${commandFiles.length} commands...`);

    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);

        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
            console.log(`✅ Loaded command: ${command.data.name}`);
        } else {
            console.log(`⚠️  Command at ${filePath} is missing required "data" or "execute" property.`);
        }
    }
}

/**
 * Register slash commands with Discord API
 */
async function registerCommands() {
    const earnCommand = require('./commands/earn.js');
    const createRaffleCommand = require('./commands/create-raffle.js');
    const endRaffleCommand = require('./commands/end-raffle.js');
    const raffleStatusCommand = require('./commands/raffle-status.js');
    const myTicketsCommand = require('./commands/my-tickets.js');
    const giveTicketsCommand = require('./commands/give-tickets.js');
    const removeTicketsCommand = require('./commands/remove-tickets.js');
    const chatStatsCommand = require('./commands/chat-stats.js');

    // Register commands with Discord
    const commands = [
        earnCommand.data.toJSON(),
        createRaffleCommand.data.toJSON(),
        endRaffleCommand.data.toJSON(),
        raffleStatusCommand.data.toJSON(),
        myTicketsCommand.data.toJSON(),
        giveTicketsCommand.data.toJSON(),
        removeTicketsCommand.data.toJSON(),
        chatStatsCommand.data.toJSON()
    ];

    const rest = new REST().setToken(process.env.DISCORD_TOKEN || 'your_bot_token_here');

    try {
        console.log(`🔄 Started refreshing ${commands.length} application (/) commands.`);

        const data = await rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID || 'your_client_id_here'),
            { body: commands },
        );

        console.log(`✅ Successfully reloaded ${data.length} application (/) commands.`);
    } catch (error) {
        console.error('❌ Error registering commands:', error);
    }
}

/**
 * Start the live countdown update system
 * Updates all active raffle embeds every second
 */
function startCountdownUpdates() {
    setInterval(async () => {
        try {
            await client.raffleManager.updateAllRaffles(client);
        } catch (error) {
            console.error('❌ Error updating raffles:', error);
        }
    }, 1000); // Update every second for live countdowns
}

// Client event handlers
client.once('ready', async () => {
    console.log(`🎉 ${client.user.tag} is online and ready!`);
    console.log(`📊 Serving ${client.guilds.cache.size} guilds`);

    // Ensure data directory exists
    const fs = require('fs');
    const dataDir = 'data';
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
        console.log('📁 Created data directory');
    }

    // Set bot activity status
    client.user.setActivity('🎟️ Rizzing Up Baddies', { type: ActivityType.Custom });

    // Load persistent data
    try {
        await client.storage.loadData();
        console.log('💾 Loaded persistent data from storage');

        // Initialize managers with storage
        client.raffleManager.setStorage(client.storage);
        client.ticketManager.setStorage(client.storage);
        console.log('🔧 Initialized managers with storage');
    } catch (error) {
        console.error('❌ Error loading data, starting fresh:', error);
        // Continue with empty data if loading fails
    }

    // Run data integrity validation on startup
    const validationResults = client.ticketManager.validateDataIntegrity();
    if (validationResults.corrected > 0) {
        console.log(`🔧 Data integrity: validated ${validationResults.validated} users, auto-corrected ${validationResults.corrected} issues`);
    } else {
        console.log(`✅ Data integrity check passed (${validationResults.validated} users validated)`);
    }

    // Start the countdown update system
    startCountdownUpdates();
    console.log('⏰ Started live countdown update system');

    // Start dashboard server
    try {
        client.dashboardServer.start(5000);
        console.log('🌐 Dashboard server started on port 5000');
    } catch (error) {
        console.error('❌ Failed to start dashboard server:', error);
    }

    // Initialize bug fixer with enhanced monitoring
    client.bugFixer = new BugFixer(client);

    // Run comprehensive startup diagnostics
    console.log('🔍 Running comprehensive startup diagnostics...');
    try {
        const startupDiagnostics = await client.bugFixer.runComprehensiveDiagnostics();

        const criticalIssues = startupDiagnostics.checks.filter(check => check.severity === 'critical');
        const warningIssues = startupDiagnostics.checks.filter(check => check.severity === 'warning');

        console.log(`🔍 Startup diagnostics completed:`);
        console.log(`   ✅ ${startupDiagnostics.checks.filter(c => c.status === 'pass').length} checks passed`);
        console.log(`   ⚠️  ${warningIssues.length} warnings found`);
        console.log(`   ❌ ${criticalIssues.length} critical issues found`);
        console.log(`   🔧 ${startupDiagnostics.fixes.length} automatic fixes applied`);

        if (criticalIssues.length > 0) {
            console.log('🚨 Critical issues detected:');
            criticalIssues.forEach(issue => {
                console.log(`   - ${issue.name}: ${issue.issues.length} problems`);
            });
        }

    } catch (error) {
        console.error('❌ Startup diagnostics failed:', error);
    }

    client.bugFixer.schedulePeriodicChecks();
    console.log('🔧 Automated bug fixer system started');

    // Register commands
    await registerCommands();
});

// Handle all interactions (slash commands, buttons, modals)
client.on('interactionCreate', async (interaction) => {
    const interactionId = `${interaction.id}-${interaction.customId || interaction.commandName}`;
    console.log(`🎮 Processing interaction ${interactionId}`);

    try {
        await interactionHandler.handle(interaction, client);
        console.log(`✅ Completed interaction ${interactionId}`);
    } catch (error) {
        console.error(`❌ Interaction handler error for ${interactionId}:`, error);

        // Enhanced error handling with more specific error types
        if (!interaction.replied && !interaction.deferred) {
            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Something went wrong`)
                .setDescription('An unexpected error occurred while processing your request.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            try {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            } catch (replyError) {
                console.error('❌ Failed to send error reply:', replyError);

                // Try followUp if reply failed
                try {
                    await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
                } catch (followUpError) {
                    console.error('❌ Failed to send followUp error:', followUpError);
                }
            }
        }

        // Run automated bug detection on interaction errors
        setTimeout(async () => {
            try {
                await client.bugFixer.performHealthCheck();
            } catch (bugFixError) {
                console.error('❌ Bug fixer failed:', bugFixError);
            }
        }, 1000);
    }
});

// Message listener for chat-based ticket earning (1 ticket per message)
client.on('messageCreate', async message => {
    // Ignore bot messages, system messages, and DMs
    if (message.author.bot || !message.guild) return;

    // Ignore very short messages, commands, and common spam
    if (message.content.length < 3 || 
        message.content.startsWith('/') || 
        message.content.startsWith('!') ||
        message.content.startsWith('.')) return;

    try {
        // Process chat activity for ticket earning
        const ticketResult = client.ticketManager.processChatActivity(
            message.author.id, 
            message.guild.id, 
            message.content
        );

        if (ticketResult && ticketResult.awarded) {
            console.log(`🎟️ ${message.author.tag} earned ${ticketResult.amount} ticket${ticketResult.amount !== 1 ? 's' : ''} from chat (${ticketResult.totalMessages} total messages)`);
            // Removed automatic emoji reactions to reduce spam
        }

    } catch (error) {
        console.error('❌ Error processing chat activity:', error);
    }
});

// Handle bot errors
client.on('error', error => {
    console.error('❌ Discord client error:', error);
});

// Handle process termination gracefully
process.on('SIGINT', async () => {
    console.log('🔄 Saving data before shutdown...');
    await client.storage.saveData();
    console.log('💾 Data saved successfully');
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log('🔄 Saving data before shutdown...');
    await client.storage.saveData();
    console.log('💾 Data saved successfully');
    process.exit(0);
});

// Save data periodically
setInterval(async () => {
    try {
        await client.storage.saveData();
        console.log('💾 Auto-saved data');
    } catch (error) {
        console.error('❌ Error auto-saving data:', error);
    }
}, 300000); // Save every 5 minutes

// Load commands and start the bot
loadCommands();

// Login to Discord
const token = process.env.DISCORD_TOKEN;
if (!token || token === 'your_bot_token_here') {
    console.error('❌ Missing DISCORD_TOKEN environment variable!');
    console.log('💡 Please add your Discord bot token to the Secrets tab');
    process.exit(1);
}

client.login(token)
    .catch(error => {
        console.error('❌ Failed to login:', error);
        console.log('💡 Check if your Discord bot token is valid');
        process.exit(1);
    });

module.exports = client;