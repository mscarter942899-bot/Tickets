const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const { Storage } = require('../utils/storage.js');

class DashboardServer {
    constructor(client) {
        this.client = client;
        this.app = express();
        this.storage = new Storage();
        this.logs = [];
        this.setupMiddleware();
        this.setupRoutes();
    }

    setupMiddleware() {
        this.app.use(express.json());
        this.app.use(express.static(path.join(__dirname)));

        // Log all requests
        this.app.use((req, res, next) => {
            this.addLog(`${req.method} ${req.url} - ${new Date().toISOString()}`);
            next();
        });
    }

    setupRoutes() {
        // Dashboard data
        this.app.get('/api/dashboard-data', async (req, res) => {
            try {
                const data = await this.getDashboardData();
                res.json(data);
            } catch (error) {
                this.addLog(`Error getting dashboard data: ${error.message}`);
                res.status(500).json({ error: 'Failed to get dashboard data' });
            }
        });

        // Raffles management
        this.app.get('/api/raffles', async (req, res) => {
            try {
                await this.storage.loadData();
                const raffles = Array.from(this.storage.data.raffles.values());
                console.log('Sending raffles to dashboard:', raffles.length);
                res.json(raffles || []);
            } catch (error) {
                console.error('Error fetching raffles:', error);
                res.status(500).json({ error: 'Failed to load raffles', details: error.message });
            }
        });

        this.app.post('/api/raffles', async (req, res) => {
            try {
                const { prize, description, duration, winners } = req.body;
                // Create raffle logic here
                res.json({ success: true, message: 'Raffle created' });
            } catch (error) {
                res.status(500).json({ error: 'Failed to create raffle' });
            }
        });

        // Tickets management
        this.app.get('/api/tickets', async (req, res) => {
            try {
                await this.storage.loadData();
                const tickets = Object.fromEntries(this.storage.data.tickets);
                res.json(tickets);
            } catch (error) {
                res.status(500).json({ error: 'Failed to get tickets' });
            }
        });

        this.app.post('/api/give-tickets', async (req, res) => {
            try {
                const { userId, amount, reason } = req.body;
                const result = this.client.ticketManager.awardTicket(userId, parseInt(amount), 'admin');
                await this.client.storage.saveData();
                res.json({ success: result.success, message: result.message });
            } catch (error) {
                res.status(500).json({ error: 'Failed to give tickets' });
            }
        });

        // Users data
        this.app.get('/api/users', async (req, res) => {
            try {
                await this.storage.loadData();
                const users = Object.fromEntries(this.storage.data.userStats);
                res.json(users);
            } catch (error) {
                res.status(500).json({ error: 'Failed to get users' });
            }
        });

        // Diagnostics and bug fixing
        this.app.post('/api/diagnostics', async (req, res) => {
            try {
                const diagnostics = await this.runDiagnostics();
                res.json(diagnostics);
            } catch (error) {
                res.status(500).json({ error: 'Failed to run diagnostics' });
            }
        });

        this.app.post('/api/fix-integrity', async (req, res) => {
            try {
                const result = this.client.ticketManager.validateDataIntegrity();
                await this.client.storage.saveData();
                res.json({ fixed: result.corrected });
            } catch (error) {
                res.status(500).json({ error: 'Failed to fix integrity issues' });
            }
        });

        this.app.post('/api/clean-raffles', async (req, res) => {
            try {
                const cleaned = await this.cleanInactiveRaffles();
                res.json({ cleaned });
            } catch (error) {
                res.status(500).json({ error: 'Failed to clean raffles' });
            }
        });

        this.app.post('/api/reset-cooldowns', async (req, res) => {
            try {
                const reset = await this.resetAllCooldowns();
                res.json({ reset });
            } catch (error) {
                res.status(500).json({ error: 'Failed to reset cooldowns' });
            }
        });

        // Configuration
        this.app.get('/api/config', async (req, res) => {
            try {
                const config = await this.getConfiguration();
                res.json(config);
            } catch (error) {
                res.status(500).json({ error: 'Failed to get configuration' });
            }
        });

        this.app.post('/api/config', async (req, res) => {
            try {
                await this.saveConfiguration(req.body);
                res.json({ success: true });
            } catch (error) {
                res.status(500).json({ error: 'Failed to save configuration' });
            }
        });

        // Individual raffle endpoints
        this.app.get('/api/raffles/:id', async (req, res) => {
            try {
                await this.storage.loadData();
                const raffle = this.storage.data.raffles.get(req.params.id);
                if (!raffle) {
                    return res.status(404).json({ error: 'Raffle not found' });
                }
                res.json(raffle);
            } catch (error) {
                res.status(500).json({ error: 'Failed to get raffle' });
            }
        });

        this.app.post('/api/raffles/:id/end', async (req, res) => {
            try {
                const result = await this.client.raffleManager.endRaffle(req.params.id, this.client);
                res.json({ success: result.success, message: result.message });
            } catch (error) {
                res.status(500).json({ error: 'Failed to end raffle' });
            }
        });

        // Individual user endpoints
        this.app.get('/api/users/:id', async (req, res) => {
            try {
                await this.storage.loadData();
                const userId = req.params.id;
                const tickets = Object.fromEntries(this.storage.data.tickets);
                const stats = Object.fromEntries(this.storage.data.userStats);

                res.json({
                    tickets: tickets[userId] || { total: 0 },
                    stats: stats[userId] || {}
                });
            } catch (error) {
                res.status(500).json({ error: 'Failed to get user' });
            }
        });

        // Bot control
        this.app.post('/api/restart', async (req, res) => {
            try {
                this.addLog('Bot restart requested via dashboard');
                res.json({ success: true });
                setTimeout(() => process.exit(0), 1000);
            } catch (error) {
                res.status(500).json({ error: 'Failed to restart bot' });
            }
        });

        // Logs
        this.app.get('/api/logs', (req, res) => {
            try {
                res.type('text/plain');
                
                // Get recent console logs (last 100 lines)
                const logs = this.getRecentLogs();
                res.send(logs);
            } catch (error) {
                console.error('Error fetching logs:', error);
                res.status(500).send('Error fetching logs: ' + error.message);
            }
        });

        this.app.delete('/api/logs', (req, res) => {
            this.logs = [];
            res.json({ success: true });
        });

        // Advanced analytics
        this.app.get('/api/analytics/ticket-distribution', async (req, res) => {
            try {
                await this.storage.loadData();
                const distribution = await this.getTicketDistribution();
                res.json(distribution);
            } catch (error) {
                res.status(500).json({ error: 'Failed to get ticket distribution' });
            }
        });

        this.app.get('/api/analytics/user-activity', async (req, res) => {
            try {
                await this.storage.loadData();
                const activity = await this.getUserActivity();
                res.json(activity);
            } catch (error) {
                res.status(500).json({ error: 'Failed to get user activity' });
            }
        });

        this.app.get('/api/leaderboard/tickets', async (req, res) => {
            try {
                await this.storage.loadData();
                const leaderboard = await this.getTicketLeaderboard();
                res.json(leaderboard);
            } catch (error) {
                res.status(500).json({ error: 'Failed to get ticket leaderboard' });
            }
        });

        // Bulk operations
        this.app.post('/api/bulk/give-tickets', async (req, res) => {
            try {
                const { userIds, amount, reason } = req.body;
                const results = [];
                
                for (const userId of userIds) {
                    const result = this.client.ticketManager.awardTicket(userId, parseInt(amount), reason || 'bulk admin');
                    results.push({ userId, result });
                }
                
                await this.client.storage.saveData();
                res.json({ success: true, results });
            } catch (error) {
                res.status(500).json({ error: 'Failed to bulk give tickets' });
            }
        });

        this.app.post('/api/bulk/remove-tickets', async (req, res) => {
            try {
                const { userIds, amount, reason } = req.body;
                const results = [];
                
                for (const userId of userIds) {
                    const userData = this.client.storage.getUserTickets(userId);
                    userData.total = Math.max(0, userData.total - amount);
                    this.client.storage.setUserTickets(userId, userData);
                    results.push({ userId, newTotal: userData.total });
                }
                
                await this.client.storage.saveData();
                res.json({ success: true, results });
            } catch (error) {
                res.status(500).json({ error: 'Failed to bulk remove tickets' });
            }
        });

        // Export data
        this.app.get('/api/export/all-data', async (req, res) => {
            try {
                await this.storage.loadData();
                const exportData = {
                    tickets: Object.fromEntries(this.storage.data.tickets),
                    raffles: Array.from(this.storage.data.raffles.values()),
                    userStats: Object.fromEntries(this.storage.data.userStats),
                    exportedAt: new Date().toISOString()
                };
                
                res.setHeader('Content-Type', 'application/json');
                res.setHeader('Content-Disposition', 'attachment; filename="raffle-bot-data.json"');
                res.json(exportData);
            } catch (error) {
                res.status(500).json({ error: 'Failed to export data' });
            }
        });

        // Comprehensive system health check
        this.app.post('/api/system/health-check', async (req, res) => {
            try {
                console.log('🔍 Running comprehensive system health check...');
                
                const healthCheck = {
                    timestamp: new Date().toISOString(),
                    systemHealth: {},
                    diagnostics: {},
                    performance: {},
                    recommendations: []
                };

                // System health basics
                healthCheck.systemHealth = {
                    botOnline: this.client.isReady(),
                    memoryUsage: process.memoryUsage(),
                    uptime: process.uptime(),
                    nodeVersion: process.version,
                    platform: process.platform
                };

                // Run full diagnostics
                if (this.client.bugFixer) {
                    healthCheck.diagnostics = await this.client.bugFixer.runComprehensiveDiagnostics();
                }

                // Performance metrics
                const memUsageMB = process.memoryUsage().heapUsed / 1024 / 1024;
                healthCheck.performance = {
                    memoryUsageMB: Math.round(memUsageMB * 100) / 100,
                    totalUsers: this.storage.data.tickets.size,
                    totalRaffles: this.storage.data.raffles.size,
                    activeRaffles: Array.from(this.storage.data.raffles.values()).filter(r => r.isActive).length
                };

                // Generate recommendations
                if (memUsageMB > 500) {
                    healthCheck.recommendations.push('High memory usage detected - consider restarting bot');
                }

                const criticalIssues = healthCheck.diagnostics.checks?.filter(c => c.severity === 'critical') || [];
                if (criticalIssues.length > 0) {
                    healthCheck.recommendations.push(`${criticalIssues.length} critical issues found - review diagnostics`);
                }

                if (process.uptime() > 7 * 24 * 60 * 60) {
                    healthCheck.recommendations.push('Bot has been running for over a week - consider periodic restart');
                }

                console.log(`🔍 System health check completed - ${healthCheck.diagnostics.checks?.length || 0} checks run`);
                res.json(healthCheck);

            } catch (error) {
                console.error('❌ System health check failed:', error);
                res.status(500).json({ 
                    error: 'System health check failed', 
                    details: error.message,
                    timestamp: new Date().toISOString()
                });
            }
        });

        // Serve dashboard
        this.app.get('/', (req, res) => {
            res.sendFile(path.join(__dirname, 'index.html'));
        });
    }

    async getDashboardData() {
        await this.storage.loadData();

        const tickets = this.storage.data.tickets;
        const raffles = this.storage.data.raffles;
        const users = this.storage.data.userStats;

        const totalUsers = tickets.size;
        const totalTickets = Array.from(tickets.values()).reduce((sum, user) => sum + user.total, 0);
        const activeRaffles = Array.from(raffles.values()).filter(r => r.isActive).length;

        // Generate activity data for chart
        const activityLabels = [];
        const ticketActivity = [];
        const messageActivity = [];

        // Last 7 days of activity
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            activityLabels.push(date.toLocaleDateString());

            // Mock data - in real implementation, you'd track this
            ticketActivity.push(Math.floor(Math.random() * 50) + 10);
            messageActivity.push(Math.floor(Math.random() * 200) + 50);
        }

        return {
            botStatus: this.client.isReady() ? 'online' : 'offline',
            totalUsers,
            totalTickets,
            activeRaffles,
            activityLabels,
            ticketActivity,
            messageActivity
        };
    }

    async runDiagnostics() {
        const healthChecks = [];
        const integrityChecks = [];

        // Health checks
        healthChecks.push({
            name: 'Bot Connection',
            status: this.client.isReady() ? 'pass' : 'fail'
        });

        healthChecks.push({
            name: 'Storage Access',
            status: await this.testStorageAccess() ? 'pass' : 'fail'
        });

        healthChecks.push({
            name: 'Command Registration',
            status: this.client.commands.size > 0 ? 'pass' : 'fail'
        });

        // Data integrity checks
        const integrityResult = this.client.ticketManager.validateDataIntegrity();
        integrityChecks.push({
            name: 'Ticket Data Integrity',
            status: integrityResult.corrected === 0 ? 'pass' : 'warning'
        });

        integrityChecks.push({
            name: 'Raffle Consistency',
            status: await this.checkRaffleConsistency() ? 'pass' : 'fail'
        });

        return {
            healthChecks,
            integrityChecks,
            details: {
                totalUsers: this.storage.data.tickets.size,
                totalRaffles: this.storage.data.raffles.size,
                dataIntegrityIssues: integrityResult.corrected,
                lastDataSave: this.storage.data.lastSaved || 'Never'
            }
        };
    }

    async testStorageAccess() {
        try {
            await this.storage.loadData();
            return true;
        } catch (error) {
            return false;
        }
    }

    async checkRaffleConsistency() {
        try {
            const raffles = Array.from(this.storage.data.raffles.values());
            const currentTime = Math.floor(Date.now() / 1000);

            // Check for raffles that should have ended
            const inconsistentRaffles = raffles.filter(raffle => 
                raffle.isActive && raffle.endTime < currentTime
            );

            return inconsistentRaffles.length === 0;
        } catch (error) {
            return false;
        }
    }

    async cleanInactiveRaffles() {
        await this.storage.loadData();
        const raffles = this.storage.data.raffles;
        const currentTime = Math.floor(Date.now() / 1000);
        let cleaned = 0;

        for (const [id, raffle] of raffles.entries()) {
            if (!raffle.isActive && raffle.endTime < currentTime - (7 * 24 * 60 * 60)) {
                raffles.delete(id);
                cleaned++;
            }
        }

        await this.storage.saveData();
        this.addLog(`Cleaned ${cleaned} inactive raffles`);
        return cleaned;
    }

    async resetAllCooldowns() {
        await this.storage.loadData();
        const tickets = this.storage.data.tickets;
        let reset = 0;

        for (const [userId, data] of tickets.entries()) {
            if (data.cooldowns && Object.keys(data.cooldowns).length > 0) {
                data.cooldowns = {};
                reset++;
            }
        }

        await this.storage.saveData();
        this.addLog(`Reset cooldowns for ${reset} users`);
        return reset;
    }

    async getConfiguration() {
        await this.storage.loadData();
        const config = this.storage.getConfig();
        return {
            ...config,
            maxWinners: config.maxWinners || 10,
            maxTicketEntry: config.maxTicketEntry || 0,
            earnCooldown: config.earnCooldown || 30,
            commandCooldown: config.commandCooldown || 3,
            unlimitedEntry: config.unlimitedEntry || true,
            ticketMultiplier: config.ticketMultiplier || 1,
            ticketEmoji: config.ticketEmoji || '🎟️',
            raffleEmoji: config.raffleEmoji || '🎁',
            autoCleanEndedRaffles: config.autoCleanEndedRaffles || false,
            enableTicketLeaderboard: config.enableTicketLeaderboard || false,
            earnFromMessages: config.earnFromMessages || true,
            messagesPerTicket: config.messagesPerTicket || 1,
            minMessageLength: config.minMessageLength || 10,
            weekendBonus: config.weekendBonus || false,
            dailyBonus: config.dailyBonus || 5,
            streakMultiplier: config.streakMultiplier || 1,
            vipRoleBonus: config.vipRoleBonus || 1.5
        };
    }

    async saveConfiguration(config) {
        await this.storage.loadData();
        this.storage.setConfig(config);
        await this.storage.saveData();
        this.addLog(`Configuration updated: ${JSON.stringify(config)}`);
    }

    addLog(message) {
        const timestamp = new Date().toISOString();
        this.logs.push(`[${timestamp}] ${message}`);

        // Keep only last 1000 log entries
        if (this.logs.length > 1000) {
            this.logs = this.logs.slice(-1000);
        }

        console.log(message);
    }

    async getTicketDistribution() {
        const tickets = this.storage.data.tickets;
        const distribution = {
            ranges: {
                '0-10': 0,
                '11-50': 0,
                '51-100': 0,
                '101-500': 0,
                '500+': 0
            },
            totalUsers: tickets.size,
            totalTickets: 0
        };

        for (const userData of tickets.values()) {
            const total = userData.total || 0;
            distribution.totalTickets += total;

            if (total <= 10) distribution.ranges['0-10']++;
            else if (total <= 50) distribution.ranges['11-50']++;
            else if (total <= 100) distribution.ranges['51-100']++;
            else if (total <= 500) distribution.ranges['101-500']++;
            else distribution.ranges['500+']++;
        }

        return distribution;
    }

    async getUserActivity() {
        const users = this.storage.data.userStats;
        const activity = {
            totalActiveUsers: 0,
            messagesLast24h: 0,
            messagesLast7d: 0,
            ticketsEarnedLast24h: 0,
            ticketsEarnedLast7d: 0
        };

        const now = Date.now();
        const day = 24 * 60 * 60 * 1000;
        const week = 7 * day;

        for (const userData of users.values()) {
            if (userData.lastActivity && (now - userData.lastActivity) < week) {
                activity.totalActiveUsers++;
            }

            // Mock data for demonstration - in real implementation, track these metrics
            activity.messagesLast24h += Math.floor(Math.random() * 10);
            activity.messagesLast7d += Math.floor(Math.random() * 50);
            activity.ticketsEarnedLast24h += Math.floor(Math.random() * 5);
            activity.ticketsEarnedLast7d += Math.floor(Math.random() * 20);
        }

        return activity;
    }

    async getTicketLeaderboard() {
        const tickets = this.storage.data.tickets;
        const leaderboard = [];

        for (const [userId, userData] of tickets.entries()) {
            leaderboard.push({
                userId,
                total: userData.total || 0,
                earned: userData.chatRewards || 0,
                spent: userData.spentTickets ? Object.values(userData.spentTickets).reduce((a, b) => a + b, 0) : 0
            });
        }

        return leaderboard
            .sort((a, b) => b.total - a.total)
            .slice(0, 50); // Top 50
    }

    getRecentLogs() {
        return this.logs.slice(-100).join('\n');
    }

    start(port = 5000) {
        this.app.listen(port, '0.0.0.0', () => {
            console.log(`🌐 Dashboard server running on http://0.0.0.0:${port}`);
            this.addLog(`Dashboard server started on port ${port}`);
        });
    }
}

module.exports = { DashboardServer };