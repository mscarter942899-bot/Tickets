class Dashboard {
    constructor() {
        this.currentPage = 'overview';
        this.botData = {};
        this.logs = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupModals();
        this.loadDashboardData();
        this.startDataRefresh();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = e.target.closest('.nav-link').dataset.page;
                this.switchPage(page);
            });
        });

        // Header actions
        document.getElementById('save-config').addEventListener('click', () => this.saveConfiguration());
        document.getElementById('restart-bot').addEventListener('click', () => this.restartBot());

        // Configuration tabs
        document.querySelectorAll('.config-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const targetTab = e.target.dataset.tab;
                this.switchConfigTab(targetTab);
            });
        });

        // Bug fixer actions
        document.getElementById('run-diagnostics').addEventListener('click', () => this.runDiagnostics());
        document.getElementById('fix-data-integrity').addEventListener('click', () => this.fixDataIntegrity());
        document.getElementById('clean-inactive-raffles').addEventListener('click', () => this.cleanInactiveRaffles());
        document.getElementById('reset-cooldowns').addEventListener('click', () => this.resetCooldowns());

        // Log actions
        document.getElementById('clear-logs').addEventListener('click', () => this.clearLogs());
        document.getElementById('refresh-logs').addEventListener('click', () => this.refreshLogs());

        // Modal triggers
        document.getElementById('create-raffle-btn').addEventListener('click', () => this.openModal('create-raffle-modal'));
        document.getElementById('give-tickets-btn').addEventListener('click', () => this.openModal('give-tickets-modal'));

        // Form submissions
        document.getElementById('create-raffle-form').addEventListener('submit', (e) => this.handleCreateRaffle(e));
        document.getElementById('give-tickets-form').addEventListener('submit', (e) => this.handleGiveTickets(e));
    }

    setupModals() {
        document.querySelectorAll('.close').forEach(closeBtn => {
            closeBtn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                this.closeModal(modal.id);
            });
        });

        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal(modal.id);
                }
            });
        });
    }

    switchPage(page) {
        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.toggle('active', link.dataset.page === page);
        });

        // Update pages
        document.querySelectorAll('.page').forEach(pageEl => {
            pageEl.classList.toggle('active', pageEl.id === `${page}-page`);
        });

        // Update title
        const titles = {
            overview: 'Dashboard Overview',
            config: 'Configuration',
            raffles: 'Manage Raffles',
            tickets: 'Ticket Management',
            users: 'User Statistics',
            'bug-fixer': 'Automated Bug Fixer',
            logs: 'System Logs'
        };
        document.getElementById('page-title').textContent = titles[page];

        this.currentPage = page;
        this.loadPageData(page);
    }

    async loadDashboardData() {
        try {
            const response = await fetch('/api/dashboard-data');
            this.botData = await response.json();
            this.updateOverviewStats();
        } catch (error) {
            console.error('Failed to load dashboard data:', error);
            this.showError('Failed to load dashboard data');
        }
    }

    updateOverviewStats() {
        const data = this.botData;

        document.getElementById('bot-status').textContent = data.botStatus || 'Online';
        document.getElementById('bot-status').className = `status ${data.botStatus ? 'online' : 'offline'}`;
        document.getElementById('active-raffles').textContent = data.activeRaffles || 0;
        document.getElementById('total-users').textContent = data.totalUsers || 0;
        document.getElementById('total-tickets').textContent = data.totalTickets || 0;

        this.updateActivityChart();
    }

    updateActivityChart() {
        const ctx = document.getElementById('activity-chart').getContext('2d');

        if (this.activityChart) {
            this.activityChart.destroy();
        }

        this.activityChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.botData.activityLabels || [],
                datasets: [{
                    label: 'Tickets Earned',
                    data: this.botData.ticketActivity || [],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Messages',
                    data: this.botData.messageActivity || [],
                    borderColor: '#764ba2',
                    backgroundColor: 'rgba(118, 75, 162, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    async loadPageData(page) {
        switch (page) {
            case 'raffles':
                await this.loadRafflesData();
                break;
            case 'tickets':
                await this.loadTicketsData();
                break;
            case 'users':
                await this.loadUsersData();
                break;
            case 'logs':
                await this.refreshLogs();
                break;
            case 'config':
                await this.loadConfigData();
                break;
        }
    }

    async loadRafflesData() {
        try {
            const response = await fetch('/api/raffles');
            const raffles = await response.json();
            this.populateRafflesTable(raffles);
        } catch (error) {
            console.error('Failed to load raffles:', error);
        }
    }

    populateRafflesTable(raffles) {
        const tbody = document.querySelector('#raffles-table tbody');
        tbody.innerHTML = '';

        raffles.forEach(raffle => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${raffle.id}</td>
                <td>${raffle.prize}</td>
                <td>${Object.keys(raffle.participants).length}</td>
                <td>${new Date(raffle.endTime * 1000).toLocaleString()}</td>
                <td><span class="check-status ${raffle.isActive ? 'pass' : 'fail'}">${raffle.isActive ? 'Active' : 'Ended'}</span></td>
                <td>
                    <button class="btn btn-warning" onclick="dashboard.endRaffle('${raffle.id}')">End</button>
                    <button class="btn btn-secondary" onclick="dashboard.viewRaffle('${raffle.id}')">View</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    async loadTicketsData() {
        try {
            const response = await fetch('/api/tickets');
            const tickets = await response.json();
            this.populateTicketsTable(tickets);
        } catch (error) {
            console.error('Failed to load tickets:', error);
        }
    }

    populateTicketsTable(tickets) {
        const tbody = document.querySelector('#tickets-table tbody');
        tbody.innerHTML = '';

        Object.entries(tickets).forEach(([userId, data]) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${userId}</td>
                <td>User ${userId.slice(-4)}</td>
                <td>${data.total}</td>
                <td>${data.total - (data.spentTickets ? Object.values(data.spentTickets).reduce((a, b) => a + b, 0) : 0)}</td>
                <td>${data.spentTickets ? Object.values(data.spentTickets).reduce((a, b) => a + b, 0) : 0}</td>
                <td>
                    <button class="btn btn-primary" onclick="dashboard.giveTicketsToUser('${userId}')">Give Tickets</button>
                    <button class="btn btn-secondary" onclick="dashboard.viewUserDetails('${userId}')">Details</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    async loadUsersData() {
        try {
            const response = await fetch('/api/users');
            const users = await response.json();
            this.populateUsersTable(users);
        } catch (error) {
            console.error('Failed to load users:', error);
        }
    }

    populateUsersTable(users) {
        const tbody = document.querySelector('#users-table tbody');
        tbody.innerHTML = '';

        Object.entries(users).forEach(([userId, data]) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${userId}</td>
                <td>${data.chatMessages || 0}</td>
                <td>${data.ticketsEarned || 0}</td>
                <td>${data.lastActivity ? new Date(data.lastActivity).toLocaleString() : 'Never'}</td>
                <td>${data.messageText ? data.messageText.substring(0, 50) + '...' : 'N/A'}</td>
            `;
            tbody.appendChild(row);
        });
    }

    async runDiagnostics() {
        this.showLoading('Running comprehensive diagnostics...');

        try {
            const response = await fetch('/api/diagnostics', { method: 'POST' });
            const results = await response.json();

            this.displayHealthChecks(results.healthChecks);
            this.displayIntegrityChecks(results.integrityChecks);
            this.displayDiagnosticResults(results.details);

        } catch (error) {
            console.error('Diagnostics failed:', error);
            this.showError('Failed to run diagnostics');
        }
    }

    displayHealthChecks(checks) {
        const container = document.getElementById('health-checks');
        container.innerHTML = '';

        checks.forEach(check => {
            const item = document.createElement('div');
            item.className = 'check-item';
            item.innerHTML = `
                <span>${check.name}</span>
                <span class="check-status ${check.status}">${check.status.toUpperCase()}</span>
            `;
            container.appendChild(item);
        });
    }

    displayIntegrityChecks(checks) {
        const container = document.getElementById('integrity-checks');
        container.innerHTML = '';

        checks.forEach(check => {
            const item = document.createElement('div');
            item.className = 'check-item';
            item.innerHTML = `
                <span>${check.name}</span>
                <span class="check-status ${check.status}">${check.status.toUpperCase()}</span>
            `;
            container.appendChild(item);
        });
    }

    displayDiagnosticResults(details) {
        const container = document.getElementById('diagnostic-results');
        container.innerHTML = `<pre>${JSON.stringify(details, null, 2)}</pre>`;
    }

    async fixDataIntegrity() {
        try {
            const response = await fetch('/api/fix-integrity', { method: 'POST' });
            const result = await response.json();
            this.showSuccess(`Fixed ${result.fixed} data integrity issues`);
            this.runDiagnostics();
        } catch (error) {
            this.showError('Failed to fix data integrity issues');
        }
    }

    async cleanInactiveRaffles() {
        try {
            const response = await fetch('/api/clean-raffles', { method: 'POST' });
            const result = await response.json();
            this.showSuccess(`Cleaned ${result.cleaned} inactive raffles`);
            this.loadRafflesData();
        } catch (error) {
            this.showError('Failed to clean inactive raffles');
        }
    }

    async resetCooldowns() {
        try {
            const response = await fetch('/api/reset-cooldowns', { method: 'POST' });
            const result = await response.json();
            this.showSuccess(`Reset ${result.reset} user cooldowns`);
        } catch (error) {
            this.showError('Failed to reset cooldowns');
        }
    }

    async saveConfiguration() {
        const config = {
            botToken: document.getElementById('bot-token').value,
            clientId: document.getElementById('client-id').value,
            maxWinners: parseInt(document.getElementById('max-winners').value),
            maxTicketEntry: parseInt(document.getElementById('max-ticket-entry').value),
            earnCooldown: parseInt(document.getElementById('earn-cooldown').value),
            commandCooldown: parseInt(document.getElementById('command-cooldown').value)
        };

        try {
            const response = await fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            });

            if (response.ok) {
                this.showSuccess('Configuration saved successfully');
            } else {
                this.showError('Failed to save configuration');
            }
        } catch (error) {
            this.showError('Failed to save configuration');
        }
    }

    async restartBot() {
        if (confirm('Are you sure you want to restart the bot? This will temporarily disconnect it.')) {
            try {
                await fetch('/api/restart', { method: 'POST' });
                this.showSuccess('Bot restart initiated');
            } catch (error) {
                this.showError('Failed to restart bot');
            }
        }
    }

    async refreshLogs() {
        try {
            const response = await fetch('/api/logs');
            const logs = await response.text();
            document.getElementById('logs-content').textContent = logs;
        } catch (error) {
            this.showError('Failed to refresh logs');
        }
    }

    clearLogs() {
        if (confirm('Are you sure you want to clear all logs?')) {
            document.getElementById('logs-content').textContent = '';
            fetch('/api/logs', { method: 'DELETE' });
        }
    }

    openModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    async handleCreateRaffle(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const raffleData = Object.fromEntries(formData);

        try {
            const response = await fetch('/api/raffles', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(raffleData)
            });

            if (response.ok) {
                this.showSuccess('Raffle created successfully');
                this.closeModal('create-raffle-modal');
                this.loadRafflesData();
            } else {
                this.showError('Failed to create raffle');
            }
        } catch (error) {
            this.showError('Failed to create raffle');
        }
    }

    async handleGiveTickets(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const ticketData = Object.fromEntries(formData);

        try {
            const response = await fetch('/api/give-tickets', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(ticketData)
            });

            if (response.ok) {
                this.showSuccess('Tickets given successfully');
                this.closeModal('give-tickets-modal');
                this.loadTicketsData();
            } else {
                this.showError('Failed to give tickets');
            }
        } catch (error) {
            this.showError('Failed to give tickets');
        }
    }

    startDataRefresh() {
        setInterval(() => {
            if (this.currentPage === 'overview') {
                this.loadDashboardData();
            }
        }, 30000); // Refresh every 30 seconds
    }

    showSuccess(message) {
        this.showNotification(message, 'success');
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    showLoading(message) {
        this.showNotification(message, 'loading');
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 8px;
            color: white;
            z-index: 1001;
            transition: all 0.3s ease;
        `;

        if (type === 'success') notification.style.background = '#48bb78';
        if (type === 'error') notification.style.background = '#f56565';
        if (type === 'loading') notification.style.background = '#4299e1';

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    async loadConfigData() {
        try {
            const response = await fetch('/api/config');
            const config = await response.json();

            // Populate all configuration fields
            Object.keys(config).forEach(key => {
                const element = document.getElementById(this.camelToKebab(key));
                if (element) {
                    if (element.type === 'checkbox') {
                        element.checked = config[key];
                    } else {
                        element.value = config[key] || '';
                    }
                }
            });

            this.showSuccess('Configuration loaded');
        } catch (error) {
            this.showError('Failed to load configuration');
        }
    }

    camelToKebab(str) {
        return str.replace(/([a-z0-9]|(?=[A-Z]))([A-Z])/g, '$1-$2').toLowerCase();
    }

    switchConfigTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.config-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabName);
        });

        // Update tab content
        document.querySelectorAll('.config-tab-content').forEach(content => {
            content.classList.toggle('active', content.id === `${tabName}-tab`);
        });
    }

    async viewRaffle(raffleId) {
        try {
            const response = await fetch(`/api/raffles/${raffleId}`);
            const raffle = await response.json();

            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.style.display = 'block';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>Raffle Details: ${raffle.prize}</h2>
                        <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <p><strong>Description:</strong> ${raffle.description || 'N/A'}</p>
                        <p><strong>Status:</strong> ${raffle.isActive ? 'Active' : 'Ended'}</p>
                        <p><strong>Participants:</strong> ${Object.keys(raffle.participants).length}</p>
                        <p><strong>Total Tickets:</strong> ${Object.values(raffle.participants).reduce((a, b) => a + b, 0)}</p>
                        <p><strong>End Time:</strong> ${new Date(raffle.endTime * 1000).toLocaleString()}</p>
                        <p><strong>Winners:</strong> ${raffle.maxWinners}</p>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        } catch (error) {
            this.showError('Failed to load raffle details');
        }
    }

    async endRaffle(raffleId) {
        if (confirm('Are you sure you want to end this raffle?')) {
            try {
                const response = await fetch(`/api/raffles/${raffleId}/end`, { method: 'POST' });
                if (response.ok) {
                    this.showSuccess('Raffle ended successfully');
                    this.loadRafflesData();
                } else {
                    this.showError('Failed to end raffle');
                }
            } catch (error) {
                this.showError('Failed to end raffle');
            }
        }
    }

    async viewUserDetails(userId) {
        try {
            const response = await fetch(`/api/users/${userId}`);
            const user = await response.json();

            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.style.display = 'block';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>User Details: ${userId}</h2>
                        <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <p><strong>Total Tickets:</strong> ${user.tickets.total}</p>
                        <p><strong>Chat Rewards:</strong> ${user.tickets.chatRewards || 0}</p>
                        <p><strong>Messages:</strong> ${user.stats.chatMessages || 0}</p>
                        <p><strong>Last Activity:</strong> ${user.stats.lastActivity ? new Date(user.stats.lastActivity).toLocaleString() : 'Never'}</p>
                        <p><strong>Tickets Earned:</strong> ${user.stats.ticketsEarned || 0}</p>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        } catch (error) {
            this.showError('Failed to load user details');
        }
    }

    viewRaffle(raffleId) {
        // View detailed raffle information
        alert(`Viewing raffle: ${raffleId}`);
        // TODO: Implement detailed raffle view modal
    }

    viewUserDetails(userId) {
        // View detailed user information
        alert(`Viewing user details: ${userId}`);
        // TODO: Implement detailed user view modal
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background: ${type === 'error' ? '#e74c3c' : type === 'success' ? '#27ae60' : '#3498db'};
            color: white;
            border-radius: 5px;
            z-index: 10000;
        `;
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 3000);
    }
}

// Initialize dashboard when page loads
let dashboard;
document.addEventListener('DOMContentLoaded', () => {
    dashboard = new Dashboard();
    window.dashboard = dashboard; // Make it globally accessible
    dashboard.init();
});