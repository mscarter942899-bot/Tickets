
/**
 * /remove-tickets command - Administrator only command to remove tickets from users or raffles
 */

const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { COLORS, EMOJIS } = require('../config/constants.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove-tickets')
        .setDescription('🔧 Admin: Remove tickets from a user or raffle')
        .addSubcommand(subcommand =>
            subcommand
                .setName('from-user')
                .setDescription('Remove tickets from a user\'s inventory')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('The user to remove tickets from')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Number of tickets to remove (1-100)')
                        .setRequired(true)
                        .setMinValue(1)
                        .setMaxValue(100))
                .addStringOption(option =>
                    option.setName('reason')
                        .setDescription('Reason for removing tickets')
                        .setRequired(false)
                        .setMaxLength(200)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('from-raffle')
                .setDescription('Remove a user\'s tickets from a specific raffle')
                .addStringOption(option =>
                    option.setName('raffle-id')
                        .setDescription('The raffle ID to remove tickets from')
                        .setRequired(true))
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('The user whose tickets to remove from the raffle')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Number of tickets to remove (0 = all tickets)')
                        .setRequired(false)
                        .setMinValue(0)
                        .setMaxValue(100))
                .addStringOption(option =>
                    option.setName('reason')
                        .setDescription('Reason for removing tickets')
                        .setRequired(false)
                        .setMaxLength(200)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction, client) {
        // Double-check admin permissions
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Insufficient Permissions`)
                .setDescription('You need **Manage Server** permissions to use this command.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        const subcommand = interaction.options.getSubcommand();
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'Administrator action';
        const adminUser = interaction.user;

        try {
            // Validate target user
            if (targetUser.bot) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Invalid Target`)
                    .setDescription('You cannot remove tickets from bots.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                return await interaction.reply({ embeds: [embed], ephemeral: true });
            }

            if (subcommand === 'from-user') {
                await this.handleRemoveFromUser(interaction, client, targetUser, adminUser, reason);
            } else if (subcommand === 'from-raffle') {
                await this.handleRemoveFromRaffle(interaction, client, targetUser, adminUser, reason);
            }

        } catch (error) {
            console.error(`❌ Error in remove-tickets command:`, error);

            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Command Error`)
                .setDescription('An unexpected error occurred while removing tickets.')
                .setColor(COLORS.ERROR)
                .addFields({
                    name: 'What happened?',
                    value: 'A technical issue prevented the ticket removal from being processed.',
                    inline: false
                },
                {
                    name: 'What to do?',
                    value: '• Try the command again\n• Check user permissions\n• Contact bot administrators if issue persists',
                    inline: false
                })
                .setTimestamp();

            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },

    async handleRemoveFromUser(interaction, client, targetUser, adminUser, reason) {
        const amount = interaction.options.getInteger('amount');

        // Get user's current stats before removal
        const beforeStats = client.ticketManager.getTicketStats(targetUser.id);
        const userData = client.storage.getUserTickets(targetUser.id);

        if (userData.total === 0) {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} No Tickets to Remove`)
                .setDescription(`${targetUser} has no tickets in their inventory.`)
                .setColor(COLORS.ERROR)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        if (amount > userData.total) {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Insufficient Tickets`)
                .setDescription(`${targetUser} only has **${userData.total}** ticket${userData.total !== 1 ? 's' : ''}, but you tried to remove **${amount}**.`)
                .setColor(COLORS.ERROR)
                .addFields({
                    name: 'User\'s Current Balance',
                    value: `**Total:** ${userData.total}\n**Available:** ${beforeStats.available}\n**In Active Raffles:** ${beforeStats.inActiveRaffles}`,
                    inline: false
                })
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Remove tickets from user's inventory
        const originalTotal = userData.total;
        userData.total = Math.max(0, userData.total - amount);
        
        // Track admin removals
        if (!userData.adminRemoved) userData.adminRemoved = 0;
        userData.adminRemoved += amount;

        client.storage.setUserTickets(targetUser.id, userData);

        // Get updated stats
        const afterStats = client.ticketManager.getTicketStats(targetUser.id);

        // Create success embed
        const embed = new EmbedBuilder()
            .setTitle(`${EMOJIS.SUCCESS} Tickets Removed Successfully!`)
            .setColor(COLORS.SUCCESS)
            .setTimestamp();

        let description = `${EMOJIS.TICKET} **${amount} ticket${amount !== 1 ? 's' : ''}** removed from ${targetUser}'s inventory`;
        if (reason !== 'Administrator action') {
            description += `\n\n**Reason:** ${reason}`;
        }
        embed.setDescription(description);

        // User's updated balance
        embed.addFields(
            {
                name: `${EMOJIS.STATS} ${targetUser.displayName}'s Updated Balance`,
                value: `**Total:** ${originalTotal} → **${afterStats.total}**\n**Available:** ${beforeStats.available} → **${afterStats.available}**\n**In Active Raffles:** ${afterStats.inActiveRaffles}`,
                inline: true
            },
            {
                name: `${EMOJIS.WARNING} Removal Details`,
                value: `**Amount:** ${amount} tickets\n**Removed by:** ${adminUser.displayName}\n**Total Removed by Admins:** ${userData.adminRemoved}`,
                inline: true
            }
        );

        embed.setFooter({
            text: `Admin Command • Ticket removal • Raffle Bot`,
            iconURL: adminUser.displayAvatarURL()
        });

        await interaction.reply({ embeds: [embed] });

        // Log the admin action
        console.log(`🔧 Admin ${adminUser.tag} (${adminUser.id}) removed ${amount} tickets from ${targetUser.tag} (${targetUser.id}). Reason: "${reason}"`);

        // Save data
        await client.storage.saveData();
    },

    async handleRemoveFromRaffle(interaction, client, targetUser, adminUser, reason) {
        const raffleId = interaction.options.getString('raffle-id');
        const amount = interaction.options.getInteger('amount') || 0; // 0 means remove all

        // Get raffle data
        const raffle = client.storage.getRaffle(raffleId);
        if (!raffle) {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Raffle Not Found`)
                .setDescription(`No raffle found with ID: \`${raffleId}\``)
                .setColor(COLORS.ERROR)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Check if user has tickets in this raffle
        const userTicketsInRaffle = raffle.participants[targetUser.id] || 0;
        if (userTicketsInRaffle === 0) {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} No Tickets in Raffle`)
                .setDescription(`${targetUser} has no tickets in raffle **${raffle.prize}**.`)
                .setColor(COLORS.ERROR)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Calculate actual removal amount
        const ticketsToRemove = amount === 0 ? userTicketsInRaffle : Math.min(amount, userTicketsInRaffle);
        const originalTicketsInRaffle = userTicketsInRaffle;

        // Remove tickets from raffle
        if (ticketsToRemove >= userTicketsInRaffle) {
            delete raffle.participants[targetUser.id];
        } else {
            raffle.participants[targetUser.id] -= ticketsToRemove;
        }

        // Refund tickets to user's inventory
        const userData = client.storage.getUserTickets(targetUser.id);
        const originalTotal = userData.total;
        userData.total += ticketsToRemove;

        // Clean up spent tickets tracking for this raffle
        if (userData.spentTickets && userData.spentTickets[raffleId]) {
            userData.spentTickets[raffleId] = Math.max(0, userData.spentTickets[raffleId] - ticketsToRemove);
            if (userData.spentTickets[raffleId] === 0) {
                delete userData.spentTickets[raffleId];
            }
        }

        // Save changes
        client.storage.setRaffle(raffleId, raffle);
        client.storage.setUserTickets(targetUser.id, userData);

        // Get updated stats
        const afterStats = client.ticketManager.getTicketStats(targetUser.id);
        const remainingInRaffle = raffle.participants[targetUser.id] || 0;

        // Create success embed
        const embed = new EmbedBuilder()
            .setTitle(`${EMOJIS.SUCCESS} Tickets Removed from Raffle!`)
            .setColor(COLORS.SUCCESS)
            .setTimestamp();

        let description = `${EMOJIS.TICKET} **${ticketsToRemove} ticket${ticketsToRemove !== 1 ? 's' : ''}** removed from ${targetUser} in raffle **${raffle.prize}**`;
        if (reason !== 'Administrator action') {
            description += `\n\n**Reason:** ${reason}`;
        }
        embed.setDescription(description);

        embed.addFields(
            {
                name: `${EMOJIS.RAFFLE} Raffle Participation`,
                value: `**Raffle:** ${raffle.prize}\n**Before:** ${originalTicketsInRaffle} tickets\n**After:** ${remainingInRaffle} tickets\n**Removed:** ${ticketsToRemove} tickets`,
                inline: true
            },
            {
                name: `${EMOJIS.STATS} User's Updated Balance`,
                value: `**Total:** ${originalTotal} → **${userData.total}**\n**Available:** ${afterStats.available}\n**In Active Raffles:** ${afterStats.inActiveRaffles}`,
                inline: true
            },
            {
                name: `${EMOJIS.WARNING} Removal Details`,
                value: `**Tickets Refunded:** ${ticketsToRemove}\n**Removed by:** ${adminUser.displayName}\n**Raffle Status:** ${raffle.isActive ? 'Active' : 'Ended'}`,
                inline: false
            }
        );

        embed.setFooter({
            text: `Admin Command • Raffle ticket removal • Raffle Bot`,
            iconURL: adminUser.displayAvatarURL()
        });

        await interaction.reply({ embeds: [embed] });

        // Log the admin action
        console.log(`🔧 Admin ${adminUser.tag} (${adminUser.id}) removed ${ticketsToRemove} tickets from ${targetUser.tag} (${targetUser.id}) in raffle ${raffleId}. Reason: "${reason}"`);

        // Save data
        await client.storage.saveData();

        // Optional: Send a DM notification to the user
        try {
            const dmEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.WARNING} Tickets Removed from Raffle`)
                .setDescription(`**${ticketsToRemove} ticket${ticketsToRemove !== 1 ? 's' : ''}** were removed from your entry in the raffle **${raffle.prize}** in **${interaction.guild.name}**.`)
                .setColor(COLORS.WARNING)
                .addFields(
                    {
                        name: 'Details',
                        value: `**Reason:** ${reason}\n**Tickets Refunded:** ${ticketsToRemove}\n**Remaining in Raffle:** ${remainingInRaffle}`,
                        inline: false
                    },
                    {
                        name: 'What\'s Next?',
                        value: `Your tickets have been refunded to your inventory. Use \`/my-tickets\` to check your balance.`,
                        inline: false
                    }
                )
                .setFooter({
                    text: `${interaction.guild.name} • Raffle Bot`,
                    iconURL: interaction.guild.iconURL()
                })
                .setTimestamp();

            await targetUser.send({ embeds: [dmEmbed] });
            console.log(`📨 Sent DM notification to ${targetUser.tag} about ticket removal from raffle`);

        } catch (dmError) {
            console.log(`📨 Could not DM ${targetUser.tag} about ticket removal (DMs disabled)`);
        }
    }
};
