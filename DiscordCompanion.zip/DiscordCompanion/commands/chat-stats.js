/**
 * /chat-stats command - Show user's chat activity stats and tickets earned from chat
 */

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS, EMOJIS } = require('../config/constants.js');
const { TimeFormatter } = require('../utils/time-formatter.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('chat-stats')
        .setDescription('Show your chat activity stats and tickets earned from chat participation'),

    async execute(interaction, client) {
        try {
            const userId = interaction.user.id;
            
            // Get user stats and ticket data
            const userStats = client.storage.getUserStats(userId);
            const ticketData = client.storage.getUserTickets(userId);
            const ticketStats = client.ticketManager.getTicketStats(userId);

            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.SPARKLES} Your Chat Activity Stats`)
                .setColor(COLORS.INFO)
                .setThumbnail(interaction.user.displayAvatarURL())
                .setTimestamp();

            // Chat activity overview
            const totalMessages = userStats.chatMessages || 0;
            const ticketsFromChat = userStats.ticketsEarned || 0;
            const lastActivity = userStats.lastActivity || 0;

            let activityText = `${EMOJIS.STATS} **Total Messages:** ${totalMessages.toLocaleString()}\n`;
            activityText += `${EMOJIS.TICKET} **Tickets Earned:** ${ticketsFromChat}\n`;
            
            if (lastActivity > 0) {
                activityText += `${EMOJIS.TIME} **Last Active:** ${TimeFormatter.discordTimestamp(Math.floor(lastActivity / 1000), 'R')}`;
            } else {
                activityText += `${EMOJIS.TIME} **Last Active:** Never recorded`;
            }

            embed.addFields({
                name: `${EMOJIS.SPARKLES} Activity Overview`,
                value: activityText,
                inline: true
            });

            // Ticket earning progress
            const messagesForNextTicket = 50;
            const messagesSinceLastTicket = totalMessages - (userStats.lastTicketMessage || 0);
            const messagesNeeded = Math.max(0, messagesForNextTicket - messagesSinceLastTicket);
            
            let progressText = `${EMOJIS.TICKET} **Chat Tickets Earned:** ${ticketsFromChat}\n`;
            progressText += `${EMOJIS.STATS} **Messages Since Last Ticket:** ${messagesSinceLastTicket}\n`;
            
            if (messagesNeeded > 0) {
                progressText += `${EMOJIS.TIME} **Messages to Next Ticket:** ${messagesNeeded}`;
            } else {
                progressText += `${EMOJIS.SUCCESS} **Ready for Next Ticket!** (chat more to earn)`;
            }

            embed.addFields({
                name: `${EMOJIS.TICKET} Ticket Progress`,
                value: progressText,
                inline: true
            });

            // Activity level assessment
            let activityLevel = 'New Member';
            let activityColor = COLORS.NEUTRAL;
            let activityEmoji = EMOJIS.HELP;

            if (totalMessages >= 1000) {
                activityLevel = 'Super Active';
                activityColor = COLORS.SUCCESS;
                activityEmoji = EMOJIS.CROWN;
            } else if (totalMessages >= 500) {
                activityLevel = 'Very Active';
                activityColor = COLORS.SUCCESS;
                activityEmoji = EMOJIS.STAR;
            } else if (totalMessages >= 200) {
                activityLevel = 'Active';
                activityColor = COLORS.INFO;
                activityEmoji = EMOJIS.SPARKLES;
            } else if (totalMessages >= 50) {
                activityLevel = 'Regular';
                activityColor = COLORS.WARNING;
                activityEmoji = EMOJIS.TICKET;
            }

            embed.setColor(activityColor);

            embed.addFields({
                name: `${activityEmoji} Activity Level`,
                value: `**${activityLevel}**\nBased on ${totalMessages} total messages`,
                inline: true
            });

            // Efficiency stats
            if (totalMessages > 0) {
                const efficiency = ticketsFromChat > 0 ? (totalMessages / ticketsFromChat).toFixed(1) : 'N/A';
                const chatTicketPercentage = ticketStats.total > 0 ? 
                    Math.round((ticketsFromChat / ticketStats.total) * 100) : 0;

                let efficiencyText = `${EMOJIS.STATS} **Messages per Ticket:** ${efficiency}\n`;
                efficiencyText += `${EMOJIS.TICKET} **Chat Tickets vs Total:** ${chatTicketPercentage}%\n`;
                efficiencyText += `${EMOJIS.SPARKLES} **Efficiency Rating:** ${this.getEfficiencyRating(efficiency)}`;

                embed.addFields({
                    name: `${EMOJIS.STATS} Efficiency Stats`,
                    value: efficiencyText,
                    inline: false
                });
            }

            // Milestones and achievements
            const milestones = this.calculateMilestones(totalMessages, ticketsFromChat);
            if (milestones.length > 0) {
                const milestonesText = milestones.join('\n');
                embed.addFields({
                    name: `${EMOJIS.STAR} Achievements`,
                    value: milestonesText,
                    inline: false
                });
            }

            // Next goals
            const nextGoals = this.getNextGoals(totalMessages, ticketsFromChat);
            if (nextGoals.length > 0) {
                const goalsText = nextGoals.join('\n');
                embed.addFields({
                    name: `${EMOJIS.TIME} Next Goals`,
                    value: goalsText,
                    inline: false
                });
            }

            // Tips for earning more tickets
            let tipsText = `${EMOJIS.HELP} **How to Earn More Chat Tickets:**\n`;
            tipsText += `• Send messages in different channels\n`;
            tipsText += `• Participate in conversations naturally\n`;
            tipsText += `• Join voice chats and server events\n`;
            tipsText += `• Help other members with questions\n`;
            tipsText += `• Share content and reactions\n\n`;
            tipsText += `${EMOJIS.TICKET} **Don't forget:** Use \`/earn\` every 30 minutes for guaranteed tickets!`;

            embed.addFields({
                name: `${EMOJIS.HELP} Tips & Strategies`,
                value: tipsText,
                inline: false
            });

            // Server ranking (simplified - could be expanded)
            embed.addFields({
                name: `${EMOJIS.CROWN} Your Rank`,
                value: `Based on your activity level, you're a **${activityLevel}** member!\nKeep chatting to climb the ranks!`,
                inline: true
            });

            embed.setFooter({ 
                text: `Chat stats update in real-time • Stay active to earn more tickets!`,
                iconURL: interaction.user.displayAvatarURL()
            });

            await interaction.reply({ embeds: [embed], ephemeral: true });

            // Log the stats check
            console.log(`📊 ${interaction.user.tag} checked chat stats: ${totalMessages} messages, ${ticketsFromChat} chat tickets`);

        } catch (error) {
            console.error('❌ Error in /chat-stats command:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Error`)
                .setDescription('An error occurred while fetching your chat statistics. Please try again.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    },

    /**
     * Get efficiency rating based on messages per ticket
     * @param {string|number} efficiency - Messages per ticket ratio
     * @returns {string} - Efficiency rating
     */
    getEfficiencyRating(efficiency) {
        if (efficiency === 'N/A') return 'No data yet';
        
        const ratio = parseFloat(efficiency);
        if (ratio <= 30) return 'Excellent 🌟';
        if (ratio <= 40) return 'Great 🎯';
        if (ratio <= 50) return 'Good 👍';
        if (ratio <= 60) return 'Fair 📈';
        return 'Improving 📊';
    },

    /**
     * Calculate achieved milestones
     * @param {number} messages - Total messages
     * @param {number} tickets - Tickets from chat
     * @returns {Array} - Array of milestone strings
     */
    calculateMilestones(messages, tickets) {
        const milestones = [];
        
        // Message milestones
        if (messages >= 1000) milestones.push(`${EMOJIS.CROWN} 1,000+ Messages Champion`);
        else if (messages >= 500) milestones.push(`${EMOJIS.STAR} 500+ Messages Veteran`);
        else if (messages >= 100) milestones.push(`${EMOJIS.SPARKLES} 100+ Messages Regular`);
        else if (messages >= 50) milestones.push(`${EMOJIS.TICKET} 50+ Messages Starter`);
        
        // Ticket milestones
        if (tickets >= 50) milestones.push(`${EMOJIS.MONEY} 50+ Chat Tickets Master`);
        else if (tickets >= 20) milestones.push(`${EMOJIS.TICKET} 20+ Chat Tickets Collector`);
        else if (tickets >= 10) milestones.push(`${EMOJIS.SUCCESS} 10+ Chat Tickets Earner`);
        else if (tickets >= 1) milestones.push(`${EMOJIS.SPARKLES} First Chat Ticket`);
        
        return milestones;
    },

    /**
     * Get next goals for the user
     * @param {number} messages - Total messages
     * @param {number} tickets - Tickets from chat
     * @returns {Array} - Array of goal strings
     */
    getNextGoals(messages, tickets) {
        const goals = [];
        
        // Message goals
        if (messages < 50) goals.push(`${EMOJIS.TIME} Reach 50 messages for Regular status`);
        else if (messages < 100) goals.push(`${EMOJIS.TIME} Reach 100 messages for milestone`);
        else if (messages < 200) goals.push(`${EMOJIS.TIME} Reach 200 messages for Active status`);
        else if (messages < 500) goals.push(`${EMOJIS.TIME} Reach 500 messages for Veteran status`);
        else if (messages < 1000) goals.push(`${EMOJIS.TIME} Reach 1,000 messages for Champion status`);
        
        // Ticket goals
        if (tickets < 1) goals.push(`${EMOJIS.TICKET} Earn your first chat ticket`);
        else if (tickets < 10) goals.push(`${EMOJIS.TICKET} Reach 10 chat tickets`);
        else if (tickets < 20) goals.push(`${EMOJIS.TICKET} Reach 20 chat tickets`);
        else if (tickets < 50) goals.push(`${EMOJIS.TICKET} Reach 50 chat tickets`);
        
        return goals.slice(0, 3); // Limit to 3 goals
    }
};
