/**
 * /earn command - Claim 1 free raffle ticket every 30 minutes
 */

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS, EMOJIS } = require('../config/constants.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('earn')
        .setDescription('Claim 1 free raffle ticket (30 minute cooldown)'),

    async execute(interaction, client) {
        const userId = interaction.user.id;
        
        try {
            // Check cooldown
            const cooldownCheck = client.ticketManager.canEarnTicket(userId);
            
            if (!cooldownCheck.canEarn) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.TIME} Ticket Earning Cooldown`)
                    .setDescription(`You can earn your next free ticket in:\n**${cooldownCheck.timeRemaining}**`)
                    .setColor(COLORS.WARNING)
                    .addFields({
                        name: `${EMOJIS.HELP} How to Get More Tickets`,
                        value: `• Use \`/earn\` every 30 minutes\n• Participate in chat conversations\n• Join server events and giveaways`,
                        inline: false
                    })
                    .setFooter({ text: 'Tip: Stay active in the server to earn bonus tickets!' })
                    .setTimestamp();

                return await interaction.reply({ embeds: [embed], ephemeral: true });
            }

            // Award ticket with built-in cooldown protection
            const awardResult = client.ticketManager.awardTicket(userId, 1, 'earn');
            
            if (!awardResult.success) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Earn Failed`)
                    .setDescription(awardResult.message || 'Could not award ticket.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                return await interaction.reply({ embeds: [embed], ephemeral: true });
            }
            
            // Get updated stats
            const stats = client.ticketManager.getTicketStats(userId);

            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.SUCCESS} Ticket Earned!`)
                .setDescription(`${EMOJIS.TICKET} You earned **1 free ticket**!`)
                .setColor(COLORS.SUCCESS)
                .addFields(
                    {
                        name: `${EMOJIS.STATS} Your Ticket Balance`,
                        value: `**Total:** ${stats.total}\n**Available:** ${stats.available}\n**In Active Raffles:** ${stats.inActiveRaffles}`,
                        inline: true
                    },
                    {
                        name: `${EMOJIS.TIME} Next Free Ticket`,
                        value: `Available in **30 minutes**\nUse \`/earn\` again after cooldown`,
                        inline: true
                    }
                )
                .setFooter({ 
                    text: `Use /my-tickets for detailed stats • Use /raffle-status to see active raffles`,
                    iconURL: interaction.user.displayAvatarURL()
                })
                .setTimestamp();

            // Add bonus tip for new users
            if (stats.total <= 5) {
                embed.addFields({
                    name: `${EMOJIS.SPARKLES} New User Tip`,
                    value: `Check out \`/raffle-status\` to see active raffles you can enter!`,
                    inline: false
                });
            }

            await interaction.reply({ embeds: [embed], ephemeral: true });

            // Log the ticket earning
            console.log(`🎟️ ${interaction.user.tag} (${userId}) earned a ticket via /earn command`);

        } catch (error) {
            console.error('❌ Error in /earn command:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Error`)
                .setDescription('An error occurred while processing your ticket claim. Please try again.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
