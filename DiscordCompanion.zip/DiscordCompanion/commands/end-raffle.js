/**
 * /end-raffle command - Staff only command to manually end raffles
 */

const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { COLORS, EMOJIS } = require('../config/constants.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('end-raffle')
        .setDescription('Manually end a raffle (Staff Only)')
        .addStringOption(option =>
            option.setName('raffle-id')
                .setDescription('Raffle ID to end (leave empty to end the latest active raffle)')
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction, client) {
        try {
            // Check permissions
            if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Permission Denied`)
                    .setDescription('You need the **Manage Server** permission to end raffles.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                return await interaction.reply({ embeds: [embed], ephemeral: true });
            }

            const raffleId = interaction.options.getString('raffle-id');
            let targetRaffle = null;

            // Find target raffle
            if (raffleId) {
                // End specific raffle by ID
                targetRaffle = client.storage.getRaffle(raffleId);
                
                if (!targetRaffle) {
                    const embed = new EmbedBuilder()
                        .setTitle(`${EMOJIS.ERROR} Raffle Not Found`)
                        .setDescription(`No raffle found with ID: \`${raffleId}\``)
                        .setColor(COLORS.ERROR)
                        .addFields({
                            name: `${EMOJIS.HELP} Need Help?`,
                            value: `Use \`/raffle-status\` to see all active raffles and their IDs.`,
                            inline: false
                        })
                        .setTimestamp();

                    return await interaction.reply({ embeds: [embed], ephemeral: true });
                }

                if (!targetRaffle.isActive) {
                    const embed = new EmbedBuilder()
                        .setTitle(`${EMOJIS.WARNING} Raffle Already Ended`)
                        .setDescription(`The raffle \`${raffleId}\` has already ended.`)
                        .setColor(COLORS.WARNING)
                        .setTimestamp();

                    return await interaction.reply({ embeds: [embed], ephemeral: true });
                }

            } else {
                // Find latest active raffle in this guild
                const guildRaffles = client.raffleManager.getGuildActiveRaffles(interaction.guild.id);
                
                if (guildRaffles.length === 0) {
                    const embed = new EmbedBuilder()
                        .setTitle(`${EMOJIS.WARNING} No Active Raffles`)
                        .setDescription('There are no active raffles in this server to end.')
                        .setColor(COLORS.WARNING)
                        .addFields({
                            name: `${EMOJIS.HELP} Need to Create a Raffle?`,
                            value: `Use \`/create-raffle\` to start a new raffle.`,
                            inline: false
                        })
                        .setTimestamp();

                    return await interaction.reply({ embeds: [embed], ephemeral: true });
                }

                // Get the most recent active raffle
                targetRaffle = guildRaffles.sort((a, b) => b.startTime - a.startTime)[0];
            }

            // Defer reply as ending might take time
            await interaction.deferReply();

            try {
                // End the raffle
                const result = await client.raffleManager.endRaffle(targetRaffle.id);

                if (!result.success) {
                    const embed = new EmbedBuilder()
                        .setTitle(`${EMOJIS.ERROR} Failed to End Raffle`)
                        .setDescription(result.message || 'An error occurred while ending the raffle.')
                        .setColor(COLORS.ERROR)
                        .setTimestamp();

                    return await interaction.editReply({ embeds: [embed] });
                }

                // Create winner announcement
                const winnerEmbed = client.raffleManager.createWinnerEmbed(result.raffle, result.winners);
                
                // Send winner announcement in the same channel
                await interaction.followUp({ embeds: [winnerEmbed] });

                // Send confirmation to staff member
                const confirmationEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.SUCCESS} Raffle Ended Successfully`)
                    .setDescription(`The raffle for **${result.raffle.prize}** has been manually ended.`)
                    .setColor(COLORS.SUCCESS)
                    .addFields(
                        {
                            name: `${EMOJIS.STATS} Results`,
                            value: `**Winners:** ${result.winners.length}\n**Participants:** ${Object.keys(result.raffle.participants).length}\n**Total Tickets:** ${Object.values(result.raffle.participants).reduce((sum, tickets) => sum + tickets, 0)}`,
                            inline: true
                        },
                        {
                            name: `${EMOJIS.RAFFLE} Raffle Info`,
                            value: `**ID:** \`${result.raffle.id}\`\n**Creator:** <@${result.raffle.creatorId}>\n**Ended By:** <@${interaction.user.id}>`,
                            inline: true
                        }
                    )
                    .setFooter({ 
                        text: `Raffle ended manually by ${interaction.user.tag}`,
                        iconURL: interaction.user.displayAvatarURL()
                    })
                    .setTimestamp();

                await interaction.editReply({ embeds: [confirmationEmbed] });

                // Update original raffle message if possible
                try {
                    const channel = await client.channels.fetch(result.raffle.channelId);
                    if (channel && result.raffle.messageId) {
                        const message = await channel.messages.fetch(result.raffle.messageId);
                        if (message) {
                            const updatedEmbed = client.raffleManager.createRaffleEmbed(result.raffle, Math.floor(Date.now() / 1000));
                            const updatedButtons = client.raffleManager.createRaffleButtons(result.raffle, Math.floor(Date.now() / 1000));

                            await message.edit({
                                embeds: [updatedEmbed],
                                components: [updatedButtons]
                            });
                        }
                    }
                } catch (updateError) {
                    console.error('❌ Error updating original raffle message:', updateError);
                }

                // Log the manual ending
                console.log(`🏁 ${interaction.user.tag} manually ended raffle ${result.raffle.id} with ${result.winners.length} winners`);

            } catch (endError) {
                console.error('❌ Error ending raffle:', endError);
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Error Ending Raffle`)
                    .setDescription('An unexpected error occurred while ending the raffle. Please try again.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                await interaction.editReply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('❌ Error in /end-raffle command:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Command Error`)
                .setDescription('An unexpected error occurred. Please try again.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            if (interaction.deferred) {
                await interaction.editReply({ embeds: [errorEmbed] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    }
};
