/**
 * /raffle-status command - Show all active raffles with live countdown timers
 */

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS, EMOJIS } = require('../config/constants.js');
const { TimeFormatter } = require('../utils/time-formatter.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('raffle-status')
        .setDescription('Show all active raffles with live countdown timers and entry stats'),

    async execute(interaction, client) {
        try {
            await interaction.deferReply();

            // Get all active raffles for this guild
            const guildRaffles = client.raffleManager.getGuildActiveRaffles(interaction.guild.id);
            const currentTime = Math.floor(Date.now() / 1000);

            if (guildRaffles.length === 0) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.RAFFLE} Active Raffles`)
                    .setDescription(`${EMOJIS.WARNING} No active raffles found in this server.`)
                    .setColor(COLORS.NEUTRAL)
                    .addFields({
                        name: `${EMOJIS.HELP} Want to Start a Raffle?`,
                        value: `Staff members can use \`/create-raffle\` to create new raffles.\nUse \`/earn\` to get free tickets every 30 minutes!`,
                        inline: false
                    })
                    .setFooter({ 
                        text: `Use /my-tickets to check your ticket balance`,
                        iconURL: interaction.user.displayAvatarURL()
                    })
                    .setTimestamp();

                return await interaction.editReply({ embeds: [embed] });
            }

            // Sort raffles by end time (ending soonest first)
            const sortedRaffles = guildRaffles.sort((a, b) => a.endTime - b.endTime);

            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.RAFFLE} Active Raffles (${guildRaffles.length})`)
                .setColor(COLORS.RAFFLE)
                .setTimestamp();

            let description = `Here are all the active raffles in **${interaction.guild.name}**:\n\n`;

            // Add each raffle to the embed
            for (let i = 0; i < Math.min(sortedRaffles.length, 10); i++) { // Limit to 10 raffles
                const raffle = sortedRaffles[i];
                const timeRemaining = Math.max(0, raffle.endTime - currentTime);
                const participantCount = Object.keys(raffle.participants).length;
                const totalTickets = Object.values(raffle.participants).reduce((sum, tickets) => sum + tickets, 0);
                
                // Get user's participation in this raffle
                const userTicketsInRaffle = raffle.participants[interaction.user.id] || 0;
                const winProbability = userTicketsInRaffle > 0 ? 
                    client.raffleManager.calculateWinProbability(raffle, interaction.user.id) : 0;

                // Status emoji based on time remaining
                const statusEmoji = TimeFormatter.getStatusEmoji(timeRemaining);
                
                let raffleInfo = `${statusEmoji} **${raffle.prize}**\n`;
                raffleInfo += `${EMOJIS.TIME} **Ends:** ${TimeFormatter.formatCountdown(timeRemaining)} (${TimeFormatter.discordTimestamp(raffle.endTime, 'R')})\n`;
                raffleInfo += `${EMOJIS.STATS} **Participants:** ${participantCount} (${totalTickets} tickets)\n`;
                raffleInfo += `${EMOJIS.WINNER} **Winners:** ${raffle.winners}\n`;
                
                if (userTicketsInRaffle > 0) {
                    raffleInfo += `${EMOJIS.TICKET} **Your Entry:** ${userTicketsInRaffle} tickets (${winProbability}% chance)\n`;
                }
                
                raffleInfo += `${EMOJIS.RAFFLE} **ID:** \`${raffle.id}\``;

                embed.addFields({
                    name: `${i + 1}. ${raffle.prize}`,
                    value: raffleInfo,
                    inline: false
                });
            }

            // Add summary information
            const userStats = client.ticketManager.getTicketStats(interaction.user.id);
            let totalUserEntries = 0;
            let totalUserTicketsInRaffles = 0;

            for (const raffle of sortedRaffles) {
                const userTickets = raffle.participants[interaction.user.id] || 0;
                if (userTickets > 0) {
                    totalUserEntries++;
                    totalUserTicketsInRaffles += userTickets;
                }
            }

            embed.addFields({
                name: `${EMOJIS.STATS} Your Summary`,
                value: `**Available Tickets:** ${userStats.available}\n**Tickets in Raffles:** ${totalUserTicketsInRaffles}\n**Active Entries:** ${totalUserEntries}/${guildRaffles.length}`,
                inline: true
            });

            // Add server raffle stats
            const totalParticipants = new Set();
            let totalTicketsAcrossRaffles = 0;
            
            for (const raffle of sortedRaffles) {
                Object.keys(raffle.participants).forEach(userId => totalParticipants.add(userId));
                totalTicketsAcrossRaffles += Object.values(raffle.participants).reduce((sum, tickets) => sum + tickets, 0);
            }

            embed.addFields({
                name: `${EMOJIS.SPARKLES} Server Stats`,
                value: `**Total Participants:** ${totalParticipants.size}\n**Total Tickets Entered:** ${totalTicketsAcrossRaffles}\n**Average per Raffle:** ${Math.round(totalTicketsAcrossRaffles / guildRaffles.length)} tickets`,
                inline: true
            });

            // If there are more than 10 raffles, mention it
            if (guildRaffles.length > 10) {
                embed.setFooter({ 
                    text: `Showing first 10 of ${guildRaffles.length} active raffles • Use /my-tickets for your detailed stats`,
                    iconURL: interaction.user.displayAvatarURL()
                });
            } else {
                embed.setFooter({ 
                    text: `Use /my-tickets for detailed stats • Use /earn for free tickets`,
                    iconURL: interaction.user.displayAvatarURL()
                });
            }

            // Add helpful tips for users with no entries
            if (totalUserEntries === 0 && userStats.available > 0) {
                embed.addFields({
                    name: `${EMOJIS.HELP} Ready to Enter?`,
                    value: `You have **${userStats.available} available tickets**! Click the "${EMOJIS.TICKET} Enter Raffle" button on any raffle above to participate.`,
                    inline: false
                });
            } else if (totalUserEntries === 0 && userStats.available === 0) {
                embed.addFields({
                    name: `${EMOJIS.HELP} Need Tickets?`,
                    value: `Use \`/earn\` to get a free ticket every 30 minutes, or stay active in chat to earn bonus tickets!`,
                    inline: false
                });
            }

            await interaction.editReply({ embeds: [embed] });

            // Log the status check
            console.log(`📊 ${interaction.user.tag} checked raffle status in ${interaction.guild.name} (${guildRaffles.length} active raffles)`);

        } catch (error) {
            console.error('❌ Error in /raffle-status command:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Error`)
                .setDescription('An error occurred while fetching raffle status. Please try again.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            if (interaction.deferred) {
                await interaction.editReply({ embeds: [errorEmbed] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    }
};
