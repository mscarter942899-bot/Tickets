/**
 * /give-tickets command - Administrator only command to award tickets to users
 */

const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { COLORS, EMOJIS } = require('../config/constants.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('give-tickets')
        .setDescription('🔧 Admin: Award tickets to a user')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to give tickets to')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Number of tickets to give (1-50)')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(50))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for giving tickets (optional)')
                .setRequired(false)
                .setMaxLength(200))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction, client) {
        // Double-check admin permissions
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Insufficient Permissions`)
                .setDescription('You need **Manage Server** permissions to use this command.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], flags: [4096] }); // ephemeral
        }

        const targetUser = interaction.options.getUser('user');
        const amount = interaction.options.getInteger('amount');
        const reason = interaction.options.getString('reason') || 'Administrator bonus';
        const adminUser = interaction.user;

        try {
            // Validate target user
            if (targetUser.bot) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Invalid Target`)
                    .setDescription('You cannot give tickets to bots.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                return await interaction.reply({ embeds: [embed], flags: [4096] });
            }

            // Get user's current stats before awarding
            const beforeStats = client.ticketManager.getTicketStats(targetUser.id);

            // Award tickets using the atomic system
            const awardResult = client.ticketManager.awardTicket(targetUser.id, amount, 'admin');

            if (!awardResult.success) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Award Failed`)
                    .setDescription(awardResult.message || 'Failed to award tickets.')
                    .setColor(COLORS.ERROR)
                    .addFields({
                        name: 'What to try?',
                        value: '• Wait a moment and try again\n• Check if the user exists in the server\n• Contact bot administrators if issue persists',
                        inline: false
                    })
                    .setTimestamp();

                return await interaction.reply({ embeds: [embed], flags: [4096] });
            }

            // Get updated stats
            const afterStats = client.ticketManager.getTicketStats(targetUser.id);

            // Create success embed
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.SUCCESS} Tickets Awarded Successfully!`)
                .setColor(COLORS.SUCCESS)
                .setTimestamp();

            let description = `${EMOJIS.TICKET} **${amount} ticket${amount !== 1 ? 's' : ''}** awarded to ${targetUser}`;
            if (reason !== 'Administrator bonus') {
                description += `\n\n**Reason:** ${reason}`;
            }
            embed.setDescription(description);

            // User's updated balance
            embed.addFields(
                {
                    name: `${EMOJIS.STATS} ${targetUser.displayName}'s Updated Balance`,
                    value: `**Total:** ${beforeStats.total} → **${afterStats.total}**\n**Available:** ${beforeStats.available} → **${afterStats.available}**\n**In Active Raffles:** ${afterStats.inActiveRaffles}`,
                    inline: true
                },
                {
                    name: `${EMOJIS.SPARKLES} Award Details`,
                    value: `**Amount:** ${amount} tickets\n**Source:** Administrator\n**Awarded by:** ${adminUser.displayName}`,
                    inline: true
                }
            );

            // Add helpful tips for new users
            if (afterStats.total <= 10) {
                embed.addFields({
                    name: `${EMOJIS.HELP} Getting Started`,
                    value: `${targetUser.displayName} can now:\n• Use \`/raffle-status\` to see active raffles\n• Use \`/my-tickets\` to check their balance\n• Enter raffles by clicking the 🎟️ button`,
                    inline: false
                });
            }

            embed.setFooter({
                text: `Admin Command • Use /my-tickets to check balances • Raffle Bot`,
                iconURL: adminUser.displayAvatarURL()
            });

            await interaction.reply({ embeds: [embed] });

            // Log the admin action
            console.log(`🔧 Admin ${adminUser.tag} (${adminUser.id}) gave ${amount} tickets to ${targetUser.tag} (${targetUser.id}). Reason: "${reason}"`);

            // Save data
            await client.storage.saveData();

            // Optional: Send a DM notification to the user (if they allow DMs)
            try {
                const dmEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.GIFT} You Received Tickets!`)
                    .setDescription(`You've been awarded **${amount} ticket${amount !== 1 ? 's' : ''}** in **${interaction.guild.name}**!`)
                    .setColor(COLORS.SUCCESS)
                    .addFields(
                        {
                            name: 'Details',
                            value: `**Amount:** ${amount} tickets\n**Reason:** ${reason}\n**Your Total:** ${afterStats.total} tickets`,
                            inline: false
                        },
                        {
                            name: 'What\'s Next?',
                            value: `Head back to the server and use \`/raffle-status\` to see active raffles you can enter!`,
                            inline: false
                        }
                    )
                    .setFooter({
                        text: `${interaction.guild.name} • Raffle Bot`,
                        iconURL: interaction.guild.iconURL()
                    })
                    .setTimestamp();

                await targetUser.send({ embeds: [dmEmbed] });
                console.log(`📨 Sent DM notification to ${targetUser.tag} about ticket award`);

            } catch (dmError) {
                // DM failed - user probably has DMs disabled, which is fine
                console.log(`📨 Could not DM ${targetUser.tag} about ticket award (DMs disabled)`);
            }

        } catch (error) {
            console.error(`❌ Error in give-tickets command:`, error);

            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Command Error`)
                .setDescription('An unexpected error occurred while awarding tickets.')
                .setColor(COLORS.ERROR)
                .addFields({
                    name: 'What happened?',
                    value: 'A technical issue prevented the ticket award from being processed.',
                    inline: false
                },
                {
                    name: 'What to do?',
                    value: '• Try the command again\n• Check user permissions\n• Contact bot administrators if issue persists',
                    inline: false
                })
                .setTimestamp();

            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [errorEmbed], flags: [4096] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], flags: [4096] });
            }
        }
    }
};