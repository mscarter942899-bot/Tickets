/**
 * /create-raffle command - Staff only command to create new raffles
 */

const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { COLORS, EMOJIS, RAFFLE, PERMISSIONS } = require('../config/constants.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('create-raffle')
        .setDescription('Create a new raffle (Staff Only)')
        .addStringOption(option =>
            option.setName('prize')
                .setDescription('The prize for the raffle')
                .setRequired(true)
                .setMaxLength(256)
        )
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Raffle duration (e.g. "30m", "2h", "tomorrow 3pm", "15:30")')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('winners')
                .setDescription('Number of winners (1-10)')
                .setMinValue(1)
                .setMaxValue(RAFFLE.MAX_WINNERS)
        )
        .addStringOption(option =>
            option.setName('image')
                .setDescription('Image URL for the raffle (optional)')
        )
        .addStringOption(option =>
            option.setName('description')
                .setDescription('Custom description for the raffle (optional)')
                .setMaxLength(1024)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction, client) {
        try {
            // Check permissions
            if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Permission Denied`)
                    .setDescription('You need the **Manage Server** permission to create raffles.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                return await interaction.reply({ embeds: [embed], ephemeral: true });
            }

            // Get command options
            const prize = interaction.options.getString('prize');
            const duration = interaction.options.getString('duration');
            const winners = interaction.options.getInteger('winners') || RAFFLE.DEFAULT_WINNERS;
            const image = interaction.options.getString('image');
            const description = interaction.options.getString('description');

            // Validate image URL if provided
            if (image && !this.isValidImageUrl(image)) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Invalid Image URL`)
                    .setDescription('Please provide a valid image URL (jpg, png, gif, webp).')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                return await interaction.reply({ embeds: [embed], ephemeral: true });
            }

            // Defer reply as raffle creation might take time
            await interaction.deferReply();

            try {
                // Create the raffle
                const raffle = await client.raffleManager.createRaffle({
                    guildId: interaction.guild.id,
                    channelId: interaction.channel.id,
                    creatorId: interaction.user.id,
                    prize,
                    duration,
                    winners,
                    image,
                    description
                });

                // Create raffle embed and buttons
                const raffleEmbed = client.raffleManager.createRaffleEmbed(raffle);
                const raffleButtons = client.raffleManager.createRaffleButtons(raffle);

                // Send the raffle message
                const raffleMessage = await interaction.followUp({
                    embeds: [raffleEmbed],
                    components: [raffleButtons]
                });

                // Update raffle with message ID
                raffle.messageId = raffleMessage.id;
                client.storage.setRaffle(raffle.id, raffle);

                // Send confirmation to creator
                const confirmationEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.SUCCESS} Raffle Created Successfully!`)
                    .setDescription(`Your raffle for **${prize}** has been created and is now active.`)
                    .setColor(COLORS.SUCCESS)
                    .addFields(
                        {
                            name: `${EMOJIS.RAFFLE} Raffle Details`,
                            value: `**Prize:** ${prize}\n**Winners:** ${winners}\n**Duration:** ${duration}`,
                            inline: true
                        },
                        {
                            name: `${EMOJIS.STATS} Management`,
                            value: `**Raffle ID:** \`${raffle.id}\`\n**End Time:** <t:${raffle.endTime}:F>\n**Relative:** <t:${raffle.endTime}:R>`,
                            inline: true
                        }
                    )
                    .setFooter({ 
                        text: `Use /end-raffle ${raffle.id} to end early • Use /raffle-status to monitor`,
                        iconURL: interaction.user.displayAvatarURL()
                    })
                    .setTimestamp();

                // Send confirmation as ephemeral message
                setTimeout(async () => {
                    try {
                        await interaction.followUp({ embeds: [confirmationEmbed], ephemeral: true });
                    } catch (error) {
                        console.error('❌ Error sending raffle confirmation:', error);
                    }
                }, 1000);

                // Log raffle creation
                console.log(`🎁 ${interaction.user.tag} created raffle ${raffle.id}: "${prize}" in ${interaction.guild.name}`);

            } catch (durationError) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Invalid Duration Format`)
                    .setDescription(`Could not parse duration: "${duration}"`)
                    .setColor(COLORS.ERROR)
                    .addFields({
                        name: `${EMOJIS.HELP} Supported Formats`,
                        value: `• **Simple:** \`30m\`, \`2h\`, \`120s\`\n• **Natural:** \`in 2 hours\`, \`in 30 minutes\`\n• **Specific:** \`15:30\`, \`3:45 PM\`\n• **Relative:** \`tomorrow\`, \`next friday\`\n• **Combined:** \`tomorrow 3pm\`, \`friday 15:30\``,
                        inline: false
                    })
                    .setFooter({ text: 'Examples: "30m", "2h", "tomorrow 3pm", "15:30"' })
                    .setTimestamp();

                return await interaction.editReply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('❌ Error in /create-raffle command:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Error Creating Raffle`)
                .setDescription('An unexpected error occurred while creating the raffle. Please try again.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            if (interaction.deferred) {
                await interaction.editReply({ embeds: [errorEmbed] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },

    /**
     * Validate if URL is a valid image URL
     * @param {string} url - URL to validate
     * @returns {boolean} - Whether URL is valid
     */
    isValidImageUrl(url) {
        try {
            const parsedUrl = new URL(url);
            const validExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
            const pathname = parsedUrl.pathname.toLowerCase();
            
            return validExtensions.some(ext => pathname.endsWith(ext)) || 
                   pathname.includes('cdn.discord') || 
                   pathname.includes('imgur.com') ||
                   pathname.includes('i.redd.it');
        } catch {
            return false;
        }
    }
};
