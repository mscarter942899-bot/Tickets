/**
 * /my-tickets command - Show user their total combined tickets from legacy and chat rewards
 */

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS, EMOJIS } = require('../config/constants.js');
const { TimeFormatter } = require('../utils/time-formatter.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('my-tickets')
        .setDescription('Show your total ticket balance and detailed breakdown'),

    async execute(interaction, client) {
        try {
            const userId = interaction.user.id;
            
            // Get comprehensive ticket stats
            const stats = client.ticketManager.getTicketStats(userId);
            const report = client.ticketManager.generateTicketReport(userId);
            const activeRaffles = client.raffleManager.getGuildActiveRaffles(interaction.guild.id);

            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.TICKET} Your Ticket Balance`)
                .setColor(COLORS.PRIMARY)
                .setThumbnail(interaction.user.displayAvatarURL())
                .setTimestamp();

            // Main ticket balance section
            let balanceText = `${EMOJIS.STATS} **Total Tickets:** ${stats.total}\n`;
            balanceText += `${EMOJIS.SUCCESS} **Available:** ${stats.available}\n`;
            balanceText += `${EMOJIS.RAFFLE} **In Active Raffles:** ${stats.inActiveRaffles}`;

            embed.addFields({
                name: `${EMOJIS.MONEY} Ticket Balance`,
                value: balanceText,
                inline: true
            });

            // Ticket sources breakdown
            let sourcesText = `${EMOJIS.TICKET} **Earn Commands:** ${report.sources.earnCommands}\n`;
            sourcesText += `${EMOJIS.SPARKLES} **Chat Activity:** ${report.sources.chatActivity}`;
            
            if (report.sources.adminAwarded > 0) {
                sourcesText += `\n${EMOJIS.CROWN} **Admin Awarded:** ${report.sources.adminAwarded}`;
            }
            
            if (report.sources.bonusTickets > 0) {
                sourcesText += `\n${EMOJIS.STAR} **Bonus Rewards:** ${report.sources.bonusTickets}`;
            }

            embed.addFields({
                name: `${EMOJIS.STATS} Ticket Sources`,
                value: sourcesText,
                inline: true
            });

            // Next earning opportunity
            let earnText;
            if (stats.canEarnNext) {
                earnText = `${EMOJIS.SUCCESS} **Ready Now!**\nUse \`/earn\` to claim your free ticket`;
            } else {
                earnText = `${EMOJIS.TIME} **Next Free Ticket:**\n${stats.cooldownText}`;
            }

            embed.addFields({
                name: `${EMOJIS.TIME} Earning Status`,
                value: earnText,
                inline: true
            });

            // Active raffle entries
            if (stats.activeRaffleEntries > 0) {
                let raffleEntries = '';
                let entryCount = 0;
                
                for (const raffle of activeRaffles) {
                    const userTickets = raffle.participants[userId] || 0;
                    if (userTickets > 0 && entryCount < 5) { // Limit to 5 entries shown
                        const timeRemaining = Math.max(0, raffle.endTime - Math.floor(Date.now() / 1000));
                        const winChance = client.raffleManager.calculateWinProbability(raffle, userId);
                        
                        raffleEntries += `**${raffle.prize}**\n`;
                        raffleEntries += `${EMOJIS.TICKET} ${userTickets} tickets (${winChance}% chance)\n`;
                        raffleEntries += `${EMOJIS.TIME} Ends ${TimeFormatter.discordTimestamp(raffle.endTime, 'R')}\n\n`;
                        entryCount++;
                    }
                }

                if (stats.activeRaffleEntries > 5) {
                    raffleEntries += `*...and ${stats.activeRaffleEntries - 5} more entries*`;
                }

                embed.addFields({
                    name: `${EMOJIS.RAFFLE} Your Active Entries (${stats.activeRaffleEntries})`,
                    value: raffleEntries || 'No active entries',
                    inline: false
                });
            }

            // Activity stats
            if (report.activity.totalChatMessages > 0 || report.activity.lastEarnTime > 0) {
                let activityText = '';
                
                if (report.activity.totalChatMessages > 0) {
                    activityText += `${EMOJIS.SPARKLES} **Chat Messages:** ${report.activity.totalChatMessages}\n`;
                }
                
                if (report.activity.lastEarnTime > 0) {
                    activityText += `${EMOJIS.TIME} **Last Earn:** ${TimeFormatter.discordTimestamp(Math.floor(report.activity.lastEarnTime / 1000), 'R')}\n`;
                }
                
                if (report.activity.lastActivity > 0) {
                    activityText += `${EMOJIS.STATS} **Last Activity:** ${TimeFormatter.discordTimestamp(Math.floor(report.activity.lastActivity / 1000), 'R')}`;
                }

                if (activityText) {
                    embed.addFields({
                        name: `${EMOJIS.STATS} Activity Stats`,
                        value: activityText,
                        inline: false
                    });
                }
            }

            // Tips and recommendations
            let tipsText = '';
            
            if (stats.available === 0 && stats.canEarnNext) {
                tipsText += `${EMOJIS.TICKET} Use \`/earn\` to get a free ticket right now!\n`;
            }
            
            if (stats.available > 0 && stats.activeRaffleEntries === 0) {
                tipsText += `${EMOJIS.RAFFLE} You have tickets ready! Check \`/raffle-status\` to enter raffles.\n`;
            }
            
            if (report.activity.totalChatMessages < 50) {
                tipsText += `${EMOJIS.SPARKLES} Stay active in chat to earn bonus tickets!\n`;
            }
            
            tipsText += `${EMOJIS.HELP} Use \`/raffle-status\` to see all active raffles.`;

            embed.addFields({
                name: `${EMOJIS.HELP} Tips & Recommendations`,
                value: tipsText,
                inline: false
            });

            // Win statistics (if user has entered raffles before)
            if (stats.activeRaffleEntries > 0) {
                let totalWinChance = 0;
                for (const raffle of activeRaffles) {
                    const userTickets = raffle.participants[userId] || 0;
                    if (userTickets > 0) {
                        totalWinChance += client.raffleManager.calculateWinProbability(raffle, userId);
                    }
                }

                if (totalWinChance > 0) {
                    embed.addFields({
                        name: `${EMOJIS.CROWN} Win Potential`,
                        value: `${EMOJIS.STAR} **Combined Win Chance:** ${Math.round(totalWinChance * 100) / 100}%\n${EMOJIS.SPARKLES} **Entries:** ${stats.activeRaffleEntries} active raffle${stats.activeRaffleEntries !== 1 ? 's' : ''}`,
                        inline: true
                    });
                }
            }

            embed.setFooter({ 
                text: `Ticket data updates in real-time • Use /earn every 30 minutes for free tickets`,
                iconURL: interaction.user.displayAvatarURL()
            });

            // Color coding based on ticket balance
            if (stats.available >= 10) {
                embed.setColor(COLORS.SUCCESS);
            } else if (stats.available >= 5) {
                embed.setColor(COLORS.WARNING);
            } else if (stats.available > 0) {
                embed.setColor(COLORS.INFO);
            } else {
                embed.setColor(COLORS.ERROR);
            }

            await interaction.reply({ embeds: [embed], ephemeral: true });

            // Log the ticket check
            console.log(`🎟️ ${interaction.user.tag} checked their tickets: ${stats.total} total, ${stats.available} available`);

        } catch (error) {
            console.error('❌ Error in /my-tickets command:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Error`)
                .setDescription('An error occurred while fetching your ticket information. Please try again.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
