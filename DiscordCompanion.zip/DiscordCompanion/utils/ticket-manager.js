/**
 * Ticket management system for the raffle bot
 * Handles earning, spending, and tracking of user tickets
 */

const { COOLDOWNS, EMOJIS } = require('../config/constants.js');
const { TimeFormatter } = require('./time-formatter.js');

class TicketManager {
    constructor() {
        this.storage = null; // Will be injected
    }

    /**
     * Initialize with storage reference
     * @param {Storage} storage - Storage instance
     */
    setStorage(storage) {
        this.storage = storage;
    }

    /**
     * Check if user can earn a ticket (cooldown check)
     * @param {string} userId - Discord user ID
     * @returns {Object} - { canEarn: boolean, cooldownEnd?: number, timeRemaining?: string }
     */
    canEarnTicket(userId) {
        const userData = this.storage.getUserTickets(userId);
        const now = Date.now();
        const cooldownEnd = userData.lastEarn + COOLDOWNS.EARN_TICKET;

        if (cooldownEnd > now) {
            return {
                canEarn: false,
                cooldownEnd,
                timeRemaining: TimeFormatter.formatCooldown(cooldownEnd, now)
            };
        }

        return { canEarn: true };
    }

    /**
     * Award a ticket to a user (ATOMIC & COOLDOWN PROTECTED)
     * @param {string} userId - Discord user ID
     * @param {number} amount - Number of tickets to award (default: 1)
     * @param {string} source - Source of tickets ('earn', 'chat', 'bonus')
     * @returns {Object} - { success: boolean, userData?: Object, message?: string }
     */
    awardTicket(userId, amount = 1, source = 'earn') {
        // Prevent double-earning with atomic lock
        const lockKey = `award_${userId}_${source}`;
        if (this.activeLocks && this.activeLocks.has(lockKey)) {
            return { success: false, message: 'Award already in progress. Please wait.' };
        }

        if (!this.activeLocks) this.activeLocks = new Set();
        this.activeLocks.add(lockKey);

        try {
            const userData = this.storage.getUserTickets(userId);

            // For 'earn' source, validate cooldown to prevent spam/exploits
            if (source === 'earn') {
                const cooldownCheck = this.canEarnTicket(userId);
                if (!cooldownCheck.canEarn) {
                    return { 
                        success: false, 
                        message: `Cooldown active. You can earn again ${cooldownCheck.timeRemaining}.`,
                        cooldownEnd: cooldownCheck.cooldownEnd
                    };
                }
                userData.lastEarn = Date.now();
            } else if (source === 'chat') {
                userData.chatRewards = (userData.chatRewards || 0) + amount;
            } else if (source === 'admin') {
                // Admin awarded tickets - no restrictions
                if (!userData.adminAwarded) userData.adminAwarded = 0;
                userData.adminAwarded += amount;
            }

            // Award tickets
            userData.total += amount;
            this.storage.setUserTickets(userId, userData);

            console.log(`🎟️ Awarded ${amount} ticket${amount !== 1 ? 's' : ''} to ${userId} (${source})`);

            return { success: true, userData };

        } catch (error) {
            console.error(`❌ Error awarding tickets to ${userId}:`, error);
            return { success: false, message: 'Failed to award tickets due to system error.' };
        } finally {
            this.activeLocks.delete(lockKey);
        }
    }

    /**
     * Spend tickets for raffle entry (ATOMIC OPERATION)
     * @param {string} userId - Discord user ID
     * @param {number} amount - Number of tickets to spend
     * @param {string} raffleId - Raffle ID for tracking
     * @returns {Object} - { success: boolean, message?: string, availableBefore?: number }
     */
    spendTickets(userId, amount, raffleId) {
        // Critical: Lock to prevent race conditions
        const lockKey = `spend_${userId}_${raffleId}`;
        if (this.activeLocks && this.activeLocks.has(lockKey)) {
            return { success: false, message: 'Entry already in progress for this raffle.' };
        }

        // Initialize locks if not exists
        if (!this.activeLocks) this.activeLocks = new Set();
        this.activeLocks.add(lockKey);

        // Auto-release lock after 5 seconds to prevent permanent locks
        const lockTimeout = setTimeout(() => {
            if (this.activeLocks) {
                this.activeLocks.delete(lockKey);
                console.log(`🔓 Auto-released lock due to timeout: ${lockKey}`);
            }
        }, 5000);

        try {
            // Get fresh data with atomic check
            const availableTickets = this.getAvailableTickets(userId);

            if (availableTickets < amount) {
                return { 
                    success: false, 
                    message: `Insufficient tickets. You have ${availableTickets} available, but need ${amount}.`,
                    availableBefore: availableTickets
                };
            }

            // Validate raffle exists and is active
            const raffle = this.storage.getRaffle(raffleId);
            if (!raffle || !raffle.isActive) {
                return { success: false, message: 'Raffle is no longer active.' };
            }

            // Check if user already has tickets in this raffle to prevent double-entry exploits
            const currentParticipation = raffle.participants[userId] || 0;
            const maxTicketsPerUser = 100; // Configurable limit

            if (currentParticipation + amount > maxTicketsPerUser) {
                return { 
                    success: false, 
                    message: `Entry limit exceeded. Maximum ${maxTicketsPerUser} tickets per raffle. You already have ${currentParticipation}.`
                };
            }

            // ATOMIC TRANSACTION: Both user tickets and raffle participation must succeed
            const userData = this.storage.getUserTickets(userId);
            const originalTotal = userData.total;

            // Remove tickets from user's total
            userData.total -= amount;

            // Track spent tickets per raffle for audit trail
            if (!userData.spentTickets) userData.spentTickets = {};
            if (!userData.spentTickets[raffleId]) userData.spentTickets[raffleId] = 0;
            userData.spentTickets[raffleId] += amount;

            // Update raffle participation atomically
            raffle.participants[userId] = currentParticipation + amount;

            // Save both changes or fail completely
            this.storage.setUserTickets(userId, userData);
            this.storage.setRaffle(raffleId, raffle);

            console.log(`🎟️ ${userId} spent ${amount} ticket${amount !== 1 ? 's' : ''} on raffle ${raffleId} (${originalTotal} → ${userData.total})`);
            console.log(`🎟️ Raffle ${raffleId} participation for ${userId}: ${raffle.participants[userId]} tickets`);

            return { 
                success: true, 
                availableBefore: availableTickets,
                newTotal: userData.total,
                raffleParticipation: raffle.participants[userId]
            };

        } catch (error) {
            console.error(`❌ Critical error in spendTickets for user ${userId}:`, error);
            return { success: false, message: 'Transaction failed due to system error.' };
        } finally {
            // Clear timeout and release lock immediately
            clearTimeout(lockTimeout);
            if (this.activeLocks) {
                this.activeLocks.delete(lockKey);
                console.log(`🔓 Released lock: ${lockKey}`);
            }
        }
    }

    /**
     * Get available tickets (ATOMIC CALCULATION - Bug-proof)
     * @param {string} userId - Discord user ID
     * @returns {number} - Available ticket count
     */
    getAvailableTickets(userId) {
        const userData = this.storage.getUserTickets(userId);
        const activeRaffles = this.storage.getActiveRaffles();

        let ticketsInActiveRaffles = 0;

        // Count tickets ONLY from active raffles to prevent double-counting
        for (const raffle of activeRaffles) {
            if (raffle.participants && raffle.participants[userId]) {
                ticketsInActiveRaffles += raffle.participants[userId];
            }
        }

        // Critical fix: Never allow negative tickets
        const available = Math.max(0, userData.total - ticketsInActiveRaffles);

        // Debug logging for negative balance detection
        if (available < 0 || userData.total < ticketsInActiveRaffles) {
            console.warn(`⚠️ Ticket calculation issue for ${userId}: total=${userData.total}, inRaffles=${ticketsInActiveRaffles}, available=${available}`);

            // Auto-correct corrupted data
            if (userData.total < ticketsInActiveRaffles) {
                console.log(`🔧 Auto-correcting ticket balance for ${userId}`);
                userData.total = ticketsInActiveRaffles;
                this.storage.setUserTickets(userId, userData);
                return 0;
            }
        }

        return available;
    }

    /**
     * Get user's ticket statistics
     * @param {string} userId - Discord user ID
     * @returns {Object} - Comprehensive ticket stats
     */
    getTicketStats(userId) {
        const userData = this.storage.getUserTickets(userId);
        const activeRaffles = this.storage.getActiveRaffles();
        const userStats = this.storage.getUserStats(userId);

        let ticketsInActiveRaffles = 0;
        let activeRaffleCount = 0;

        for (const raffle of activeRaffles) {
            if (raffle.participants && raffle.participants[userId]) {
                ticketsInActiveRaffles += raffle.participants[userId];
                activeRaffleCount++;
            }
        }

        const availableTickets = userData.total - ticketsInActiveRaffles;
        const cooldownCheck = this.canEarnTicket(userId);

        return {
            total: userData.total,
            available: availableTickets,
            inActiveRaffles: ticketsInActiveRaffles,
            chatRewards: userData.chatRewards || 0,
            adminAwarded: userData.adminAwarded || 0,
            earnedFromChat: userStats.ticketsEarned || 0,
            activeRaffleEntries: activeRaffleCount,
            canEarnNext: cooldownCheck.canEarn,
            nextEarnTime: cooldownCheck.cooldownEnd,
            cooldownText: cooldownCheck.timeRemaining
        };
    }

    /**
     * Get leaderboard of users by ticket count
     * @param {number} limit - Number of users to return (default: 10)
     * @returns {Array} - Array of user ticket data
     */
    getLeaderboard(limit = 10) {
        const allUsers = [];

        for (const [userId, userData] of this.storage.data.tickets) {
            allUsers.push({
                userId,
                total: userData.total,
                chatRewards: userData.chatRewards || 0,
                available: this.getAvailableTickets(userId)
            });
        }

        return allUsers
            .sort((a, b) => b.total - a.total)
            .slice(0, limit);
    }

    /**
     * Process chat activity and award 1 ticket per message (PROTECTED)
     * @param {string} userId - Discord user ID
     * @param {string} guildId - Discord guild ID
     * @param {string} messageContent - Message content for spam detection
     * @returns {Object|null} - Ticket award info or null if no award
     */
    processChatActivity(userId, guildId, messageContent = '') {
        // Prevent chat spam exploitation
        const lockKey = `chat_${userId}`;
        if (this.activeLocks && this.activeLocks.has(lockKey)) {
            return null; // Skip if already processing
        }

        if (!this.activeLocks) this.activeLocks = new Set();
        this.activeLocks.add(lockKey);

        try {
            const userStats = this.storage.getUserStats(userId);
            const now = Date.now();

            // Store message content for spam detection
            userStats.messageText = messageContent;

            // Check if message-based ticket earning is enabled (configurable)
            const config = this.storage.getConfig();
            if (!config.earnFromMessages) {
                return null;
            }

            // Optional: Anti-spam protection based on config
            const messageSpamCooldown = config.messageSpamCooldown || 0; // Default: no cooldown
            if (messageSpamCooldown > 0 && userStats.lastTicketTime && (now - userStats.lastTicketTime) < messageSpamCooldown) {
                return null;
            }

            // Anti-spam: Ignore very short messages (configurable)
            const minMessageLength = config.minMessageLength || 3;
            if (!userStats.messageText || userStats.messageText.length < minMessageLength) {
                return null;
            }

            // Update chat stats
            userStats.chatMessages = (userStats.chatMessages || 0) + 1;
            userStats.lastActivity = now;

            // Award tickets per message (configurable amount)
            const ticketsPerMessage = config.ticketsPerMessage || 1;
            
            userStats.ticketsEarned = (userStats.ticketsEarned || 0) + ticketsPerMessage;
            userStats.lastTicketTime = now;

            this.storage.setUserStats(userId, userStats);

            // Use atomic award function
            const awardResult = this.awardTicket(userId, ticketsPerMessage, 'chat');

            if (awardResult.success) {
                return {
                    awarded: true,
                    amount: ticketsPerMessage,
                    source: 'chat',
                    totalMessages: userStats.chatMessages
                };
            }

            this.storage.setUserStats(userId, userStats);
            return null;

        } catch (error) {
            console.error(`❌ Error processing chat activity for ${userId}:`, error);
            return null;
        } finally {
            this.activeLocks.delete(lockKey);
        }
    }

    /**
     * Refund tickets from a cancelled or ended raffle (ATOMIC)
     * @param {string} raffleId - Raffle ID
     * @param {Object} participants - Participants object { userId: ticketCount }
     * @returns {Object} - Refund results
     */
    refundRaffleTickets(raffleId, participants) {
        const refundResults = {
            successful: [],
            failed: [],
            totalRefunded: 0
        };

        for (const [userId, ticketCount] of Object.entries(participants)) {
            const lockKey = `refund_${userId}_${raffleId}`;
            if (this.activeLocks && this.activeLocks.has(lockKey)) {
                refundResults.failed.push({ userId, reason: 'Lock conflict' });
                continue;
            }

            if (!this.activeLocks) this.activeLocks = new Set();
            this.activeLocks.add(lockKey);

            try {
                const userData = this.storage.getUserTickets(userId);
                const originalTotal = userData.total;

                // Refund tickets
                userData.total += ticketCount;

                // Clean up spent tickets tracking
                if (userData.spentTickets && userData.spentTickets[raffleId]) {
                    delete userData.spentTickets[raffleId];
                }

                this.storage.setUserTickets(userId, userData);

                refundResults.successful.push({ 
                    userId, 
                    refunded: ticketCount, 
                    newTotal: userData.total,
                    oldTotal: originalTotal
                });
                refundResults.totalRefunded += ticketCount;

                console.log(`🔄 Refunded ${ticketCount} tickets to ${userId} from raffle ${raffleId} (${originalTotal} → ${userData.total})`);

            } catch (error) {
                console.error(`❌ Error refunding tickets to ${userId}:`, error);
                refundResults.failed.push({ userId, reason: error.message });
            } finally {
                this.activeLocks.delete(lockKey);
            }
        }

        return refundResults;
    }

    /**
     * Generate a detailed ticket report for a user
     * @param {string} userId - Discord user ID
     * @returns {Object} - Detailed ticket report
     */
    generateTicketReport(userId) {
        const stats = this.getTicketStats(userId);
        const userData = this.storage.getUserTickets(userId);
        const userStats = this.storage.getUserStats(userId);

        return {
            summary: {
                totalTickets: stats.total,
                availableTickets: stats.available,
                ticketsInRaffles: stats.inActiveRaffles,
                activeEntries: stats.activeRaffleEntries
            },
            sources: {
                earnCommands: stats.total - stats.chatRewards - stats.adminAwarded,
                chatActivity: stats.chatRewards,
                adminAwarded: stats.adminAwarded,
                bonusTickets: 0 // Could be expanded
            },
            activity: {
                lastEarnTime: userData.lastEarn || 0,
                totalChatMessages: userStats.chatMessages || 0,
                lastActivity: userStats.lastActivity || 0
            },
            cooldown: {
                canEarnNow: stats.canEarnNext,
                nextEarnTime: stats.nextEarnTime,
                cooldownRemaining: stats.cooldownText
            }
        };
    }

    /**
     * Data integrity validation and auto-repair system
     * @param {string} userId - Discord user ID (optional, validates all if not provided)
     * @returns {Object} - Validation results
     */
    validateDataIntegrity(userId = null) {
        const results = {
            validated: 0,
            corrected: 0,
            issues: []
        };

        const usersToCheck = userId ? [userId] : Array.from(this.storage.data.tickets.keys());

        for (const checkUserId of usersToCheck) {
            results.validated++;

            const userData = this.storage.getUserTickets(checkUserId);
            const activeRaffles = this.storage.getActiveRaffles();

            let actualTicketsInRaffles = 0;
            for (const raffle of activeRaffles) {
                if (raffle.participants && raffle.participants[checkUserId]) {
                    actualTicketsInRaffles += raffle.participants[checkUserId];
                }
            }

            // Check for negative total tickets
            if (userData.total < 0) {
                console.warn(`🔧 Auto-correcting negative ticket balance for ${checkUserId}: ${userData.total} → 0`);
                userData.total = 0;
                this.storage.setUserTickets(checkUserId, userData);
                results.corrected++;
                results.issues.push(`Corrected negative balance for ${checkUserId}`);
            }

            // Check for impossible scenarios (tickets in raffles > total tickets)
            if (actualTicketsInRaffles > userData.total) {
                console.warn(`🔧 Auto-correcting ticket inconsistency for ${checkUserId}: total=${userData.total}, inRaffles=${actualTicketsInRaffles}`);
                userData.total = actualTicketsInRaffles;
                this.storage.setUserTickets(checkUserId, userData);
                results.corrected++;
                results.issues.push(`Corrected ticket total for ${checkUserId} (${actualTicketsInRaffles} in raffles)`);
            }

            // Check for orphaned spent ticket records
            if (userData.spentTickets) {
                const activeRaffleIds = new Set(activeRaffles.map(r => r.id));
                for (const raffleId of Object.keys(userData.spentTickets)) {
                    if (!activeRaffleIds.has(raffleId)) {
                        delete userData.spentTickets[raffleId];
                        this.storage.setUserTickets(checkUserId, userData);
                        results.corrected++;
                        results.issues.push(`Cleaned orphaned raffle record ${raffleId} for ${checkUserId}`);
                    }
                }
            }
        }

        if (results.corrected > 0) {
            console.log(`🔧 Data integrity check: validated ${results.validated} users, corrected ${results.corrected} issues`);
        }

        return results;
    }

    
}

module.exports = { TicketManager };