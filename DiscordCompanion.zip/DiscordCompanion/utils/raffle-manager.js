/**
 * Raffle management system with live updates and winner selection
 */

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { COLORS, EMOJIS, RAFFLE } = require('../config/constants.js');
const { TimeFormatter } = require('./time-formatter.js');
const { DurationParser } = require('./duration-parser.js');

class RaffleManager {
    constructor() {
        this.storage = null;
        this.durationParser = new DurationParser();
        this.updateInterval = null;
    }

    /**
     * Initialize with storage reference
     * @param {Storage} storage - Storage instance
     */
    setStorage(storage) {
        this.storage = storage;
    }

    /**
     * Create a new raffle
     * @param {Object} options - Raffle creation options
     * @returns {Object} - Created raffle data
     */
    async createRaffle(options) {
        const {
            guildId,
            channelId,
            creatorId,
            prize,
            duration,
            winners = RAFFLE.DEFAULT_WINNERS,
            image = null,
            description = null
        } = options;

        // Generate unique raffle ID
        const raffleId = this.generateRaffleId();
        
        // Parse duration to get end timestamp
        const endTime = this.durationParser.parse(duration);
        const startTime = Math.floor(Date.now() / 1000);

        const raffle = {
            id: raffleId,
            guildId,
            channelId,
            messageId: null, // Will be set after message is sent
            creatorId,
            prize: prize.substring(0, 256), // Limit prize length
            description: description ? description.substring(0, 1024) : null,
            image,
            startTime,
            endTime,
            winners: Math.min(winners, RAFFLE.MAX_WINNERS),
            participants: {}, // userId -> ticketCount
            isActive: true,
            createdAt: new Date().toISOString()
        };

        // Store raffle
        this.storage.setRaffle(raffleId, raffle);

        console.log(`🎁 Created raffle ${raffleId}: "${prize}" ending at ${TimeFormatter.formatLocalTime(endTime)}`);

        return raffle;
    }

    /**
     * Generate unique raffle ID
     * @returns {string} - Unique raffle ID
     */
    generateRaffleId() {
        const timestamp = Date.now().toString(36);
        const random = Math.random().toString(36).substring(2, 8);
        return `raffle_${timestamp}_${random}`;
    }

    /**
     * Create raffle embed
     * @param {Object} raffle - Raffle data
     * @param {number} currentTime - Current timestamp in seconds
     * @returns {EmbedBuilder} - Discord embed
     */
    createRaffleEmbed(raffle, currentTime = Math.floor(Date.now() / 1000)) {
        const timeRemaining = raffle.endTime - currentTime;
        const participantCount = Object.keys(raffle.participants).length;
        const totalTickets = Object.values(raffle.participants).reduce((sum, tickets) => sum + tickets, 0);

        const embed = new EmbedBuilder()
            .setTitle(`${EMOJIS.RAFFLE} ${raffle.prize}`)
            .setColor(timeRemaining > 0 ? COLORS.RAFFLE : COLORS.ERROR)
            .setTimestamp(new Date(raffle.endTime * 1000));

        // Description with raffle details
        let descriptionText = raffle.description || `Enter this exciting raffle for a chance to win **${raffle.prize}**!`;
        
        descriptionText += `\n\n${EMOJIS.WINNER} **Winners:** ${raffle.winners}`;
        descriptionText += `\n${EMOJIS.TICKET} **Participants:** ${participantCount} (${totalTickets} tickets)`;
        
        if (timeRemaining > 0) {
            descriptionText += `\n${EMOJIS.TIME} **Time Remaining:** ${TimeFormatter.formatCountdown(timeRemaining)}`;
            descriptionText += `\n${EMOJIS.TIME} **Ends:** ${TimeFormatter.discordTimestamp(raffle.endTime, 'R')}`;
        } else {
            descriptionText += `\n${EMOJIS.ERROR} **Status:** Ended`;
        }

        embed.setDescription(descriptionText);

        // Add image if provided
        if (raffle.image) {
            embed.setImage(raffle.image);
        }

        // Footer with raffle info
        embed.setFooter({
            text: `Raffle ID: ${raffle.id} | Created by User ${raffle.creatorId}`
        });

        // Add urgency color coding
        if (timeRemaining > 0) {
            if (timeRemaining <= 60) {
                embed.setColor(COLORS.ERROR); // Red for last minute
            } else if (timeRemaining <= 300) {
                embed.setColor(COLORS.WARNING); // Yellow for last 5 minutes
            }
        }

        return embed;
    }

    /**
     * Create action row with raffle buttons
     * @param {Object} raffle - Raffle data
     * @param {number} currentTime - Current timestamp in seconds
     * @returns {ActionRowBuilder} - Button action row
     */
    createRaffleButtons(raffle, currentTime = Math.floor(Date.now() / 1000)) {
        const timeRemaining = raffle.endTime - currentTime;
        const isActive = timeRemaining > 0 && raffle.isActive;

        const enterButton = new ButtonBuilder()
            .setCustomId(`raffle_enter_${raffle.id}`)
            .setLabel('🎟️ Enter Raffle')
            .setStyle(ButtonStyle.Success)
            .setDisabled(!isActive);

        const helpButton = new ButtonBuilder()
            .setCustomId('raffle_help')
            .setLabel('❓ How to Earn Tickets')
            .setStyle(ButtonStyle.Secondary);

        const statsButton = new ButtonBuilder()
            .setCustomId(`raffle_stats_${raffle.id}`)
            .setLabel('📊 Raffle Stats')
            .setStyle(ButtonStyle.Primary);

        return new ActionRowBuilder().addComponents(enterButton, helpButton, statsButton);
    }

    /**
     * Add participant to raffle
     * @param {string} raffleId - Raffle ID
     * @param {string} userId - User ID
     * @param {number} ticketCount - Number of tickets to enter
     * @returns {Object} - { success: boolean, message: string, raffle?: Object }
     */
    addParticipant(raffleId, userId, ticketCount) {
        const raffle = this.storage.getRaffle(raffleId);
        
        if (!raffle) {
            return { success: false, message: 'Raffle not found.' };
        }

        if (!raffle.isActive) {
            return { success: false, message: 'This raffle is no longer active.' };
        }

        const currentTime = Math.floor(Date.now() / 1000);
        if (currentTime >= raffle.endTime) {
            return { success: false, message: 'This raffle has already ended.' };
        }

        // Add or update participant
        if (raffle.participants[userId]) {
            raffle.participants[userId] += ticketCount;
        } else {
            raffle.participants[userId] = ticketCount;
        }

        // Update storage
        this.storage.setRaffle(raffleId, raffle);

        const totalTickets = raffle.participants[userId];
        console.log(`🎟️ ${userId} entered raffle ${raffleId} with ${ticketCount} tickets (total: ${totalTickets})`);

        return {
            success: true,
            message: `Successfully entered ${ticketCount} ticket${ticketCount !== 1 ? 's' : ''} into the raffle!`,
            raffle
        };
    }

    /**
     * Calculate win probability for a user
     * @param {Object} raffle - Raffle data
     * @param {string} userId - User ID
     * @returns {number} - Win probability as percentage
     */
    calculateWinProbability(raffle, userId) {
        const userTickets = raffle.participants[userId] || 0;
        const totalTickets = Object.values(raffle.participants).reduce((sum, tickets) => sum + tickets, 0);
        
        if (totalTickets === 0) return 0;
        
        // For multiple winners, calculate probability using hypergeometric distribution approximation
        const winnerCount = Math.min(raffle.winners, Object.keys(raffle.participants).length);
        const probability = Math.min(100, (userTickets / totalTickets) * winnerCount * 100);
        
        return Math.round(probability * 100) / 100; // Round to 2 decimal places
    }

    /**
     * End a raffle and select winners
     * @param {string} raffleId - Raffle ID
     * @returns {Object} - { success: boolean, winners: Array, raffle: Object }
     */
    async endRaffle(raffleId) {
        const raffle = this.storage.getRaffle(raffleId);
        
        if (!raffle) {
            return { success: false, message: 'Raffle not found.' };
        }

        if (!raffle.isActive) {
            return { success: false, message: 'Raffle is already ended.' };
        }

        // Mark as inactive
        raffle.isActive = false;
        raffle.endedAt = new Date().toISOString();

        const participants = Object.keys(raffle.participants);
        
        if (participants.length === 0) {
            this.storage.setRaffle(raffleId, raffle);
            return {
                success: true,
                winners: [],
                raffle,
                message: 'No participants entered this raffle.'
            };
        }

        // Select winners using weighted random selection
        const winners = this.selectWinners(raffle);
        raffle.winners_selected = winners;

        // Update storage
        this.storage.setRaffle(raffleId, raffle);

        console.log(`🏆 Raffle ${raffleId} ended with ${winners.length} winner${winners.length !== 1 ? 's' : ''}`);

        return {
            success: true,
            winners,
            raffle,
            message: `Raffle ended successfully with ${winners.length} winner${winners.length !== 1 ? 's' : ''}!`
        };
    }

    /**
     * Select winners using weighted random selection
     * @param {Object} raffle - Raffle data
     * @returns {Array} - Array of winner objects
     */
    selectWinners(raffle) {
        const participants = Object.entries(raffle.participants);
        const winners = [];
        const maxWinners = Math.min(raffle.winners, participants.length);

        // Create weighted pool
        const weightedPool = [];
        for (const [userId, ticketCount] of participants) {
            for (let i = 0; i < ticketCount; i++) {
                weightedPool.push(userId);
            }
        }

        // Select unique winners
        const selectedUsers = new Set();
        
        for (let i = 0; i < maxWinners && weightedPool.length > 0; i++) {
            let selectedUser;
            let attempts = 0;
            
            do {
                const randomIndex = Math.floor(Math.random() * weightedPool.length);
                selectedUser = weightedPool[randomIndex];
                attempts++;
                
                // Prevent infinite loop if all participants are already selected
                if (attempts > 100) break;
                
            } while (selectedUsers.has(selectedUser) && selectedUsers.size < participants.length);
            
            if (!selectedUsers.has(selectedUser)) {
                selectedUsers.add(selectedUser);
                winners.push({
                    userId: selectedUser,
                    tickets: raffle.participants[selectedUser],
                    position: i + 1
                });
            }
        }

        return winners;
    }

    /**
     * Create winner announcement embed
     * @param {Object} raffle - Raffle data
     * @param {Array} winners - Winners array
     * @returns {EmbedBuilder} - Winner announcement embed
     */
    createWinnerEmbed(raffle, winners) {
        const totalTickets = Object.values(raffle.participants).reduce((sum, tickets) => sum + tickets, 0);
        const totalParticipants = Object.keys(raffle.participants).length;

        const embed = new EmbedBuilder()
            .setTitle(`${EMOJIS.PARTY} Raffle Results ${EMOJIS.PARTY}`)
            .setColor(COLORS.WINNER)
            .setTimestamp();

        if (winners.length === 0) {
            embed.setDescription(`${EMOJIS.ERROR} **No Winners**\n\nThe raffle for **${raffle.prize}** ended with no participants.`);
        } else {
            let description = `${EMOJIS.TADA} **Congratulations to the winner${winners.length !== 1 ? 's' : ''}!** ${EMOJIS.TADA}\n\n`;
            description += `**Prize:** ${raffle.prize}\n\n`;
            
            description += `**Winner${winners.length !== 1 ? 's' : ''}:**\n`;
            
            for (const winner of winners) {
                const position = winners.length > 1 ? `${winner.position}. ` : '';
                const emoji = winner.position === 1 ? EMOJIS.CROWN : EMOJIS.STAR;
                description += `${emoji} ${position}<@${winner.userId}> - ${winner.tickets} ticket${winner.tickets !== 1 ? 's' : ''}\n`;
            }

            description += `\n**Raffle Statistics:**\n`;
            description += `${EMOJIS.TICKET} Total Tickets: ${totalTickets}\n`;
            description += `${EMOJIS.STATS} Total Participants: ${totalParticipants}\n`;
            description += `${EMOJIS.TIME} Duration: ${TimeFormatter.formatDuration(raffle.endTime - raffle.startTime)}`;

            embed.setDescription(description);
        }

        // Add image if provided
        if (raffle.image) {
            embed.setThumbnail(raffle.image);
        }

        embed.setFooter({
            text: `Raffle ID: ${raffle.id} | Ended at ${TimeFormatter.formatLocalTime(raffle.endTime)}`
        });

        return embed;
    }

    /**
     * Update all active raffle embeds
     * @param {Client} client - Discord client
     */
    async updateAllRaffles(client) {
        if (!this.storage) {
            console.log('⚠️ Storage not initialized in RaffleManager, skipping update');
            return;
        }
        const activeRaffles = this.storage.getActiveRaffles();
        const currentTime = Math.floor(Date.now() / 1000);

        for (const raffleData of activeRaffles) {
            try {
                const raffle = { id: raffleData.id, ...raffleData };
                
                // Check if raffle has ended
                if (currentTime >= raffle.endTime) {
                    await this.handleRaffleExpiry(client, raffle);
                    continue;
                }

                // Update live embed
                await this.updateRaffleEmbed(client, raffle, currentTime);
                
            } catch (error) {
                console.error(`❌ Error updating raffle ${raffleData.id}:`, error);
            }
        }
    }

    /**
     * Update a single raffle embed
     * @param {Client} client - Discord client
     * @param {Object} raffle - Raffle data
     * @param {number} currentTime - Current timestamp
     */
    async updateRaffleEmbed(client, raffle, currentTime) {
        if (!raffle.messageId) return;

        try {
            const channel = await client.channels.fetch(raffle.channelId);
            if (!channel) return;

            const message = await channel.messages.fetch(raffle.messageId);
            if (!message) return;

            const embed = this.createRaffleEmbed(raffle, currentTime);
            const buttons = this.createRaffleButtons(raffle, currentTime);

            await message.edit({
                embeds: [embed],
                components: [buttons]
            });

        } catch (error) {
            if (error.code !== 10008) { // Ignore "Unknown Message" errors
                console.error(`❌ Error updating raffle embed ${raffle.id}:`, error);
            }
        }
    }

    /**
     * Handle raffle expiry and winner selection
     * @param {Client} client - Discord client
     * @param {Object} raffle - Raffle data
     */
    async handleRaffleExpiry(client, raffle) {
        try {
            const result = await this.endRaffle(raffle.id);
            
            if (!result.success) return;

            const channel = await client.channels.fetch(raffle.channelId);
            if (!channel) return;

            // Create and send winner announcement
            const winnerEmbed = this.createWinnerEmbed(raffle, result.winners);
            await channel.send({ embeds: [winnerEmbed] });

            // Update original raffle message to show ended status
            if (raffle.messageId) {
                try {
                    const message = await channel.messages.fetch(raffle.messageId);
                    const embed = this.createRaffleEmbed(raffle, Math.floor(Date.now() / 1000));
                    const buttons = this.createRaffleButtons(raffle, Math.floor(Date.now() / 1000));

                    await message.edit({
                        embeds: [embed],
                        components: [buttons]
                    });
                } catch (error) {
                    console.error(`❌ Error updating ended raffle message:`, error);
                }
            }

            console.log(`🏁 Raffle ${raffle.id} automatically ended with ${result.winners.length} winners`);

        } catch (error) {
            console.error(`❌ Error handling raffle expiry ${raffle.id}:`, error);
        }
    }

    /**
     * Get raffle statistics
     * @param {string} raffleId - Raffle ID
     * @returns {Object|null} - Raffle statistics
     */
    getRaffleStats(raffleId) {
        const raffle = this.storage.getRaffle(raffleId);
        if (!raffle) return null;

        const participants = Object.entries(raffle.participants);
        const totalTickets = Object.values(raffle.participants).reduce((sum, tickets) => sum + tickets, 0);
        const currentTime = Math.floor(Date.now() / 1000);
        const timeRemaining = Math.max(0, raffle.endTime - currentTime);

        // Calculate top participants
        const topParticipants = participants
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10)
            .map(([userId, tickets]) => ({
                userId,
                tickets,
                percentage: totalTickets > 0 ? Math.round((tickets / totalTickets) * 100 * 100) / 100 : 0
            }));

        return {
            id: raffle.id,
            prize: raffle.prize,
            isActive: raffle.isActive,
            timeRemaining,
            participantCount: participants.length,
            totalTickets,
            averageTicketsPerParticipant: participants.length > 0 ? Math.round((totalTickets / participants.length) * 100) / 100 : 0,
            topParticipants,
            startTime: raffle.startTime,
            endTime: raffle.endTime,
            duration: raffle.endTime - raffle.startTime,
            winners: raffle.winners
        };
    }

    /**
     * Get all active raffles for a guild
     * @param {string} guildId - Guild ID
     * @returns {Array} - Array of active raffles
     */
    getGuildActiveRaffles(guildId) {
        const activeRaffles = this.storage.getActiveRaffles();
        return activeRaffles.filter(raffle => raffle.guildId === guildId);
    }

    /**
     * Clean up old inactive raffles
     * @param {number} maxAge - Maximum age in seconds (default: 7 days)
     */
    cleanupOldRaffles(maxAge = 604800) {
        const cutoffTime = Math.floor(Date.now() / 1000) - maxAge;
        const allRaffles = Array.from(this.storage.data.raffles.entries());
        
        let cleanedCount = 0;
        
        for (const [raffleId, raffle] of allRaffles) {
            if (!raffle.isActive && raffle.endTime < cutoffTime) {
                this.storage.deleteRaffle(raffleId);
                cleanedCount++;
            }
        }

        if (cleanedCount > 0) {
            console.log(`🧹 Cleaned up ${cleanedCount} old raffle${cleanedCount !== 1 ? 's' : ''}`);
        }

        return cleanedCount;
    }
}

module.exports = { RaffleManager };
