/**
 * Persistent storage manager for bot data
 * Handles saving and loading of tickets, raffles, and user data
 */

const fs = require('fs').promises;
const path = require('path');
const { STORAGE } = require('../config/constants.js');

class Storage {
    constructor() {
        this.data = {
            tickets: new Map(),        // userId -> { total, chatRewards, cooldowns }
            raffles: new Map(),        // raffleId -> raffle object
            userStats: new Map(),      // userId -> { chatMessages, lastActivity }
            guildSettings: new Map(),   // guildId -> settings
            config: {
                earnFromMessages: true,
                ticketsPerMessage: 1,
                minMessageLength: 3,
                messageSpamCooldown: 0,
                maxTotalTickets: 1000,
                defaultTicketAward: 1,
                bonusTicketThreshold: 100,
                weekendBonus: false,
                excludedChannels: []
            }
        };

        this.dataLoaded = false;
    }

    /**
     * Ensure data directory exists
     */
    async ensureDataDirectory() {
        const dataDir = path.dirname(STORAGE.DATA_FILE);
        try {
            await fs.access(dataDir);
        } catch {
            await fs.mkdir(dataDir, { recursive: true });
            console.log(`📁 Created data directory: ${dataDir}`);
        }
    }

    /**
     * Convert Maps to objects for JSON serialization
     */
    serializeData() {
        return {
            tickets: Object.fromEntries(this.data.tickets),
            raffles: Object.fromEntries(this.data.raffles),
            userStats: Object.fromEntries(this.data.userStats),
            guildSettings: Object.fromEntries(this.data.guildSettings),
            lastSaved: new Date().toISOString()
        };
    }

    /**
     * Convert objects back to Maps after JSON deserialization
     */
    deserializeData(jsonData) {
        this.data.tickets = new Map(Object.entries(jsonData.tickets || {}));
        this.data.raffles = new Map(Object.entries(jsonData.raffles || {}));
        this.data.userStats = new Map(Object.entries(jsonData.userStats || {}));
        this.data.guildSettings = new Map(Object.entries(jsonData.guildSettings || {}));
    }

    /**
     * Load data from storage file
     */
    async loadData() {
        try {
            await this.ensureDataDirectory();

            const data = await fs.readFile(STORAGE.DATA_FILE, 'utf8');
            const jsonData = JSON.parse(data);

            this.deserializeData(jsonData);
            this.dataLoaded = true;

            console.log(`💾 Loaded data: ${this.data.tickets.size} users, ${this.data.raffles.size} raffles`);

            return true;
        } catch (error) {
            if (error.code === 'ENOENT') {
                console.log('📝 No existing data file found, starting fresh');
                this.dataLoaded = true;
                return false;
            } else {
                console.error('❌ Error loading data:', error);
                throw error;
            }
        }
    }

    /**
     * Save data to storage file with backup
     */
    async saveData() {
        try {
            await this.ensureDataDirectory();

            const serializedData = this.serializeData();
            const jsonData = JSON.stringify(serializedData, null, 2);

            // Create backup of existing file
            try {
                await fs.access(STORAGE.DATA_FILE);
                await fs.copyFile(STORAGE.DATA_FILE, STORAGE.BACKUP_FILE);
            } catch {
                // No existing file to backup
            }

            // Write new data
            await fs.writeFile(STORAGE.DATA_FILE, jsonData, 'utf8');

            return true;
        } catch (error) {
            console.error('❌ Error saving data:', error);
            throw error;
        }
    }

    /**
     * Get user ticket data
     */
    getUserTickets(userId) {
        return this.data.tickets.get(userId) || {
            total: 0,
            chatRewards: 0,
            cooldowns: {},
            lastEarn: 0
        };
    }

    /**
     * Set user ticket data
     */
    setUserTickets(userId, ticketData) {
        this.data.tickets.set(userId, ticketData);
    }

    /**
     * Get raffle data
     */
    getRaffle(raffleId) {
        return this.data.raffles.get(raffleId);
    }

    /**
     * Set raffle data
     */
    setRaffle(raffleId, raffleData) {
        this.data.raffles.set(raffleId, raffleData);
    }

    /**
     * Delete raffle data
     */
    deleteRaffle(raffleId) {
        return this.data.raffles.delete(raffleId);
    }

    /**
     * Get all active raffles
     */
    getActiveRaffles() {
        const activeRaffles = [];
        for (const [id, raffle] of this.data.raffles) {
            if (raffle.isActive) {
                activeRaffles.push({ id, ...raffle });
            }
        }
        return activeRaffles;
    }

    /**
     * Get user stats
     */
    getUserStats(userId) {
        return this.data.userStats.get(userId) || {
            chatMessages: 0,
            lastActivity: 0,
            ticketsEarned: 0
        };
    }

    /**
     * Set user stats
     */
    setUserStats(userId, stats) {
        this.data.userStats.set(userId, stats);
    }

    /**
     * Get guild settings
     */
    getGuildSettings(guildId) {
        return this.data.guildSettings.get(guildId) || {
            raffleChannels: [],
            moderatorRoles: [],
            customEmojis: {}
        };
    }

    /**
     * Set guild settings
     */
    setGuildSettings(guildId, settings) {
        this.data.guildSettings.set(guildId, settings);
    }

    /**
     * Get comprehensive statistics
     * @returns {Object} - Bot statistics
     */
    getStats() {
        return {
            totalUsers: this.data.tickets.size,
            totalTickets: Array.from(this.data.tickets.values()).reduce((sum, user) => sum + user.total, 0),
            activeRaffles: Array.from(this.data.raffles.values()).filter(r => r.isActive).length,
            totalRaffles: this.data.raffles.size
        };
    }

    /**
     * Get bot configuration
     * @returns {Object} - Configuration object
     */
    getConfig() {
        return this.data.config || {
            earnFromMessages: true,
            ticketsPerMessage: 1,
            minMessageLength: 3,
            messageSpamCooldown: 0,
            maxTotalTickets: 1000,
            defaultTicketAward: 1,
            bonusTicketThreshold: 100,
            weekendBonus: false,
            excludedChannels: []
        };
    }

    /**
     * Set bot configuration
     * @param {Object} config - Configuration object
     */
    setConfig(config) {
        this.data.config = { ...this.getConfig(), ...config };
        console.log('🔧 Configuration updated:', config);
    }
}

module.exports = { Storage };