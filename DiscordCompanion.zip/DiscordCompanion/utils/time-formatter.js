/**
 * Time formatting utilities for Discord embeds and displays
 */

const { EMOJIS } = require('../config/constants.js');

class TimeFormatter {
    /**
     * Format seconds into MM:SS or HH:MM:SS format
     * @param {number} seconds - Seconds to format
     * @returns {string} - Formatted time string
     */
    static formatCountdown(seconds) {
        if (seconds <= 0) return '00:00';

        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;

        if (hours > 0) {
            return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        } else {
            return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
    }

    /**
     * Format duration into human-readable format
     * @param {number} seconds - Duration in seconds
     * @returns {string} - Human-readable duration
     */
    static formatDuration(seconds) {
        if (seconds <= 0) return 'No time';

        const units = [
            { name: 'day', value: 86400, plural: 'days' },
            { name: 'hour', value: 3600, plural: 'hours' },
            { name: 'minute', value: 60, plural: 'minutes' },
            { name: 'second', value: 1, plural: 'seconds' }
        ];

        const parts = [];
        let remaining = seconds;

        for (const unit of units) {
            if (remaining >= unit.value) {
                const count = Math.floor(remaining / unit.value);
                parts.push(`${count} ${count === 1 ? unit.name : unit.plural}`);
                remaining -= count * unit.value;
                
                // Only show top 2 units for readability
                if (parts.length >= 2) break;
            }
        }

        return parts.join(', ') || '0 seconds';
    }

    /**
     * Create Discord timestamp format
     * @param {number} timestamp - Unix timestamp in seconds
     * @param {string} format - Discord timestamp format (t, T, d, D, f, F, R)
     * @returns {string} - Discord timestamp string
     */
    static discordTimestamp(timestamp, format = 'R') {
        return `<t:${Math.floor(timestamp)}:${format}>`;
    }

    /**
     * Get relative time string (e.g., "in 5 minutes", "2 hours ago")
     * @param {number} timestamp - Target timestamp in seconds
     * @param {number} currentTime - Current timestamp in seconds (defaults to now)
     * @returns {string} - Relative time string
     */
    static getRelativeTime(timestamp, currentTime = Math.floor(Date.now() / 1000)) {
        const diff = timestamp - currentTime;
        const absDiff = Math.abs(diff);

        if (absDiff < 60) {
            return diff > 0 ? `in ${diff} second${diff !== 1 ? 's' : ''}` : 'just now';
        }

        const units = [
            { name: 'minute', value: 60 },
            { name: 'hour', value: 3600 },
            { name: 'day', value: 86400 },
            { name: 'week', value: 604800 },
            { name: 'month', value: 2592000 },
            { name: 'year', value: 31536000 }
        ];

        for (let i = 0; i < units.length; i++) {
            if (absDiff < units[i].value * (i === units.length - 1 ? Infinity : 60)) {
                const count = Math.floor(absDiff / units[i].value);
                const unit = units[i].name;
                const plural = count !== 1 ? 's' : '';
                
                return diff > 0 
                    ? `in ${count} ${unit}${plural}`
                    : `${count} ${unit}${plural} ago`;
            }
        }

        return 'unknown time';
    }

    /**
     * Format cooldown remaining time
     * @param {number} cooldownEnd - Cooldown end timestamp in milliseconds
     * @param {number} currentTime - Current timestamp in milliseconds (defaults to now)
     * @returns {string} - Formatted cooldown string
     */
    static formatCooldown(cooldownEnd, currentTime = Date.now()) {
        const remaining = cooldownEnd - currentTime;
        
        if (remaining <= 0) {
            return `${EMOJIS.SUCCESS} Ready to use!`;
        }

        const seconds = Math.ceil(remaining / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);

        if (hours > 0) {
            const remainingMinutes = minutes % 60;
            return `${EMOJIS.TIME} ${hours}h ${remainingMinutes}m remaining`;
        } else if (minutes > 0) {
            const remainingSeconds = seconds % 60;
            return `${EMOJIS.TIME} ${minutes}m ${remainingSeconds}s remaining`;
        } else {
            return `${EMOJIS.TIME} ${seconds}s remaining`;
        }
    }

    /**
     * Get status emoji based on time remaining
     * @param {number} secondsRemaining - Seconds remaining
     * @returns {string} - Status emoji
     */
    static getStatusEmoji(secondsRemaining) {
        if (secondsRemaining <= 0) return EMOJIS.ERROR;
        if (secondsRemaining <= 60) return EMOJIS.WARNING;
        if (secondsRemaining <= 300) return EMOJIS.TIME;
        return EMOJIS.SUCCESS;
    }

    /**
     * Format timestamp for logging
     * @param {Date} date - Date to format (defaults to now)
     * @returns {string} - Formatted timestamp for logs
     */
    static formatLogTimestamp(date = new Date()) {
        return date.toISOString().replace('T', ' ').substring(0, 19);
    }

    /**
     * Get time zone aware display
     * @param {number} timestamp - Unix timestamp in seconds
     * @returns {string} - Formatted date with timezone
     */
    static formatLocalTime(timestamp) {
        const date = new Date(timestamp * 1000);
        return date.toLocaleString('en-US', {
            weekday: 'short',
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            timeZoneName: 'short'
        });
    }
}

module.exports = { TimeFormatter };
