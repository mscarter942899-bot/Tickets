/**
 * Advanced duration parser supporting multiple formats
 * Supports: "30m", "120s", "in 2 hours", "15:30", "tomorrow 3pm", etc.
 */

class DurationParser {
    constructor() {
        // Time unit multipliers (in seconds)
        this.timeUnits = {
            's': 1,
            'sec': 1,
            'second': 1,
            'seconds': 1,
            'm': 60,
            'min': 60,
            'minute': 60,
            'minutes': 60,
            'h': 3600,
            'hr': 3600,
            'hour': 3600,
            'hours': 3600,
            'd': 86400,
            'day': 86400,
            'days': 86400,
            'w': 604800,
            'week': 604800,
            'weeks': 604800
        };

        // Day names for parsing
        this.dayNames = {
            'sunday': 0, 'sun': 0,
            'monday': 1, 'mon': 1,
            'tuesday': 2, 'tue': 2, 'tues': 2,
            'wednesday': 3, 'wed': 3,
            'thursday': 4, 'thu': 4, 'thur': 4, 'thurs': 4,
            'friday': 5, 'fri': 5,
            'saturday': 6, 'sat': 6
        };
    }

    /**
     * Parse duration string and return end timestamp (in seconds)
     * @param {string} input - Duration string to parse
     * @param {Date} baseTime - Base time to calculate from (defaults to now)
     * @returns {number} - End timestamp in seconds
     */
    parse(input, baseTime = new Date()) {
        if (!input || typeof input !== 'string') {
            throw new Error('Invalid duration input');
        }

        const cleanInput = input.toLowerCase().trim();
        const baseTimestamp = Math.floor(baseTime.getTime() / 1000);

        try {
            // Try different parsing methods
            let seconds = 0;

            // Method 1: Simple time units (30m, 2h, 120s)
            seconds = this.parseSimpleUnits(cleanInput);
            if (seconds > 0) {
                return baseTimestamp + seconds;
            }

            // Method 2: Natural language (in 2 hours, in 30 minutes)
            seconds = this.parseNaturalLanguage(cleanInput);
            if (seconds > 0) {
                return baseTimestamp + seconds;
            }

            // Method 3: Specific time (15:30, 3:45 PM)
            const specificTime = this.parseSpecificTime(cleanInput, baseTime);
            if (specificTime > 0) {
                return specificTime;
            }

            // Method 4: Relative days (tomorrow, next friday)
            const relativeTime = this.parseRelativeDay(cleanInput, baseTime);
            if (relativeTime > 0) {
                return relativeTime;
            }

            // Method 5: Combined format (tomorrow 3pm, friday 15:30)
            const combinedTime = this.parseCombinedFormat(cleanInput, baseTime);
            if (combinedTime > 0) {
                return combinedTime;
            }

            throw new Error('Unable to parse duration format');

        } catch (error) {
            throw new Error(`Failed to parse duration "${input}": ${error.message}`);
        }
    }

    /**
     * Parse simple time units like "30m", "2h", "120s"
     */
    parseSimpleUnits(input) {
        const regex = /^(\d+(?:\.\d+)?)\s*([a-z]+)$/;
        const match = input.match(regex);

        if (!match) return 0;

        const value = parseFloat(match[1]);
        const unit = match[2];

        if (this.timeUnits[unit]) {
            return Math.floor(value * this.timeUnits[unit]);
        }

        return 0;
    }

    /**
     * Parse natural language like "in 2 hours", "in 30 minutes"
     */
    parseNaturalLanguage(input) {
        const regex = /^in\s+(\d+(?:\.\d+)?)\s+([a-z]+)$/;
        const match = input.match(regex);

        if (!match) return 0;

        const value = parseFloat(match[1]);
        const unit = match[2];

        if (this.timeUnits[unit]) {
            return Math.floor(value * this.timeUnits[unit]);
        }

        return 0;
    }

    /**
     * Parse specific time like "15:30", "3:45 PM"
     */
    parseSpecificTime(input, baseTime) {
        // 24-hour format (15:30, 23:45)
        let regex = /^(\d{1,2}):(\d{2})$/;
        let match = input.match(regex);

        if (match) {
            const hours = parseInt(match[1]);
            const minutes = parseInt(match[2]);

            if (hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59) {
                const targetTime = new Date(baseTime);
                targetTime.setHours(hours, minutes, 0, 0);

                // If time has passed today, set for tomorrow
                if (targetTime <= baseTime) {
                    targetTime.setDate(targetTime.getDate() + 1);
                }

                return Math.floor(targetTime.getTime() / 1000);
            }
        }

        // 12-hour format (3:45 PM, 11:30 AM)
        regex = /^(\d{1,2}):(\d{2})\s*(am|pm)$/;
        match = input.match(regex);

        if (match) {
            let hours = parseInt(match[1]);
            const minutes = parseInt(match[2]);
            const period = match[3];

            if (hours >= 1 && hours <= 12 && minutes >= 0 && minutes <= 59) {
                if (period === 'pm' && hours !== 12) hours += 12;
                if (period === 'am' && hours === 12) hours = 0;

                const targetTime = new Date(baseTime);
                targetTime.setHours(hours, minutes, 0, 0);

                // If time has passed today, set for tomorrow
                if (targetTime <= baseTime) {
                    targetTime.setDate(targetTime.getDate() + 1);
                }

                return Math.floor(targetTime.getTime() / 1000);
            }
        }

        return 0;
    }

    /**
     * Parse relative days like "tomorrow", "next friday"
     */
    parseRelativeDay(input, baseTime) {
        if (input === 'tomorrow') {
            const tomorrow = new Date(baseTime);
            tomorrow.setDate(tomorrow.getDate() + 1);
            tomorrow.setHours(12, 0, 0, 0); // Default to noon
            return Math.floor(tomorrow.getTime() / 1000);
        }

        const nextDayRegex = /^next\s+([a-z]+)$/;
        const match = input.match(nextDayRegex);

        if (match && this.dayNames[match[1]] !== undefined) {
            const targetDay = this.dayNames[match[1]];
            const currentDay = baseTime.getDay();
            
            let daysToAdd = targetDay - currentDay;
            if (daysToAdd <= 0) daysToAdd += 7; // Next week

            const targetDate = new Date(baseTime);
            targetDate.setDate(targetDate.getDate() + daysToAdd);
            targetDate.setHours(12, 0, 0, 0); // Default to noon

            return Math.floor(targetDate.getTime() / 1000);
        }

        return 0;
    }

    /**
     * Parse combined formats like "tomorrow 3pm", "friday 15:30"
     */
    parseCombinedFormat(input, baseTime) {
        // Tomorrow with time
        let regex = /^tomorrow\s+(\d{1,2}):?(\d{2})?\s*(am|pm)?$/;
        let match = input.match(regex);

        if (match) {
            const tomorrow = new Date(baseTime);
            tomorrow.setDate(tomorrow.getDate() + 1);

            let hours = parseInt(match[1]);
            const minutes = parseInt(match[2]) || 0;
            const period = match[3];

            if (period) {
                if (period === 'pm' && hours !== 12) hours += 12;
                if (period === 'am' && hours === 12) hours = 0;
            }

            tomorrow.setHours(hours, minutes, 0, 0);
            return Math.floor(tomorrow.getTime() / 1000);
        }

        // Day name with time
        regex = /^([a-z]+)\s+(\d{1,2}):?(\d{2})?\s*(am|pm)?$/;
        match = input.match(regex);

        if (match && this.dayNames[match[1]] !== undefined) {
            const targetDay = this.dayNames[match[1]];
            const currentDay = baseTime.getDay();
            
            let daysToAdd = targetDay - currentDay;
            if (daysToAdd <= 0) daysToAdd += 7; // Next week

            const targetDate = new Date(baseTime);
            targetDate.setDate(targetDate.getDate() + daysToAdd);

            let hours = parseInt(match[2]);
            const minutes = parseInt(match[3]) || 0;
            const period = match[4];

            if (period) {
                if (period === 'pm' && hours !== 12) hours += 12;
                if (period === 'am' && hours === 12) hours = 0;
            }

            targetDate.setHours(hours, minutes, 0, 0);
            return Math.floor(targetDate.getTime() / 1000);
        }

        return 0;
    }

    /**
     * Format seconds into human-readable duration
     * @param {number} seconds - Duration in seconds
     * @returns {string} - Formatted duration string
     */
    formatDuration(seconds) {
        if (seconds <= 0) return '0s';

        const units = [
            { name: 'd', value: 86400 },
            { name: 'h', value: 3600 },
            { name: 'm', value: 60 },
            { name: 's', value: 1 }
        ];

        const parts = [];
        let remaining = seconds;

        for (const unit of units) {
            if (remaining >= unit.value) {
                const count = Math.floor(remaining / unit.value);
                parts.push(`${count}${unit.name}`);
                remaining -= count * unit.value;
            }
        }

        return parts.join(' ') || '0s';
    }
}

module.exports = { DurationParser };
