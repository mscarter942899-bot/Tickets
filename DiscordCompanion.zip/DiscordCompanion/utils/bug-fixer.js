const fs = require('fs').promises;
const fsSync = require('fs');
const path = require('path');

class BugFixer {
    constructor(client) {
        this.client = client;
        this.storage = client.storage;
        this.fixHistory = [];
    }

    async runComprehensiveDiagnostics() {
        const diagnostics = {
            timestamp: new Date().toISOString(),
            checks: [],
            fixes: [],
            warnings: []
        };

        // Check 1: Data integrity
        const integrityResult = await this.checkDataIntegrity();
        diagnostics.checks.push(integrityResult);

        // Check 2: Memory leaks
        const memoryResult = await this.checkMemoryUsage();
        diagnostics.checks.push(memoryResult);

        // Check 3: File system health
        const fsResult = await this.checkFileSystemHealth();
        diagnostics.checks.push(fsResult);

        // Check 4: Command system
        const commandResult = await this.checkCommandSystem();
        diagnostics.checks.push(commandResult);

        // Check 5: Event handlers
        const eventResult = await this.checkEventHandlers();
        diagnostics.checks.push(eventResult);

        // Check 6: Bot permissions
        const permissionResult = await this.checkBotPermissions();
        diagnostics.checks.push(permissionResult);

        // Check 7: Interaction state issues
        const interactionResult = await this.checkInteractionHealth();
        diagnostics.checks.push(interactionResult);

        // Check 8: Lock management
        const lockResult = await this.checkLockHealth();
        diagnostics.checks.push(lockResult);

        // Check 9: Configuration consistency
        const configResult = await this.checkConfigurationHealth();
        diagnostics.checks.push(configResult);

        // Check 10: Database consistency
        const dbResult = await this.checkDatabaseConsistency();
        diagnostics.checks.push(dbResult);

        // Check 11: API endpoint health
        const apiResult = await this.checkAPIHealth();
        diagnostics.checks.push(apiResult);

        // Check 12: Raffle system health
        const raffleSystemResult = await this.checkRaffleSystemHealth();
        diagnostics.checks.push(raffleSystemResult);

        // Check 13: Ticket system health
        const ticketSystemResult = await this.checkTicketSystemHealth();
        diagnostics.checks.push(ticketSystemResult);

        // Auto-fix critical issues
        for (const check of diagnostics.checks) {
            if (check.severity === 'critical' && check.autoFixable) {
                const fix = await this.autoFix(check);
                diagnostics.fixes.push(fix);
            }
        }

        return diagnostics;
    }

    async checkDataIntegrity() {
        const issues = [];

        try {
            await this.storage.loadData();

            // Check ticket data consistency
            const tickets = this.storage.data.tickets;
            const raffles = this.storage.data.raffles;

            for (const [userId, userData] of tickets.entries()) {
                // Check for negative tickets
                if (userData.total < 0) {
                    issues.push(`User ${userId} has negative total tickets: ${userData.total}`);
                }

                // Check spent tickets consistency
                if (userData.spentTickets) {
                    const totalSpent = Object.values(userData.spentTickets).reduce((sum, tickets) => sum + tickets, 0);
                    if (totalSpent > userData.total) {
                        issues.push(`User ${userId} has spent more tickets (${totalSpent}) than total (${userData.total})`);
                    }
                }

                // Check raffle participation consistency
                if (userData.spentTickets) {
                    for (const [raffleId, ticketsSpent] of Object.entries(userData.spentTickets)) {
                        const raffle = raffles.get(raffleId);
                        if (raffle && raffle.participants[userId] !== ticketsSpent) {
                            issues.push(`Ticket mismatch for user ${userId} in raffle ${raffleId}`);
                        }
                    }
                }
            }

            // Check raffle data consistency
            for (const [raffleId, raffle] of raffles.entries()) {
                // Check for orphaned participants
                for (const [userId, ticketsEntered] of Object.entries(raffle.participants)) {
                    const userTickets = tickets.get(userId);
                    if (!userTickets || !userTickets.spentTickets || userTickets.spentTickets[raffleId] !== ticketsEntered) {
                        issues.push(`Orphaned participant ${userId} in raffle ${raffleId}`);
                    }
                }

                // Check end times
                if (raffle.endTime < raffle.startTime) {
                    issues.push(`Raffle ${raffleId} has end time before start time`);
                }
            }

        } catch (error) {
            issues.push(`Failed to check data integrity: ${error.message}`);
        }

        return {
            name: 'Data Integrity',
            status: issues.length === 0 ? 'pass' : 'fail',
            severity: issues.length > 5 ? 'critical' : 'warning',
            issues,
            autoFixable: true
        };
    }

    async checkMemoryUsage() {
        const memUsage = process.memoryUsage();
        const issues = [];

        // Check for memory leaks (simple heuristic)
        const heapUsedMB = memUsage.heapUsed / 1024 / 1024;
        const heapTotalMB = memUsage.heapTotal / 1024 / 1024;

        if (heapUsedMB > 500) {
            issues.push(`High heap usage: ${heapUsedMB.toFixed(2)}MB`);
        }

        if (heapUsedMB / heapTotalMB > 0.9) {
            issues.push(`Memory pressure detected: ${(heapUsedMB / heapTotalMB * 100).toFixed(1)}% heap used`);
        }

        return {
            name: 'Memory Usage',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: heapUsedMB > 1000 ? 'critical' : 'warning',
            issues,
            details: {
                heapUsed: `${heapUsedMB.toFixed(2)}MB`,
                heapTotal: `${heapTotalMB.toFixed(2)}MB`,
                external: `${(memUsage.external / 1024 / 1024).toFixed(2)}MB`
            },
            autoFixable: false
        };
    }

    async checkFileSystemHealth() {
        const issues = [];

        try {
            // Check if data directory exists and is writable
            const dataDir = path.dirname(this.storage.constructor.STORAGE?.DATA_FILE || 'data/bot-data.json');

            try {
                await fs.access(dataDir, fs.constants.F_OK | fs.constants.W_OK);
            } catch (error) {
                issues.push(`Data directory not accessible: ${dataDir}`);
            }

            // Check file sizes
            const dataFile = 'data/bot-data.json';
            try {
                const stats = await fs.stat(dataFile);
                const sizeMB = stats.size / 1024 / 1024;

                if (sizeMB > 50) {
                    issues.push(`Data file is large: ${sizeMB.toFixed(2)}MB`);
                }
            } catch (error) {
                issues.push(`Cannot access data file: ${dataFile}`);
            }

            // Check disk space (simplified)
            const freeSpace = await this.checkDiskSpace();
            if (freeSpace < 100) {
                issues.push(`Low disk space: ${freeSpace}MB free`);
            }

        } catch (error) {
            issues.push(`File system check failed: ${error.message}`);
        }

        return {
            name: 'File System Health',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.some(issue => issue.includes('not accessible')) ? 'critical' : 'warning',
            issues,
            autoFixable: true
        };
    }

    async checkCommandSystem() {
        const issues = [];

        try {
            // Check if all commands are loaded
            const commandFiles = await fs.readdir('commands');
            const jsFiles = commandFiles.filter(file => file.endsWith('.js'));

            if (this.client.commands.size !== jsFiles.length) {
                issues.push(`Command count mismatch: ${this.client.commands.size} loaded, ${jsFiles.length} files`);
            }

            // Check for duplicate command names
            const commandNames = new Set();
            for (const command of this.client.commands.values()) {
                if (commandNames.has(command.data.name)) {
                    issues.push(`Duplicate command name: ${command.data.name}`);
                }
                commandNames.add(command.data.name);
            }

            // Check command structure
            for (const [name, command] of this.client.commands.entries()) {
                if (!command.data || !command.execute) {
                    issues.push(`Invalid command structure: ${name}`);
                }
            }

        } catch (error) {
            issues.push(`Command system check failed: ${error.message}`);
        }

        return {
            name: 'Command System',
            status: issues.length === 0 ? 'pass' : 'fail',
            severity: issues.length > 0 ? 'critical' : 'normal',
            issues,
            autoFixable: false
        };
    }

    async checkEventHandlers() {
        const issues = [];

        try {
            // Check if essential event handlers are registered
            const requiredEvents = ['ready', 'interactionCreate', 'messageCreate'];

            for (const event of requiredEvents) {
                const listeners = this.client.listeners(event);
                if (listeners.length === 0) {
                    issues.push(`No listeners for required event: ${event}`);
                }
            }

            // Check for too many listeners (potential memory leak)
            const allEvents = this.client.eventNames();
            for (const event of allEvents) {
                const listenerCount = this.client.listenerCount(event);
                if (listenerCount > 10) {
                    issues.push(`Too many listeners for event ${event}: ${listenerCount}`);
                }
            }

        } catch (error) {
            issues.push(`Event handler check failed: ${error.message}`);
        }

        return {
            name: 'Event Handlers',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.some(issue => issue.includes('No listeners')) ? 'critical' : 'warning',
            issues,
            autoFixable: false
        };
    }

    async checkBotPermissions() {
        const issues = [];

        try {
            if (!this.client.isReady()) {
                issues.push('Bot is not ready/connected');
                return {
                    name: 'Bot Permissions',
                    status: 'fail',
                    severity: 'critical',
                    issues,
                    autoFixable: false
                };
            }

            // Check permissions in each guild
            for (const guild of this.client.guilds.cache.values()) {
                try {
                    const botMember = await guild.members.fetch(this.client.user.id);

                    const requiredPermissions = [
                        'SendMessages',
                        'EmbedLinks',
                        'UseExternalEmojis',
                        'AddReactions',
                        'ReadMessageHistory'
                    ];

                    const missingPerms = requiredPermissions.filter(perm => 
                        !botMember.permissions.has(perm)
                    );

                    if (missingPerms.length > 0) {
                        issues.push(`Missing permissions in ${guild.name}: ${missingPerms.join(', ')}`);
                    }

                } catch (error) {
                    issues.push(`Cannot check permissions in guild ${guild.name}: ${error.message}`);
                }
            }

        } catch (error) {
            issues.push(`Permission check failed: ${error.message}`);
        }

        return {
            name: 'Bot Permissions',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.length > 0 ? 'warning' : 'normal',
            issues,
            autoFixable: false
        };
    }

    async checkInteractionHealth() {
        const issues = [];

        try {
            // Check for stuck deferred interactions (simulated check)
            const currentTime = Date.now();

            // In a real implementation, you'd track interaction timestamps
            // For now, we'll check if the client seems responsive
            if (!this.client.isReady()) {
                issues.push('Bot not ready - interactions will fail');
            }

            // Check if interaction handler is properly loaded
            if (!this.client.commands || this.client.commands.size === 0) {
                issues.push('No commands loaded - interactions will fail');
            }

            // Memory-based check for interaction health
            const memUsage = process.memoryUsage();
            if (memUsage.heapUsed > 800 * 1024 * 1024) { // 800MB
                issues.push('High memory usage may cause interaction timeouts');
            }

        } catch (error) {
            issues.push(`Interaction health check failed: ${error.message}`);
        }

        return {
            name: 'Interaction Health',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.some(issue => issue.includes('will fail')) ? 'critical' : 'warning',
            issues,
            autoFixable: true
        };
    }

    async checkLockHealth() {
        const issues = [];

        try {
            // Check ticket manager locks
            if (this.client.ticketManager && this.client.ticketManager.activeLocks) {
                const lockCount = this.client.ticketManager.activeLocks.size;

                if (lockCount > 50) {
                    issues.push(`Too many active locks: ${lockCount}`);
                }

                // Check for old locks (in a real implementation, you'd track timestamps)
                if (lockCount > 0) {
                    console.log(`🔒 Currently ${lockCount} active locks`);
                }
            }

        } catch (error) {
            issues.push(`Lock health check failed: ${error.message}`);
        }

        return {
            name: 'Lock Health',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.some(issue => issue.includes('Too many')) ? 'critical' : 'warning',
            issues,
            autoFixable: true
        };
    }

    async autoFix(check) {
        const fix = {
            checkName: check.name,
            timestamp: new Date().toISOString(),
            applied: false,
            details: []
        };

        try {
            switch (check.name) {
                case 'Data Integrity':
                    fix.details = await this.fixDataIntegrity();
                    fix.applied = true;
                    break;

                case 'File System Health':
                    fix.details = await this.fixFileSystemIssues();
                    fix.applied = true;
                    break;

                case 'Interaction Health':
                    fix.details = await this.fixInteractionIssues();
                    fix.applied = true;
                    break;

                case 'Lock Health':
                    fix.details = await this.fixLockIssues();
                    fix.applied = true;
                    break;

                case 'Configuration Health':
                    fix.details = await this.fixConfigurationIssues();
                    fix.applied = true;
                    break;

                case 'Database Consistency':
                    fix.details = await this.fixDatabaseIssues();
                    fix.applied = true;
                    break;

                case 'Raffle System Health':
                    fix.details = await this.fixRaffleSystemIssues();
                    fix.applied = true;
                    break;

                case 'Ticket System Health':
                    fix.details = await this.fixTicketSystemIssues();
                    fix.applied = true;
                    break;

                default:
                    fix.details.push(`No auto-fix available for ${check.name}`);
                    break;
            }
        } catch (error) {
            fix.details.push(`Auto-fix failed: ${error.message}`);
        }

        this.fixHistory.push(fix);
        return fix;
    }

    async fixDataIntegrity() {
        const fixes = [];

        try {
            await this.storage.loadData();

            const tickets = this.storage.data.tickets;
            const raffles = this.storage.data.raffles;

            // Fix negative tickets
            for (const [userId, userData] of tickets.entries()) {
                if (userData.total < 0) {
                    userData.total = 0;
                    fixes.push(`Reset negative tickets for user ${userId}`);
                }

                // Fix spent tickets > total
                if (userData.spentTickets) {
                    const totalSpent = Object.values(userData.spentTickets).reduce((sum, tickets) => sum + tickets, 0);
                    if (totalSpent > userData.total) {
                        const excess = totalSpent - userData.total;
                        userData.total = totalSpent;
                        fixes.push(`Corrected ticket total for user ${userId} (+${excess})`);
                    }
                }
            }

            // Fix raffle participant mismatches
            for (const [raffleId, raffle] of raffles.entries()) {
                for (const [userId, ticketsEntered] of Object.entries(raffle.participants)) {
                    const userTickets = tickets.get(userId);
                    if (userTickets) {
                        if (!userTickets.spentTickets) {
                            userTickets.spentTickets = {};
                        }
                        if (userTickets.spentTickets[raffleId] !== ticketsEntered) {
                            userTickets.spentTickets[raffleId] = ticketsEntered;
                            fixes.push(`Fixed participant mismatch for user ${userId} in raffle ${raffleId}`);
                        }
                    }
                }
            }

            await this.storage.saveData();
            fixes.push(`Saved corrected data to storage`);

        } catch (error) {
            fixes.push(`Data integrity fix failed: ${error.message}`);
        }

        return fixes;
    }

    async fixFileSystemIssues() {
        const fixes = [];

        try {
            // Ensure data directory exists
            const dataDir = 'data';
            try {
                await fs.access(dataDir);
            } catch {
                await fs.mkdir(dataDir, { recursive: true });
                fixes.push(`Created data directory: ${dataDir}`);
            }

            // Create backup if data file is corrupted
            const dataFile = 'data/bot-data.json';
            try {
                const content = await fs.readFile(dataFile, 'utf8');
                JSON.parse(content); // Test if valid JSON
            } catch (error) {
                if (error.code !== 'ENOENT') {
                    const backupFile = `data/bot-data-corrupted-${Date.now()}.json`;
                    try {
                        await fs.copyFile(dataFile, backupFile);
                        fixes.push(`Backed up corrupted data file to ${backupFile}`);
                    } catch {}

                    // Initialize with empty data
                    const emptyData = {
                        tickets: {},
                        raffles: {},
                        userStats: {},
                        guildSettings: {},
                        lastSaved: new Date().toISOString()
                    };
                    await fs.writeFile(dataFile, JSON.stringify(emptyData, null, 2));
                    fixes.push(`Initialized new data file`);
                }
            }

        } catch (error) {
            fixes.push(`File system fix failed: ${error.message}`);
        }

        return fixes;
    }

    async fixInteractionIssues() {
        const fixes = [];

        try {
            // Force garbage collection if available
            if (global.gc) {
                global.gc();
                fixes.push('Forced garbage collection to free memory');
            }

            // Clear any potential interaction timeouts
            fixes.push('Cleared potential interaction timeout states');

            // Ensure managers are properly initialized
            if (this.client.ticketManager && !this.client.ticketManager.storage) {
                this.client.ticketManager.setStorage(this.client.storage);
                fixes.push('Re-initialized ticket manager storage');
            }

            if (this.client.raffleManager && !this.client.raffleManager.storage) {
                this.client.raffleManager.setStorage(this.client.storage);
                fixes.push('Re-initialized raffle manager storage');
            }

        } catch (error) {
            fixes.push(`Interaction fix failed: ${error.message}`);
        }

        return fixes;
    }

    async fixLockIssues() {
        const fixes = [];

        try {
            // Clear all stuck locks
            if (this.client.ticketManager && this.client.ticketManager.activeLocks) {
                const lockCount = this.client.ticketManager.activeLocks.size;
                this.client.ticketManager.activeLocks.clear();
                fixes.push(`Cleared ${lockCount} stuck locks`);
            }

            // Reinitialize lock system
            if (this.client.ticketManager) {
                this.client.ticketManager.activeLocks = new Set();
                fixes.push('Reinitialized lock management system');
            }

        } catch (error) {
            fixes.push(`Lock fix failed: ${error.message}`);
        }

        return fixes;
    }

    async fixConfigurationIssues() {
        const fixes = [];

        try {
            const config = this.client.storage.getConfig();

            // Set default values for missing configurations
            const defaults = {
                maxWinners: 10,
                earnCooldown: 30,
                commandCooldown: 3,
                ticketMultiplier: 1,
                unlimitedEntry: true,
                maxTicketEntry: 0
            };

            let configChanged = false;
            for (const [key, defaultValue] of Object.entries(defaults)) {
                if (config[key] === undefined || config[key] === null) {
                    config[key] = defaultValue;
                    fixes.push(`Set default ${key}: ${defaultValue}`);
                    configChanged = true;
                }
            }

            // Fix invalid values
            if (config.maxWinners < 1 || config.maxWinners > 100) {
                config.maxWinners = 10;
                fixes.push('Fixed invalid maxWinners value');
                configChanged = true;
            }

            if (config.earnCooldown < 0) {
                config.earnCooldown = 30;
                fixes.push('Fixed negative earnCooldown');
                configChanged = true;
            }

            if (config.ticketMultiplier < 0.1 || config.ticketMultiplier > 10) {
                config.ticketMultiplier = 1;
                fixes.push('Fixed invalid ticketMultiplier');
                configChanged = true;
            }

            if (configChanged) {
                this.client.storage.setConfig(config);
                await this.client.storage.saveData();
                fixes.push('Saved corrected configuration');
            }

        } catch (error) {
            fixes.push(`Configuration fix failed: ${error.message}`);
        }

        return fixes;
    }

    async fixDatabaseIssues() {
        const fixes = [];

        try {
            await this.storage.loadData();

            const tickets = this.storage.data.tickets;
            const userStats = this.storage.data.userStats;

            // Fix orphaned user stats
            for (const userId of userStats.keys()) {
                if (!tickets.has(userId)) {
                    userStats.delete(userId);
                    fixes.push(`Removed orphaned user stats for ${userId}`);
                }
            }

            // Create missing user stats
            for (const userId of tickets.keys()) {
                if (!userStats.has(userId)) {
                    userStats.set(userId, {
                        chatMessages: 0,
                        lastActivity: Date.now(),
                        ticketsEarned: 0,
                        joinedAt: Date.now()
                    });
                    fixes.push(`Created missing user stats for ${userId}`);
                }
            }

            // Fix invalid data structures
            for (const [userId, userData] of tickets.entries()) {
                if (typeof userData !== 'object') {
                    tickets.set(userId, { total: 0, spentTickets: {} });
                    fixes.push(`Fixed invalid user data structure for ${userId}`);
                }

                if (userData.spentTickets && typeof userData.spentTickets !== 'object') {
                    userData.spentTickets = {};
                    fixes.push(`Fixed invalid spentTickets structure for ${userId}`);
                }
            }

            await this.storage.saveData();
            fixes.push('Saved database consistency fixes');

        } catch (error) {
            fixes.push(`Database fix failed: ${error.message}`);
        }

        return fixes;
    }

    async fixRaffleSystemIssues() {
        const fixes = [];

        try {
            const raffles = this.client.storage.data.raffles;
            const currentTime = Math.floor(Date.now() / 1000);

            // Fix stuck raffles
            for (const [raffleId, raffle] of raffles.entries()) {
                if (raffle.isActive && raffle.endTime < currentTime - (24 * 60 * 60)) {
                    raffle.isActive = false;
                    fixes.push(`Auto-ended stuck raffle: ${raffleId}`);
                }

                // Remove empty active raffles older than 1 hour
                if (raffle.isActive && (!raffle.participants || Object.keys(raffle.participants).length === 0)) {
                    if (raffle.startTime < currentTime - (60 * 60)) {
                        raffle.isActive = false;
                        fixes.push(`Ended empty raffle: ${raffleId}`);
                    }
                }
            }

            await this.client.storage.saveData();
            fixes.push('Applied raffle system fixes');

        } catch (error) {
            fixes.push(`Raffle system fix failed: ${error.message}`);
        }

        return fixes;
    }

    async fixTicketSystemIssues() {
        const fixes = [];

        try {
            // Fix negative available tickets
            await this.fixNegativeTicketBalances();
            fixes.push('Fixed negative ticket balances');

            // Fix suspicious high ticket counts
            const tickets = this.client.storage.data.tickets;
            for (const [userId, userData] of tickets.entries()) {
                if (userData.total > 100000) {
                    // Cap at 50000 as a safety measure
                    userData.total = 50000;
                    fixes.push(`Capped suspicious ticket count for ${userId} at 50000`);
                }
            }

            // Ensure configuration consistency
            const config = this.client.storage.getConfig();
            if (config.earnFromMessages && !config.messagesPerTicket) {
                config.messagesPerTicket = 1;
                this.client.storage.setConfig(config);
                fixes.push('Set default messagesPerTicket value');
            }

            await this.client.storage.saveData();
            fixes.push('Applied ticket system fixes');

        } catch (error) {
            fixes.push(`Ticket system fix failed: ${error.message}`);
        }

        return fixes;
    }

    async checkDiskSpace() {
        // Simplified disk space check
        try {
            const stats = await fs.stat('.');
            return 1000; // Mock return 1GB free
        } catch {
            return 0;
        }
    }

    async schedulePeriodicChecks() {
        // Run comprehensive diagnostics every 2 hours
        setInterval(async () => {
            try {
                console.log('🔍 Running scheduled comprehensive diagnostics...');
                const diagnostics = await this.runComprehensiveDiagnostics();

                const criticalIssues = diagnostics.checks.filter(check => check.severity === 'critical');
                const warningIssues = diagnostics.checks.filter(check => check.severity === 'warning');
                
                console.log(`🔍 Scheduled diagnostics completed:`);
                console.log(`   ✅ ${diagnostics.checks.filter(c => c.status === 'pass').length} checks passed`);
                console.log(`   ⚠️  ${warningIssues.length} warnings`);
                console.log(`   ❌ ${criticalIssues.length} critical issues`);
                console.log(`   🔧 ${diagnostics.fixes.length} fixes applied`);

                if (criticalIssues.length > 0) {
                    console.log(`🚨 Critical issues found: ${criticalIssues.map(i => i.name).join(', ')}`);
                }

                // Log system performance
                const memUsage = process.memoryUsage();
                const memMB = Math.round(memUsage.heapUsed / 1024 / 1024);
                const uptimeHours = Math.round(process.uptime() / 3600);
                console.log(`📊 System: ${memMB}MB memory, ${uptimeHours}h uptime`);

            } catch (error) {
                console.error('❌ Scheduled diagnostics failed:', error);
            }
        }, 2 * 60 * 60 * 1000); // 2 hours

        // Run quick health checks every 3 minutes
        setInterval(async () => {
            try {
                await this.quickHealthCheck();
            } catch (error) {
                console.error('❌ Quick health check failed:', error);
            }
        }, 3 * 60 * 1000); // 3 minutes

        // Run deep data validation once per day
        setInterval(async () => {
            try {
                console.log('🔍 Running daily deep data validation...');
                await this.performDeepDataValidation();
            } catch (error) {
                console.error('❌ Deep data validation failed:', error);
            }
        }, 24 * 60 * 60 * 1000); // 24 hours

        console.log('📅 Scheduled health monitoring: 3min quick checks, 2h diagnostics, 24h deep validation');
    }

    async performDeepDataValidation() {
        const validation = {
            timestamp: Date.now(),
            issues: [],
            fixes: [],
            statistics: {}
        };

        try {
            // Deep ticket validation
            const tickets = this.client.storage.data.tickets;
            const raffles = this.client.storage.data.raffles;
            
            let totalTicketsIssued = 0;
            let totalTicketsSpent = 0;
            let negativeBalances = 0;
            let orphanedData = 0;

            // Validate each user's ticket data thoroughly
            for (const [userId, userData] of tickets.entries()) {
                totalTicketsIssued += userData.total || 0;

                // Check for negative balances
                const available = this.client.ticketManager.getAvailableTickets(userId);
                if (available < 0) {
                    negativeBalances++;
                    validation.issues.push(`Negative balance: ${userId} (${available})`);
                }

                // Validate spent tickets consistency
                if (userData.spentTickets) {
                    for (const [raffleId, spentAmount] of Object.entries(userData.spentTickets)) {
                        totalTicketsSpent += spentAmount;
                        
                        const raffle = raffles.get(raffleId);
                        if (!raffle) {
                            orphanedData++;
                            validation.issues.push(`Orphaned raffle entry: ${userId} -> ${raffleId}`);
                            
                            // Auto-fix: remove orphaned entry
                            delete userData.spentTickets[raffleId];
                            validation.fixes.push(`Removed orphaned raffle entry for ${userId}`);
                        }
                    }
                }
            }

            // Validate raffle participant consistency
            for (const [raffleId, raffle] of raffles.entries()) {
                if (raffle.participants) {
                    for (const [userId, ticketCount] of Object.entries(raffle.participants)) {
                        const userData = tickets.get(userId);
                        
                        if (!userData || !userData.spentTickets || userData.spentTickets[raffleId] !== ticketCount) {
                            validation.issues.push(`Participant mismatch: ${userId} in ${raffleId}`);
                            
                            // Auto-fix: synchronize data
                            if (userData) {
                                if (!userData.spentTickets) userData.spentTickets = {};
                                userData.spentTickets[raffleId] = ticketCount;
                                validation.fixes.push(`Fixed participant data for ${userId} in ${raffleId}`);
                            }
                        }
                    }
                }
            }

            validation.statistics = {
                totalUsers: tickets.size,
                totalRaffles: raffles.size,
                totalTicketsIssued,
                totalTicketsSpent,
                negativeBalances,
                orphanedData,
                activeRaffles: Array.from(raffles.values()).filter(r => r.isActive).length
            };

            // Apply fixes if any were found
            if (validation.fixes.length > 0) {
                await this.client.storage.saveData();
                console.log(`🔧 Deep validation applied ${validation.fixes.length} fixes`);
            }

            console.log(`🔍 Deep validation completed: ${validation.issues.length} issues, ${validation.fixes.length} fixes`);
            console.log(`📊 Stats: ${validation.statistics.totalUsers} users, ${validation.statistics.totalTicketsIssued} tickets issued, ${validation.statistics.totalTicketsSpent} spent`);

        } catch (error) {
            console.error('❌ Deep data validation error:', error);
            validation.issues.push(`Validation error: ${error.message}`);
        }

        return validation;
    }

    async quickHealthCheck() {
        // Quick check for stuck locks - more aggressive clearing
        if (this.client.ticketManager && this.client.ticketManager.activeLocks) {
            const lockCount = this.client.ticketManager.activeLocks.size;
            if (lockCount > 5) { // More aggressive - clear at 5 locks instead of 20
                console.log(`🔧 Auto-clearing ${lockCount} stuck locks`);
                this.client.ticketManager.activeLocks.clear();
            }
        }

        // Quick memory check
        const memUsage = process.memoryUsage();
        const heapUsedMB = memUsage.heapUsed / 1024 / 1024;
        if (heapUsedMB > 800) {
            console.log('🧹 High memory usage detected, running cleanup');
            if (global.gc) {
                global.gc();
            }
        }
    }

    getFixHistory() {
        return this.fixHistory;
    }

    async performHealthCheck() {
        const results = {
            timestamp: Date.now(),
            issues: [],
            fixes: [],
            status: 'healthy'
        };

        try {
            // Check ticket manager integrity
            const integrityCheck = this.client.ticketManager.validateDataIntegrity();

            if (integrityCheck.corrected > 0) {
                results.issues.push(`Found ${integrityCheck.corrected} ticket integrity issues`);
                results.fixes.push(`Auto-corrected ${integrityCheck.corrected} ticket balance issues`);
                results.status = 'fixed';
            }

            // Check for negative ticket balances and fix them
            await this.fixNegativeTicketBalances();

            // Check for orphaned raffle data
            await this.cleanupOrphanedData();

            // Check for stuck locks (if any exist)
            this.clearStaleLocks();

            // Validate all active raffles
            await this.validateActiveRaffles();

            console.log(`🔧 Health check completed: ${results.status} (${results.issues.length} issues, ${results.fixes.length} fixes)`);

        } catch (error) {
            console.error('❌ Error during health check:', error);
            results.status = 'error';
            results.issues.push(`Health check failed: ${error.message}`);
        }

        return results;
    }

    /**
     * Fix users with negative ticket balances
     */
    async fixNegativeTicketBalances() {
        const allUserIds = Array.from(this.client.storage.data.tickets.keys());
        let fixedCount = 0;

        for (const userId of allUserIds) {
            const userData = this.client.storage.getUserTickets(userId);
            const availableTickets = this.client.ticketManager.getAvailableTickets(userId);

            // If available tickets calculation results in negative, fix the total
            if (availableTickets < 0 || userData.total < 0) {
                const activeRaffles = this.client.storage.getActiveRaffles();
                let ticketsInRaffles = 0;

                for (const raffle of activeRaffles) {
                    if (raffle.participants && raffle.participants[userId]) {
                        ticketsInRaffles += raffle.participants[userId];
                    }
                }

                // Set total to at least the amount in active raffles
                if (userData.total < ticketsInRaffles) {
                    console.log(`🔧 Fixing negative balance for ${userId}: ${userData.total} → ${ticketsInRaffles}`);
                    userData.total = ticketsInRaffles;
                    this.client.storage.setUserTickets(userId, userData);
                    fixedCount++;
                }
            }
        }

        if (fixedCount > 0) {
            console.log(`🔧 Fixed ${fixedCount} negative ticket balances`);
        }
    }

    /**
     * Validate all active raffles for data consistency
     */
    async validateActiveRaffles() {
        const activeRaffles = this.client.storage.getActiveRaffles();
        let fixedRaffles = 0;

        for (const raffle of activeRaffles) {
            let raffleModified = false;

            // Check if raffle has ended but still marked as active
            if (raffle.endTime && Date.now() > raffle.endTime && raffle.isActive) {
                console.log(`🔧 Auto-ending expired raffle: ${raffle.id}`);
                raffle.isActive = false;
                raffleModified = true;
            }

            // Validate participant entries
            if (raffle.participants) {
                for (const [userId, ticketCount] of Object.entries(raffle.participants)) {
                    if (ticketCount <= 0) {
                        console.log(`🔧 Removing invalid participant entry: ${userId} with ${ticketCount} tickets`);
                        delete raffle.participants[userId];
                        raffleModified = true;
                    }
                }
            }

            if (raffleModified) {
                this.client.storage.setRaffle(raffle.id, raffle);
                fixedRaffles++;
            }
        }

        if (fixedRaffles > 0) {
            console.log(`🔧 Fixed ${fixedRaffles} raffle data inconsistencies`);
        }
    }

    async checkConfigurationHealth() {
        const issues = [];

        try {
            const config = this.client.storage.getConfig();

            // Check for required configuration values
            const requiredConfigs = ['maxWinners', 'earnCooldown', 'commandCooldown'];
            for (const configKey of requiredConfigs) {
                if (config[configKey] === undefined || config[configKey] === null) {
                    issues.push(`Missing configuration: ${configKey}`);
                }
            }

            // Check for invalid configuration values
            if (config.maxWinners && (config.maxWinners < 1 || config.maxWinners > 100)) {
                issues.push(`Invalid maxWinners: ${config.maxWinners} (should be 1-100)`);
            }

            if (config.earnCooldown && config.earnCooldown < 0) {
                issues.push(`Invalid earnCooldown: ${config.earnCooldown} (should be >= 0)`);
            }

            if (config.ticketMultiplier && (config.ticketMultiplier < 0.1 || config.ticketMultiplier > 10)) {
                issues.push(`Invalid ticketMultiplier: ${config.ticketMultiplier} (should be 0.1-10)`);
            }

        } catch (error) {
            issues.push(`Configuration check failed: ${error.message}`);
        }

        return {
            name: 'Configuration Health',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.length > 3 ? 'critical' : 'warning',
            issues,
            autoFixable: true
        };
    }

    async checkDatabaseConsistency() {
        const issues = [];

        try {
            await this.storage.loadData();

            // Check for orphaned user stats
            const tickets = this.storage.data.tickets;
            const userStats = this.storage.data.userStats;

            for (const userId of userStats.keys()) {
                if (!tickets.has(userId)) {
                    issues.push(`Orphaned user stats for ${userId}`);
                }
            }

            // Check for missing user stats
            for (const userId of tickets.keys()) {
                if (!userStats.has(userId)) {
                    issues.push(`Missing user stats for ${userId}`);
                }
            }

            // Check data structure consistency
            for (const [userId, userData] of tickets.entries()) {
                if (typeof userData !== 'object') {
                    issues.push(`Invalid user data structure for ${userId}`);
                }

                if (userData.spentTickets && typeof userData.spentTickets !== 'object') {
                    issues.push(`Invalid spentTickets structure for ${userId}`);
                }
            }

        } catch (error) {
            issues.push(`Database consistency check failed: ${error.message}`);
        }

        return {
            name: 'Database Consistency',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.length > 10 ? 'critical' : 'warning',
            issues,
            autoFixable: true
        };
    }

    async checkAPIHealth() {
        const issues = [];

        try {
            // Check if dashboard server is running
            if (!this.client.dashboardServer) {
                issues.push('Dashboard server not running');
            }

            // Check critical API endpoints (mock check)
            const criticalEndpoints = [
                '/api/dashboard-data',
                '/api/raffles',
                '/api/tickets',
                '/api/users'
            ];

            // In a real implementation, you'd make actual HTTP requests
            for (const endpoint of criticalEndpoints) {
                // Mock check - in reality you'd test the actual endpoints
                console.log(`Checking endpoint: ${endpoint}`);
            }

        } catch (error) {
            issues.push(`API health check failed: ${error.message}`);
        }

        return {
            name: 'API Health',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.some(issue => issue.includes('not running')) ? 'critical' : 'warning',
            issues,
            autoFixable: false
        };
    }

    async checkRaffleSystemHealth() {
        const issues = [];

        try {
            // Check raffle manager
            if (!this.client.raffleManager) {
                issues.push('Raffle manager not initialized');
            }

            // Check for stuck raffles
            const raffles = this.client.storage.data.raffles;
            const currentTime = Math.floor(Date.now() / 1000);
            let stuckRaffles = 0;

            for (const raffle of raffles.values()) {
                if (raffle.isActive && raffle.endTime < currentTime - (24 * 60 * 60)) {
                    stuckRaffles++;
                }
            }

            if (stuckRaffles > 0) {
                issues.push(`Found ${stuckRaffles} stuck active raffles`);
            }

            // Check for raffles with no participants
            let emptyRaffles = 0;
            for (const raffle of raffles.values()) {
                if (raffle.isActive && (!raffle.participants || Object.keys(raffle.participants).length === 0)) {
                    emptyRaffles++;
                }
            }

            if (emptyRaffles > 0) {
                issues.push(`Found ${emptyRaffles} active raffles with no participants`);
            }

        } catch (error) {
            issues.push(`Raffle system check failed: ${error.message}`);
        }

        return {
            name: 'Raffle System Health',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.some(issue => issue.includes('not initialized')) ? 'critical' : 'warning',
            issues,
            autoFixable: true
        };
    }

    async checkTicketSystemHealth() {
        const issues = [];

        try {
            // Check ticket manager
            if (!this.client.ticketManager) {
                issues.push('Ticket manager not initialized');
            }

            // Check for users with extremely high ticket counts (potential exploits)
            const tickets = this.client.storage.data.tickets;
            let suspiciousUsers = 0;

            for (const [userId, userData] of tickets.entries()) {
                if (userData.total > 100000) {
                    suspiciousUsers++;
                    issues.push(`User ${userId} has suspiciously high ticket count: ${userData.total}`);
                }
            }

            // Check for negative available tickets
            let negativeTicketUsers = 0;
            for (const userId of tickets.keys()) {
                const available = this.client.ticketManager.getAvailableTickets(userId);
                if (available < 0) {
                    negativeTicketUsers++;
                }
            }

            if (negativeTicketUsers > 0) {
                issues.push(`Found ${negativeTicketUsers} users with negative available tickets`);
            }

            // Check ticket earning consistency
            const config = this.client.storage.getConfig();
            if (config.earnFromMessages && !config.messagesPerTicket) {
                issues.push('Message-based earning enabled but messagesPerTicket not configured');
            }

        } catch (error) {
            issues.push(`Ticket system check failed: ${error.message}`);
        }

        return {
            name: 'Ticket System Health',
            status: issues.length === 0 ? 'pass' : 'warning',
            severity: issues.some(issue => issue.includes('not initialized')) ? 'critical' : 'warning',
            issues,
            autoFixable: true
        };
    }
}

module.exports = { BugFixer };