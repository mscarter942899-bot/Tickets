/**
 * Central interaction handler for slash commands, buttons, and modals
 */

const buttonHandler = require('./button-handler.js');
const modalHandler = require('./modal-handler.js');
const { EMOJIS, COLORS } = require('../config/constants.js');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    /**
     * Handle all types of interactions
     * @param {Interaction} interaction - Discord interaction
     * @param {Client} client - Discord client
     */
    async handle(interaction, client) {
        try {
            // Inject dependencies into managers
            if (!client.raffleManager.storage) {
                client.raffleManager.setStorage(client.storage);
            }
            if (!client.ticketManager.storage) {
                client.ticketManager.setStorage(client.storage);
            }

            if (interaction.isChatInputCommand()) {
                console.log(`🔧 Processing slash command: ${interaction.commandName}`);
                await this.handleSlashCommand(interaction, client);
            } else if (interaction.isButton()) {
                console.log(`🎮 Processing button interaction: ${interaction.customId}`);
                await buttonHandler.handle(interaction, client);
            } else if (interaction.isModalSubmit()) {
                console.log(`📝 Processing modal submission: ${interaction.customId}`);
                await modalHandler.handle(interaction, client);
            } else if (interaction.isAutocomplete()) {
                await this.handleAutocomplete(interaction, client);
            } else {
                console.log(`❓ Unknown interaction type: ${interaction.type}`);
            }

        } catch (error) {
            console.error('❌ Error in interaction handler:', error);
            
            if (!interaction.replied && !interaction.deferred) {
                const errorEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Interaction Error`)
                    .setDescription('An unexpected error occurred while processing your request.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },

    /**
     * Handle slash command interactions
     * @param {ChatInputCommandInteraction} interaction - Slash command interaction
     * @param {Client} client - Discord client
     */
    async handleSlashCommand(interaction, client) {
        const command = client.commands.get(interaction.commandName);

        if (!command) {
            console.error(`❌ No command matching ${interaction.commandName} was found.`);
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Command Not Found`)
                .setDescription(`The command \`/${interaction.commandName}\` was not found.`)
                .setColor(COLORS.ERROR)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Check if command is being executed too frequently (simple rate limiting)
        const userId = interaction.user.id;
        const commandName = interaction.commandName;
        const now = Date.now();
        
        if (!client.commandCooldowns) {
            client.commandCooldowns = new Map();
        }

        const userCooldowns = client.commandCooldowns.get(userId) || new Map();
        const lastUsed = userCooldowns.get(commandName) || 0;
        const cooldownTime = 3000; // 3 seconds

        if (now - lastUsed < cooldownTime) {
            const timeLeft = Math.ceil((cooldownTime - (now - lastUsed)) / 1000);
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.TIME} Command Cooldown`)
                .setDescription(`Please wait ${timeLeft} second${timeLeft !== 1 ? 's' : ''} before using this command again.`)
                .setColor(COLORS.WARNING)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Update cooldown
        userCooldowns.set(commandName, now);
        client.commandCooldowns.set(userId, userCooldowns);

        try {
            // Log command usage
            console.log(`🔧 ${interaction.user.tag} used /${commandName} in ${interaction.guild?.name || 'DM'}`);

            // Execute the command
            await command.execute(interaction, client);

        } catch (error) {
            console.error(`❌ Error executing command /${commandName}:`, error);

            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Command Error`)
                .setDescription(`An error occurred while executing the \`/${commandName}\` command.`)
                .setColor(COLORS.ERROR)
                .addFields({
                    name: 'What can you do?',
                    value: '• Try the command again\n• Check if you have the required permissions\n• Contact server administrators if the issue persists',
                    inline: false
                })
                .setTimestamp();

            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },

    /**
     * Handle autocomplete interactions
     * @param {AutocompleteInteraction} interaction - Autocomplete interaction
     * @param {Client} client - Discord client
     */
    async handleAutocomplete(interaction, client) {
        const command = client.commands.get(interaction.commandName);

        if (!command || !command.autocomplete) {
            return;
        }

        try {
            await command.autocomplete(interaction, client);
        } catch (error) {
            console.error(`❌ Error in autocomplete for /${interaction.commandName}:`, error);
        }
    }
};
