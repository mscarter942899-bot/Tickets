/**
 * Modal interaction handler for raffle bot
 * Handles modal submissions from raffle entry forms
 */

const { EmbedBuilder } = require('discord.js');
const { COLORS, EMOJIS, RAFFLE } = require('../config/constants.js');
const { TimeFormatter } = require('../utils/time-formatter.js');

module.exports = {
    /**
     * Handle modal interactions
     * @param {ModalSubmitInteraction} interaction - Modal submit interaction
     * @param {Client} client - Discord client
     */
    async handle(interaction, client) {
        const customId = interaction.customId;

        try {
            if (customId.startsWith('raffle_entry_')) {
                await this.handleRaffleEntry(interaction, client);
            } else {
                console.log(`❓ Unknown modal interaction: ${customId}`);

                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Unknown Modal`)
                    .setDescription('This modal submission is not recognized.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed], ephemeral: true });
            }

        } catch (error) {
            console.error('❌ Error in modal handler:', error);

            if (!interaction.replied && !interaction.deferred) {
                const errorEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Modal Error`)
                    .setDescription('An error occurred while processing your submission.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },

    /**
     * Handle raffle entry modal submission
     * @param {ModalSubmitInteraction} interaction - Modal submit interaction
     * @param {Client} client - Discord client
     */
    async handleRaffleEntry(interaction, client) {
        const raffleId = interaction.customId.replace('raffle_entry_', '');
        const userId = interaction.user.id;
        const operationId = `${userId}-${raffleId}-${Date.now()}`;

        console.log(`🎯 Starting raffle entry operation ${operationId}`);

        // IMMEDIATELY defer to prevent timeout
        try {
            await interaction.deferReply({ ephemeral: true });
        } catch (deferError) {
            console.error(`❌ Failed to defer reply for ${operationId}:`, deferError);
            return;
        }

        // Set up emergency timeout
        const emergencyTimeout = setTimeout(async () => {
            console.log(`🚨 EMERGENCY TIMEOUT for operation ${operationId}`);
            try {
                if (!interaction.replied) {
                    await interaction.editReply({
                        content: `❌ Request timed out. Please try again.`,
                        ephemeral: true
                    });
                }
            } catch (e) {
                console.error('❌ Emergency timeout reply failed:', e);
            }
        }, 8000); // 8 second emergency timeout

        try {
            // Get form data
            const ticketCountInput = interaction.fields.getTextInputValue('ticket_count');
            const entryReason = interaction.fields.getTextInputValue('entry_reason') || null;

            // Validate ticket count
            const ticketCount = parseInt(ticketCountInput);

            if (isNaN(ticketCount) || ticketCount < RAFFLE.MIN_TICKET_ENTRY) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Invalid Ticket Count`)
                    .setDescription(`Please enter a valid number of tickets (minimum: ${RAFFLE.MIN_TICKET_ENTRY})`)
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                clearTimeout(emergencyTimeout);
                return await interaction.editReply({ embeds: [embed] });
            }

            // Check configurable entry limit (if set)
            const config = client.storage.getConfig();
            const maxEntry = config.maxTicketEntry || RAFFLE.MAX_TICKET_ENTRY;
            
            if (maxEntry && ticketCount > maxEntry) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Too Many Tickets`)
                    .setDescription(`You can only enter up to ${maxEntry} tickets per raffle.`)
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                clearTimeout(emergencyTimeout);
                return await interaction.editReply({ embeds: [embed] });
            }

            // Get raffle data
            const raffle = client.storage.getRaffle(raffleId);
            if (!raffle) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Raffle Not Found`)
                    .setDescription('This raffle could not be found. It may have been deleted.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                clearTimeout(emergencyTimeout);
                return await interaction.editReply({ embeds: [embed] });
            }

            // Check if raffle is still active
            const currentTime = Math.floor(Date.now() / 1000);
            if (!raffle.isActive || currentTime >= raffle.endTime) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Raffle Ended`)
                    .setDescription('This raffle has ended while you were filling out the form.')
                    .setColor(COLORS.ERROR)
                    .addFields({
                        name: `${EMOJIS.TIME} Ended`,
                        value: TimeFormatter.discordTimestamp(raffle.endTime, 'R'),
                        inline: true
                    })
                    .setTimestamp();

                clearTimeout(emergencyTimeout);
                return await interaction.editReply({ embeds: [embed] });
            }

            // Check user's available tickets
            const availableTickets = client.ticketManager.getAvailableTickets(userId);

            if (availableTickets < ticketCount) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Insufficient Tickets`)
                    .setDescription(`You only have ${availableTickets} available tickets, but tried to enter ${ticketCount}.`)
                    .setColor(COLORS.ERROR)
                    .addFields({
                        name: `${EMOJIS.HELP} Get More Tickets`,
                        value: `• Use \`/earn\` for free tickets\n• Stay active in chat for bonus tickets`,
                        inline: false
                    })
                    .setTimestamp();

                clearTimeout(emergencyTimeout);
                return await interaction.editReply({ embeds: [embed] });
            }

            // Process the entry
            console.log(`🎟️ Processing entry: ${ticketCount} tickets for ${userId} in raffle ${raffleId}`);

            // Use ticket for raffle entry (this atomically updates both user tickets and raffle participation)
            const useResult = client.ticketManager.spendTickets(userId, ticketCount, raffleId);

            if (!useResult.success) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Entry Failed`)
                    .setDescription(useResult.message || 'Failed to use tickets for raffle entry.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                clearTimeout(emergencyTimeout);
                return await interaction.editReply({ embeds: [embed] });
            }

            // Get fresh raffle data (participation already updated in spendTickets)
            const updatedRaffle = client.storage.getRaffle(raffleId);
            
            if (!updatedRaffle) {
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Entry Failed`)
                    .setDescription('Raffle data could not be retrieved after entry.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                clearTimeout(emergencyTimeout);
                return await interaction.editReply({ embeds: [embed] });
            }

            // Calculate win probability
            const totalTickets = Object.values(updatedRaffle.participants).reduce((sum, tickets) => sum + tickets, 0);
            const userTickets = updatedRaffle.participants[userId] || 0;
            const winProbability = totalTickets > 0 ? Math.round((userTickets / totalTickets) * 100 * 100) / 100 : 0;
            const currentEntry = updatedRaffle.participants[userId];

            // Create success embed
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.SUCCESS} Successfully Entered Raffle!`)
                .setColor(COLORS.SUCCESS)
                .setDescription(`You've entered **${raffle.prize}** with ${ticketCount} ticket${ticketCount !== 1 ? 's' : ''}!`)
                .addFields(
                    {
                        name: `${EMOJIS.TICKET} Your Entry`,
                        value: `**Tickets Entered:** ${ticketCount}\n**Total in Raffle:** ${currentEntry}\n**Win Chance:** ${winProbability}%`,
                        inline: true
                    },
                    {
                        name: `${EMOJIS.STATS} Raffle Stats`,
                        value: `**Participants:** ${Object.keys(updatedRaffle.participants).length}\n**Total Tickets:** ${Object.values(updatedRaffle.participants).reduce((sum, tickets) => sum + tickets, 0)}\n**Winners:** ${raffle.winners}`,
                        inline: true
                    }
                )
                .setTimestamp();

            // Add reason if provided
            if (entryReason && entryReason.trim()) {
                embed.addFields({
                    name: `${EMOJIS.SPARKLES} Your Message`,
                    value: entryReason.substring(0, 500),
                    inline: false
                });
            }

            embed.setFooter({ 
                text: `Good luck! • Raffle ID: ${raffleId}`,
                iconURL: interaction.user.displayAvatarURL()
            });

            clearTimeout(emergencyTimeout);
            await interaction.editReply({ embeds: [embed] });

            // Update the raffle message with new participant count
            try {
                const channel = await client.channels.fetch(raffle.channelId);
                if (channel && raffle.messageId) {
                    const message = await channel.messages.fetch(raffle.messageId);
                    if (message) {
                        const updatedEmbed = client.raffleManager.createRaffleEmbed(updatedRaffle);
                        const updatedButtons = client.raffleManager.createRaffleButtons(updatedRaffle);
                        await message.edit({
                            embeds: [updatedEmbed],
                            components: [updatedButtons]
                        });
                    }
                }
            } catch (updateError) {
                console.error(`❌ Error updating raffle message:`, updateError);
            }

            // Log successful entry
            console.log(`✅ ${interaction.user.tag} entered raffle ${raffleId} with ${ticketCount} tickets (${winProbability}% chance)`);

        } catch (error) {
            console.error(`❌ Error in raffle entry ${operationId}:`, error);

            clearTimeout(emergencyTimeout);

            const errorEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Entry Error`)
                .setDescription('An unexpected error occurred while processing your raffle entry. Please try again.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            try {
                if (!interaction.replied) {
                    await interaction.editReply({ embeds: [errorEmbed] });
                }
            } catch (replyError) {
                console.error(`❌ Failed to send error reply:`, replyError);
            }
        }
    }
};