/**
 * Button interaction handler for raffle bot
 * Handles all button clicks from raffle embeds and UI components
 */

const { EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const { COLORS, EMOJIS, RAFFLE } = require('../config/constants.js');
const { TimeFormatter } = require('../utils/time-formatter.js');

module.exports = {
    /**
     * Handle button interactions
     * @param {ButtonInteraction} interaction - Button interaction
     * @param {Client} client - Discord client
     */
    async handle(interaction, client) {
        const customId = interaction.customId;

        try {
            if (customId.startsWith('raffle_enter_')) {
                await this.handleRaffleEntry(interaction, client);
            } else if (customId === 'raffle_help') {
                await this.handleRaffleHelp(interaction, client);
            } else if (customId.startsWith('raffle_stats_')) {
                await this.handleRaffleStats(interaction, client);
            } else {
                console.log(`❓ Unknown button interaction: ${customId}`);
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Unknown Action`)
                    .setDescription('This button action is not recognized.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed], ephemeral: true });
            }

        } catch (error) {
            console.error('❌ Error in button handler:', error);
            
            if (!interaction.replied && !interaction.deferred) {
                const errorEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.ERROR} Button Error`)
                    .setDescription('An error occurred while processing your button click.')
                    .setColor(COLORS.ERROR)
                    .setTimestamp();

                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    },

    /**
     * Handle raffle entry button click - shows modal for ticket entry
     * @param {ButtonInteraction} interaction - Button interaction
     * @param {Client} client - Discord client
     */
    async handleRaffleEntry(interaction, client) {
        const raffleId = interaction.customId.replace('raffle_enter_', '');
        const userId = interaction.user.id;

        // Get raffle data
        const raffle = client.storage.getRaffle(raffleId);
        if (!raffle) {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Raffle Not Found`)
                .setDescription('This raffle could not be found. It may have been deleted.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Check if raffle is still active
        const currentTime = Math.floor(Date.now() / 1000);
        if (!raffle.isActive || currentTime >= raffle.endTime) {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Raffle Ended`)
                .setDescription('This raffle has already ended and is no longer accepting entries.')
                .setColor(COLORS.ERROR)
                .addFields({
                    name: `${EMOJIS.TIME} Ended`,
                    value: TimeFormatter.discordTimestamp(raffle.endTime, 'R'),
                    inline: true
                })
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Get user's available tickets
        const availableTickets = client.ticketManager.getAvailableTickets(userId);
        
        if (availableTickets === 0) {
            const cooldownCheck = client.ticketManager.canEarnTicket(userId);
            
            let helpText = `You don't have any available tickets to enter this raffle.\n\n`;
            helpText += `${EMOJIS.HELP} **How to get tickets:**\n`;
            
            if (cooldownCheck.canEarn) {
                helpText += `• ${EMOJIS.SUCCESS} Use \`/earn\` right now for a free ticket!\n`;
            } else {
                helpText += `• ${EMOJIS.TIME} Use \`/earn\` in ${cooldownCheck.timeRemaining}\n`;
            }
            
            helpText += `• ${EMOJIS.SPARKLES} Stay active in chat to earn bonus tickets\n`;
            helpText += `• ${EMOJIS.RAFFLE} Participate in server events`;

            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.TICKET} No Available Tickets`)
                .setDescription(helpText)
                .setColor(COLORS.WARNING)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Get current user participation in this raffle
        const currentEntry = raffle.participants[userId] || 0;
        const maxEntry = Math.min(availableTickets, RAFFLE.MAX_TICKET_ENTRY);

        // Create modal for ticket entry
        const modal = new ModalBuilder()
            .setCustomId(`raffle_entry_${raffleId}`)
            .setTitle(`Enter Raffle: ${raffle.prize.substring(0, 40)}${raffle.prize.length > 40 ? '...' : ''}`);

        // Ticket count input
        const ticketInput = new TextInputBuilder()
            .setCustomId('ticket_count')
            .setLabel('Number of Tickets to Enter')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder(`1-${maxEntry} tickets`)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(2);

        // Optional reason input
        const reasonInput = new TextInputBuilder()
            .setCustomId('entry_reason')
            .setLabel('Why do you want to win? (Optional)')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Share your motivation or what this prize means to you...')
            .setRequired(false)
            .setMaxLength(500);

        // Add inputs to action rows
        const ticketRow = new ActionRowBuilder().addComponents(ticketInput);
        const reasonRow = new ActionRowBuilder().addComponents(reasonInput);

        modal.addComponents(ticketRow, reasonRow);

        // Show modal
        await interaction.showModal(modal);

        // Log interaction
        console.log(`🎟️ ${interaction.user.tag} opened entry modal for raffle ${raffleId}`);
    },

    /**
     * Handle help button click - shows information about earning tickets
     * @param {ButtonInteraction} interaction - Button interaction
     * @param {Client} client - Discord client
     */
    async handleRaffleHelp(interaction, client) {
        const userId = interaction.user.id;
        const cooldownCheck = client.ticketManager.canEarnTicket(userId);
        const userStats = client.ticketManager.getTicketStats(userId);

        const embed = new EmbedBuilder()
            .setTitle(`${EMOJIS.HELP} How to Earn Raffle Tickets`)
            .setColor(COLORS.INFO)
            .setTimestamp();

        // Main earning methods
        let methodsText = `${EMOJIS.TICKET} **Free Tickets (/earn command):**\n`;
        
        if (cooldownCheck.canEarn) {
            methodsText += `${EMOJIS.SUCCESS} Ready now! Use \`/earn\` to claim 1 free ticket\n`;
        } else {
            methodsText += `${EMOJIS.TIME} Next free ticket: ${cooldownCheck.timeRemaining}\n`;
        }
        
        methodsText += `• Get 1 free ticket every 30 minutes\n`;
        methodsText += `• No limit on how many you can earn!\n\n`;

        methodsText += `${EMOJIS.SPARKLES} **Chat Activity Rewards:**\n`;
        methodsText += `• Earn bonus tickets by being active in chat\n`;
        methodsText += `• Participate in conversations naturally\n`;
        methodsText += `• Help other members and engage with content\n`;
        methodsText += `• Automatic rewards for regular participation\n\n`;

        methodsText += `${EMOJIS.RAFFLE} **Special Events:**\n`;
        methodsText += `• Server events and competitions\n`;
        methodsText += `• Community challenges\n`;
        methodsText += `• Holiday bonuses and promotions`;

        embed.addFields({
            name: `${EMOJIS.MONEY} Earning Methods`,
            value: methodsText,
            inline: false
        });

        // User's current status
        let statusText = `${EMOJIS.STATS} **Your Current Balance:**\n`;
        statusText += `• Total Tickets: ${userStats.total}\n`;
        statusText += `• Available: ${userStats.available}\n`;
        statusText += `• In Active Raffles: ${userStats.inActiveRaffles}\n\n`;
        
        statusText += `${EMOJIS.SPARKLES} **Your Activity:**\n`;
        statusText += `• Chat Tickets Earned: ${userStats.chatRewards}\n`;
        statusText += `• Active Raffle Entries: ${userStats.activeRaffleEntries}`;

        embed.addFields({
            name: `${EMOJIS.STATS} Your Status`,
            value: statusText,
            inline: false
        });

        // Tips and strategies
        let tipsText = `${EMOJIS.SUCCESS} **Pro Tips:**\n`;
        tipsText += `• Set a reminder to use \`/earn\` every 30 minutes\n`;
        tipsText += `• Stay active in multiple channels for bonus rewards\n`;
        tipsText += `• Check \`/my-tickets\` to track your progress\n`;
        tipsText += `• Use \`/raffle-status\` to see all active raffles\n`;
        tipsText += `• Enter raffles strategically based on your odds\n\n`;

        tipsText += `${EMOJIS.WARNING} **Important Notes:**\n`;
        tipsText += `• Tickets in active raffles are temporarily unavailable\n`;
        tipsText += `• If a raffle is cancelled, your tickets are refunded\n`;
        tipsText += `• More tickets = higher chance of winning!`;

        embed.addFields({
            name: `${EMOJIS.HELP} Tips & Strategies`,
            value: tipsText,
            inline: false
        });

        // Quick actions
        let actionsText = `${EMOJIS.TICKET} \`/earn\` - Claim free ticket (if available)\n`;
        actionsText += `${EMOJIS.STATS} \`/my-tickets\` - Check your ticket balance\n`;
        actionsText += `${EMOJIS.RAFFLE} \`/raffle-status\` - View all active raffles\n`;
        actionsText += `${EMOJIS.SPARKLES} \`/chat-stats\` - View your chat activity`;

        embed.addFields({
            name: `${EMOJIS.HELP} Quick Commands`,
            value: actionsText,
            inline: false
        });

        embed.setFooter({ 
            text: `Tip: The more active you are, the more tickets you can earn!`,
            iconURL: interaction.user.displayAvatarURL()
        });

        await interaction.reply({ embeds: [embed], ephemeral: true });

        // Log help interaction
        console.log(`❓ ${interaction.user.tag} viewed raffle help information`);
    },

    /**
     * Handle raffle stats button click - shows detailed raffle statistics
     * @param {ButtonInteraction} interaction - Button interaction
     * @param {Client} client - Discord client
     */
    async handleRaffleStats(interaction, client) {
        const raffleId = interaction.customId.replace('raffle_stats_', '');
        const userId = interaction.user.id;

        // Get raffle statistics
        const stats = client.raffleManager.getRaffleStats(raffleId);
        
        if (!stats) {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ERROR} Raffle Not Found`)
                .setDescription('This raffle could not be found or has been deleted.')
                .setColor(COLORS.ERROR)
                .setTimestamp();

            return await interaction.reply({ embeds: [embed], ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setTitle(`${EMOJIS.STATS} Raffle Statistics`)
            .setColor(COLORS.INFO)
            .setTimestamp();

        // Raffle overview
        let overviewText = `**Prize:** ${stats.prize}\n`;
        overviewText += `**Status:** ${stats.isActive ? `${EMOJIS.SUCCESS} Active` : `${EMOJIS.ERROR} Ended`}\n`;
        overviewText += `**Winners:** ${stats.winners}\n`;
        
        if (stats.isActive) {
            overviewText += `**Time Remaining:** ${TimeFormatter.formatCountdown(stats.timeRemaining)}\n`;
            overviewText += `**Ends:** ${TimeFormatter.discordTimestamp(stats.endTime, 'R')}`;
        } else {
            overviewText += `**Ended:** ${TimeFormatter.discordTimestamp(stats.endTime, 'F')}`;
        }

        embed.addFields({
            name: `${EMOJIS.RAFFLE} Raffle Overview`,
            value: overviewText,
            inline: true
        });

        // Participation stats
        let participationText = `**Total Participants:** ${stats.participantCount}\n`;
        participationText += `**Total Tickets:** ${stats.totalTickets}\n`;
        participationText += `**Average per User:** ${stats.averageTicketsPerParticipant}\n`;
        participationText += `**Duration:** ${TimeFormatter.formatDuration(stats.duration)}`;

        embed.addFields({
            name: `${EMOJIS.STATS} Participation Stats`,
            value: participationText,
            inline: true
        });

        // User's participation
        const userEntry = stats.topParticipants.find(p => p.userId === userId);
        let userText = '';
        
        if (userEntry) {
            const winChance = client.raffleManager.calculateWinProbability({ 
                participants: Object.fromEntries(stats.topParticipants.map(p => [p.userId, p.tickets])),
                winners: stats.winners 
            }, userId);
            
            userText = `**Your Tickets:** ${userEntry.tickets}\n`;
            userText += `**Your Share:** ${userEntry.percentage}%\n`;
            userText += `**Win Chance:** ${winChance}%\n`;
            userText += `**Status:** ${EMOJIS.SUCCESS} Entered`;
        } else {
            userText = `**Status:** ${EMOJIS.WARNING} Not entered\n`;
            userText += `**Available Tickets:** ${client.ticketManager.getAvailableTickets(userId)}\n`;
            userText += `**Action:** Click "Enter Raffle" to participate`;
        }

        embed.addFields({
            name: `${EMOJIS.TICKET} Your Entry`,
            value: userText,
            inline: true
        });

        // Top participants leaderboard
        if (stats.topParticipants.length > 0) {
            let leaderboardText = '';
            
            for (let i = 0; i < Math.min(stats.topParticipants.length, 5); i++) {
                const participant = stats.topParticipants[i];
                const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
                leaderboardText += `${medal} <@${participant.userId}> - ${participant.tickets} tickets (${participant.percentage}%)\n`;
            }

            if (stats.topParticipants.length > 5) {
                leaderboardText += `*...and ${stats.topParticipants.length - 5} more participants*`;
            }

            embed.addFields({
                name: `${EMOJIS.CROWN} Top Participants`,
                value: leaderboardText,
                inline: false
            });
        }

        // Odds and probabilities
        if (stats.isActive && stats.totalTickets > 0) {
            let oddsText = `**Odds with 1 ticket:** ${Math.round((1 / stats.totalTickets) * stats.winners * 10000) / 100}%\n`;
            oddsText += `**Odds with 5 tickets:** ${Math.round((5 / stats.totalTickets) * stats.winners * 10000) / 100}%\n`;
            oddsText += `**Odds with 10 tickets:** ${Math.round((10 / stats.totalTickets) * stats.winners * 10000) / 100}%\n`;
            oddsText += `\n*Note: These are approximate calculations*`;

            embed.addFields({
                name: `${EMOJIS.STATS} Win Probability Calculator`,
                value: oddsText,
                inline: false
            });
        }

        embed.setFooter({ 
            text: `Raffle ID: ${stats.id} • Stats update in real-time`,
            iconURL: interaction.user.displayAvatarURL()
        });

        await interaction.reply({ embeds: [embed], ephemeral: true });

        // Log stats interaction
        console.log(`📊 ${interaction.user.tag} viewed stats for raffle ${raffleId}`);
    }
};
