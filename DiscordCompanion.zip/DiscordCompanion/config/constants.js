/**
 * Configuration constants for the Discord Raffle Bot
 */

module.exports = {
    // Color scheme for embeds
    COLORS: {
        PRIMARY: 0x5865F2,     // Discord blurple
        SUCCESS: 0x57F287,     // Green
        ERROR: 0xED4245,       // Red
        WARNING: 0xFEE75C,     // Yellow
        INFO: 0x5DADE2,        // Blue
        RAFFLE: 0x9B59B6,      // Purple
        WINNER: 0xF39C12,      // Orange
        NEUTRAL: 0x95A5A6      // Gray
    },

    // Emojis for enhanced UI
    EMOJIS: {
        TICKET: '🎟️',
        RAFFLE: '🎁',
        WINNER: '🏆',
        TIME: '⏰',
        STATS: '📊',
        ENTER: '🎯',
        HELP: '❓',
        SUCCESS: '✅',
        ERROR: '❌',
        WARNING: '⚠️',
        LOADING: '⏳',
        MONEY: '💰',
        CROWN: '👑',
        STAR: '⭐',
        SPARKLES: '✨',
        PARTY: '🎉',
        TADA: '🎊'
    },

    // Cooldown timings (in milliseconds)
    COOLDOWNS: {
        EARN_TICKET: 30 * 60 * 1000, // 30 minutes
        COMMAND_RATE_LIMIT: 3 * 1000 // 3 seconds
    },

    // Raffle configuration
    RAFFLE: {
        MAX_WINNERS: 10,
        MAX_TICKET_ENTRY: null, // No limit by default
        MIN_TICKET_ENTRY: 1,
        DEFAULT_WINNERS: 1,
        UNLIMITED_ENTRY: true
    },

    // Permission levels
    PERMISSIONS: {
        MANAGE_SERVER: 'ManageGuild'
    },

    // Storage file paths
    STORAGE: {
        DATA_FILE: 'data/bot-data.json',
        BACKUP_FILE: 'data/bot-data-backup.json'
    }
};
